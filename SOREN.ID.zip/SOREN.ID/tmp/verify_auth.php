﻿<?php
$hashAdmin = '$2y$10$zvailtb.KlHCXijXsknAOeaD59ZR4.7OT0qtlztf2.0/f85HLLGgm';
$hashUser = '$2y$10$8pgf8SwLSl/JP/k.6U2AHupnTmoIfngdwVHa1T.nJodPS9BdFZnHC';
var_export(password_verify('admin123', $hashAdmin));
echo PHP_EOL;
var_export(password_verify('user123', $hashUser));
echo PHP_EOL;
