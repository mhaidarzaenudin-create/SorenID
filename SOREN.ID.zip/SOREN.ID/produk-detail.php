<?php
// produk-detail.php - Product Detail & Customer Reviews System for SOREN.ID
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'katalog.php');
    exit;
}

// Ambil detail produk
$stmt = $pdo->prepare("
    SELECT p.*, k.nama_kategori 
    FROM produk p 
    JOIN kategori k ON p.id_kategori = k.id 
    WHERE p.id = ?
");
$stmt->execute([$id]);
$produk = $stmt->fetch();

if (!$produk) {
    header('Location: ' . BASE_URL . 'katalog.php');
    exit;
}

$page_title = $produk['nama_produk'];

// Ambil statistik rating ulasan
$rating_stat = get_product_rating($pdo, $id);

// Ambil daftar ulasan produk
$stmt_rev = $pdo->prepare("
    SELECT u.*, COALESCE(usr.nama, 'Pelanggan Terverifikasi') as nama_user
    FROM ulasan_produk u
    LEFT JOIN users usr ON u.id_user = usr.id
    WHERE u.id_produk = ?
    ORDER BY u.created_at DESC
");
$stmt_rev->execute([$id]);
$reviews = $stmt_rev->fetchAll();

// Produk Terkait (kategori sama)
$stmt_related = $pdo->prepare("
    SELECT p.*, k.nama_kategori 
    FROM produk p 
    JOIN kategori k ON p.id_kategori = k.id 
    WHERE p.id_kategori = ? AND p.id != ? 
    LIMIT 4
");
$stmt_related->execute([$produk['id_kategori'], $id]);
$related_products = $stmt_related->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding-top: 20px; padding-bottom: 60px;">
  <!-- Breadcrumb -->
  <div class="breadcrumb">
    <a href="<?= BASE_URL ?>">Beranda</a>
    <span>/</span>
    <a href="<?= BASE_URL ?>katalog.php?kategori=<?= $produk['id_kategori'] ?>"><?= htmlspecialchars($produk['nama_kategori']) ?></a>
    <span>/</span>
    <span class="breadcrumb-active" style="font-weight:600;"><?= htmlspecialchars($produk['nama_produk']) ?></span>
  </div>

  <!-- Detail Layout -->
  <div class="detail-layout">
    <!-- Gallery -->
    <div class="detail-gallery">
      <div class="gallery-main" id="mainGalleryImg">
        <img src="<?= !empty($produk['gambar']) ? UPLOADS_URL . 'products/' . htmlspecialchars($produk['gambar']) : ASSETS_URL . 'images/banners/hero-1.jpg' ?>" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="<?= htmlspecialchars($produk['nama_produk']) ?>" id="activeImg">
      </div>
    </div>

    <!-- Info & Options -->
    <div class="detail-info">
      <div class="detail-category-badge" style="font-size: 12.5px; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; margin-bottom: 6px;">
        <?= htmlspecialchars($produk['nama_kategori']) ?>
      </div>
      <h1 class="detail-title"><?= htmlspecialchars($produk['nama_produk']) ?></h1>

      <div class="detail-meta">
        <div class="rating-stars">
          <span class="stars-icon">
            <?php 
              $avg = $rating_stat['average'] ?: 5.0;
              for ($i = 1; $i <= 5; $i++) echo $i <= round($avg) ? '★' : '☆';
            ?>
          </span>
          <span style="font-weight: 700; margin-left: 4px;"><?= $avg ?></span>
          <a href="#ulasanSection" class="detail-review-link" style="text-decoration:underline; font-size:12.5px; margin-left:6px;">
            (<?= $rating_stat['total'] ?> Ulasan Pembeli)
          </a>
        </div>
        <span style="color:var(--border-color);">|</span>
        <span class="badge-verified">✓ 100% Original</span>
      </div>

      <div class="detail-price">
        <span><?= format_rupiah($produk['harga']) ?></span>
      </div>

      <!-- Color Options -->
      <?php if (!empty($produk['warna'])): 
        $colors = explode(',', $produk['warna']);
      ?>
        <div class="option-group">
          <div class="option-title">
            <span>Pilihan Warna:</span>
            <span id="selectedColorName" style="color:var(--primary); font-weight:600; text-transform:none;"><?= trim($colors[0]) ?></span>
          </div>
          <div class="option-chips">
            <?php foreach ($colors as $idx => $c): 
              $c_trim = trim($c);
            ?>
              <button type="button" class="chip-btn <?= $idx === 0 ? 'active' : '' ?>" onclick="selectColor(this, '<?= htmlspecialchars($c_trim) ?>')">
                <?= htmlspecialchars($c_trim) ?>
              </button>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endif; ?>

      <!-- Size Options -->
      <div class="option-group">
        <div class="option-title">
          <span>Ukuran:</span>
          <span style="color:var(--primary); font-weight:600; text-transform:none;"><?= htmlspecialchars($produk['ukuran'] ?: 'All Size') ?></span>
        </div>
        <div class="option-chips">
          <button type="button" class="chip-btn active">
            <?= htmlspecialchars($produk['ukuran'] ?: 'All Size') ?>
          </button>
        </div>
      </div>

      <!-- Quantity & Stock -->
      <div class="option-group">
        <div class="option-title">
          <span>Jumlah:</span>
        </div>
        <div style="display: flex; align-items: center; gap: 16px;">
          <div class="qty-stepper">
            <button type="button" class="qty-btn" onclick="adjustQty(-1)">-</button>
            <input type="text" id="productQty" class="qty-input" value="1" readonly>
            <button type="button" class="qty-btn" onclick="adjustQty(1)">+</button>
          </div>
          <div class="stock-indicator">
            Stok Tersedia: <b id="stockCount"><?= $produk['stok'] ?></b> pcs
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div class="detail-actions">
        <button type="button" class="btn btn-outline" style="flex: 1;" onclick="handleAddToCart()">
          🛍️ Tambah ke Keranjang
        </button>
        <button type="button" class="btn btn-primary" style="flex: 1;" onclick="handleBuyNow()">
          Beli Sekarang
        </button>
      </div>

      <!-- Guarantee Badges -->
      <div style="background:#fff; border-radius:var(--radius-sm); border:1px solid var(--border-color); padding:16px; font-size:13px; color:var(--text-muted); display:flex; flex-direction:column; gap:8px;">
        <div>🚚 <b>Pengiriman:</b> Siap kirim dari Bandung hari ini (Order s/d 15.00 WIB)</div>
        <div>✨ <b>Garansi:</b> Garansi retur/tukar warna jika barang cacat produksi</div>
        <div>💬 <b>Bantuan:</b> Butuh saran warna? Klik tombol chat di pojok kanan bawah</div>
      </div>
    </div>
  </div>

  <!-- Tabs Section: Deskripsi, Ukuran, Pengiriman -->
  <div class="tabs-container">
    <div class="tabs-nav">
      <button type="button" class="tab-btn active" data-tab="tabDesc">Deskripsi Produk</button>
      <button type="button" class="tab-btn" data-tab="tabSize">Panduan Ukuran</button>
      <button type="button" class="tab-btn" data-tab="tabShipping">Informasi Pengiriman</button>
    </div>

    <div class="tab-pane active" id="tabDesc">
      <div style="max-width: 800px;">
        <p style="margin-bottom: 16px;"><?= nl2br(htmlspecialchars($produk['deskripsi'] ?: 'Koleksi istimewa dari SOREN.ID dengan standar jahitan butik dan material berkelas tinggi.')) ?></p>
        <h4 style="font-size:15px; margin-bottom:8px; color:var(--text-dark);">Petunjuk Perawatan Bahan:</h4>
        <ul style="padding-left: 20px; color:var(--text-muted); font-size:14px; line-height:1.7;">
          <li>Cuci dengan tangan menggunakan air dingin atau detergen lembut.</li>
          <li>Hindari memeras kain terlalu kuat agar serat kain tetap halus dan rapi.</li>
          <li>Jemur di tempat teduh (jangan terkena sinar matahari terik langsung).</li>
          <li>Setrika dengan suhu rendah atau gunakan steam iron.</li>
        </ul>
      </div>
    </div>

    <div class="tab-pane" id="tabSize">
      <div style="max-width: 700px;">
        <h4 style="font-size:16px; margin-bottom:12px;">Spesifikasi Ukuran:</h4>
        <table class="table" style="background:#fff; border-radius:var(--radius-sm); border:1px solid var(--border-color);">
          <tr>
            <td style="width: 200px; font-weight:600;">Dimensi Ukuran</td>
            <td><?= htmlspecialchars($produk['ukuran'] ?: 'All Size') ?></td>
          </tr>
          <tr>
            <td style="font-weight:600;">Pilihan Warna</td>
            <td><?= htmlspecialchars($produk['warna'] ?: '-') ?></td>
          </tr>
          <tr>
            <td style="font-weight:600;">Finishing Jahitan</td>
            <td>Jahit Tepi Butik Halus & Laser Cut Rapi</td>
          </tr>
        </table>
      </div>
    </div>

    <div class="tab-pane" id="tabShipping">
      <div style="max-width: 750px; line-height: 1.7; color:var(--text-muted); font-size:14px;">
        <p><b>Pengiriman:</b> Pesanan diproses setiap hari Senin - Sabtu. Pesanan yang terkonfirmasi sebelum pukul 15.00 WIB akan dikirim pada hari yang sama.</p>
        <p style="margin-top: 10px;"><b>Kurir:</b> J&T Express, SiCepat, JNE, dan Paxel Instant.</p>
        <p style="margin-top: 10px;"><b>Kebijakan Retur:</b> Kami menerima penukaran ukuran atau pengembalian produk jika terdapat cacat produksi dalam waktu 3x24 jam setelah pesanan diterima.</p>
      </div>
    </div>
  </div>

  <!-- ------------------------------------------------------------- -->
  <!-- FITUR ULASAN PRODUK (Customer Reviews Section) -->
  <!-- ------------------------------------------------------------- -->
  <section class="reviews-wrapper" id="ulasanSection">
    <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:24px;">
      <div>
        <div class="section-subtitle">Ulasan Pelanggan</div>
        <h2 style="font-family: var(--font-serif); font-size: 28px;">Pengalaman Pembeli</h2>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="openReviewModal">
        ✍️ Tulis Ulasan Kamu
      </button>
    </div>

    <!-- Rating Summary Grid -->
    <div class="reviews-summary-grid">
      <!-- Score Box -->
      <div class="score-box">
        <div class="score-number"><?= $rating_stat['average'] ?: '5.0' ?></div>
        <div class="score-stars">
          <?php 
            $avg_r = $rating_stat['average'] ?: 5.0;
            for ($i = 1; $i <= 5; $i++) echo $i <= round($avg_r) ? '★' : '☆';
          ?>
        </div>
        <div class="score-sub">Berdasarkan <?= $rating_stat['total'] ?> ulasan</div>
      </div>

      <!-- Progress Bars -->
      <div class="rating-bars">
        <?php 
          $tot = max(1, $rating_stat['total']);
          for ($s = 5; $s >= 1; $s--): 
            $c = $rating_stat['star_' . $s];
            $pct = round(($c / $tot) * 100);
        ?>
          <div class="bar-row">
            <span class="bar-label"><?= $s ?> Bintang</span>
            <div class="bar-progress">
              <div class="bar-fill" style="width: <?= $pct ?>%;"></div>
            </div>
            <span class="bar-count"><?= $c ?></span>
          </div>
        <?php endfor; ?>
      </div>

      <!-- CTA Box -->
      <div class="review-cta-box">
        <p style="font-size:13px; color:var(--text-muted); margin-bottom:12px;">Pernah membeli produk ini? Bagikan pendapatmu untuk sahabat SOREN lainnya!</p>
        <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('openReviewModal').click()">
          Beri Rating Sekarang
        </button>
      </div>
    </div>

    <!-- Filter Buttons -->
    <div class="reviews-filter-bar">
      <button type="button" class="filter-pill active" onclick="filterReviews(0, 0, this)">Semua (<?= count($reviews) ?>)</button>
      <button type="button" class="filter-pill" onclick="filterReviews(5, 0, this)">5 Bintang (<?= $rating_stat['star_5'] ?>)</button>
      <button type="button" class="filter-pill" onclick="filterReviews(4, 0, this)">4 Bintang (<?= $rating_stat['star_4'] ?>)</button>
      <button type="button" class="filter-pill" onclick="filterReviews(0, 1, this)">📷 Dengan Foto</button>
    </div>

    <!-- Reviews List Container -->
    <div id="reviewsList">
      <?php if (empty($reviews)): ?>
        <div style="text-align:center; padding: 40px 10px; color:var(--text-muted);">
          <div style="font-size: 36px; margin-bottom: 8px;">🌸</div>
          <p>Belum ada ulasan untuk produk ini. Jadilah yang pertama memberikan ulasan!</p>
        </div>
      <?php else: ?>
        <?php foreach ($reviews as $rev): ?>
          <div class="review-item" data-rating="<?= $rev['rating'] ?>" data-hasphoto="<?= !empty($rev['foto']) ? '1' : '0' ?>">
            <div class="review-header">
              <div class="reviewer-meta">
                <div class="reviewer-avatar">
                  <?= strtoupper(substr($rev['nama_user'], 0, 1)) ?>
                </div>
                <div>
                  <div class="reviewer-name">
                    <?= htmlspecialchars($rev['nama_user']) ?>
                    <span class="badge-verified">✓ Pembeli Terverifikasi</span>
                  </div>
                  <div class="review-date"><?= date('d F Y', strtotime($rev['created_at'])) ?></div>
                </div>
              </div>
              <div style="color:var(--star-color); font-size:14px;">
                <?= str_repeat('★', $rev['rating']) ?><?= str_repeat('☆', 5 - $rev['rating']) ?>
              </div>
            </div>

            <div class="review-content">
              <?= nl2br(htmlspecialchars($rev['ulasan'])) ?>
            </div>

            <?php if (!empty($rev['foto'])): ?>
              <div class="review-photos">
                <div class="review-photo-thumb" onclick="window.open('<?= UPLOADS_URL ?>reviews/<?= htmlspecialchars($rev['foto']) ?>', '_blank')">
                  <img src="<?= UPLOADS_URL ?>reviews/<?= htmlspecialchars($rev['foto']) ?>" alt="Foto Pembeli">
                </div>
              </div>
            <?php endif; ?>

            <!-- Balasan Admin jika ada -->
            <?php if (!empty($rev['balasan_admin'])): ?>
              <div class="admin-reply-box">
                <div class="admin-reply-header">
                  <span>🌸 Respon Resmi SOREN:</span>
                </div>
                <div class="admin-reply-text">
                  <?= nl2br(htmlspecialchars($rev['balasan_admin'])) ?>
                </div>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </section>

  <!-- Produk Terkait -->
  <?php if (!empty($related_products)): ?>
    <div style="margin-top: 60px;">
      <div class="section-header">
        <div class="section-subtitle">Koleksi Serupa</div>
        <h3 class="section-title" style="font-size: 26px;">Kamu Mungkin Juga Suka</h3>
      </div>
      <div class="product-grid">
        <?php foreach ($related_products as $rp): ?>
          <div class="product-card">
            <div class="product-thumb">
              <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $rp['id'] ?>">
                <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($rp['gambar']) ?>" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="<?= htmlspecialchars($rp['nama_produk']) ?>">
              </a>
              <!-- Overlay Transparan Menyatu dengan Foto Produk -->
              <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $rp['id'] ?>" class="product-thumb-overlay">
                <div class="product-category"><?= htmlspecialchars($rp['nama_kategori']) ?></div>
                <h4 class="product-name"><?= htmlspecialchars($rp['nama_produk']) ?></h4>
                <div class="product-price"><?= format_rupiah($rp['harga']) ?></div>
              </a>
            </div>
            <div class="product-info" style="padding: 10px 14px;">
              <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $rp['id'] ?>" class="btn btn-outline btn-block btn-sm">
                Lihat Detail
              </a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>
</div>

<!-- Modal Form Tulis Ulasan -->
<div class="modal-backdrop" id="reviewModal">
  <div class="modal-card">
    <button type="button" class="modal-close" id="closeReviewModal">✕</button>
    <h3 class="modal-title">Tulis Ulasan Produk</h3>
    <p style="font-size:13px; color:var(--text-muted); margin-bottom:16px;">
      Bagikan ulasan jujur kamu mengenai produk <b><?= htmlspecialchars($produk['nama_produk']) ?></b>
    </p>

    <form id="reviewForm" enctype="multipart/form-data">
      <input type="hidden" name="id_produk" value="<?= $produk['id'] ?>">
      <input type="hidden" name="rating" id="selectedRating" value="5">

      <!-- Star Rating Picker -->
      <div class="form-group">
        <label class="form-label">Beri Penilaian Bintang:</label>
        <div class="star-rating-select">
          <span class="star selected" data-val="1">★</span>
          <span class="star selected" data-val="2">★</span>
          <span class="star selected" data-val="3">★</span>
          <span class="star selected" data-val="4">★</span>
          <span class="star selected" data-val="5">★</span>
        </div>
      </div>

      <!-- Nama jika belum login -->
      <?php if (!is_logged_in()): ?>
        <div class="form-group">
          <label class="form-label">Nama Kamu:</label>
          <input type="text" name="nama" class="form-control" placeholder="Contoh: Sarah Az-Zahra" required>
        </div>
      <?php endif; ?>

      <!-- Isi Ulasan -->
      <div class="form-group">
        <label class="form-label">Ulasan Kamu:</label>
        <textarea name="ulasan" rows="4" class="form-control" placeholder="Ceritakan bagaimana kenyamanan bahan, keindahan warna, dan kerapian jahitannya..." required></textarea>
      </div>

      <!-- Unggah Foto Ulasan -->
      <div class="form-group">
        <label class="form-label">Unggah Foto Produk (Opsional):</label>
        <input type="file" name="foto" accept="image/*" class="form-control" style="font-size:12px;">
        <small style="color:var(--text-light); font-size:11px;">Format JPG, PNG, atau WEBP. Maks. 5MB.</small>
      </div>

      <button type="submit" class="btn btn-primary btn-block" id="btnSubmitReview" style="margin-top:16px;">
        Kirimkan Ulasan
      </button>
    </form>
  </div>
</div>

<script>
  let selectedColor = '<?= !empty($colors) ? trim($colors[0]) : "" ?>';

  function selectColor(btn, colorName) {
    document.querySelectorAll('.chip-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    selectedColor = colorName;
    const nameSpan = document.getElementById('selectedColorName');
    if (nameSpan) nameSpan.textContent = colorName;
  }

  function adjustQty(change) {
    const qtyInput = document.getElementById('productQty');
    let cur = parseInt(qtyInput.value) || 1;
    let max = parseInt(document.getElementById('stockCount').textContent) || 99;
    cur = Math.max(1, Math.min(cur + change, max));
    qtyInput.value = cur;
  }

  function handleAddToCart() {
    const qty = parseInt(document.getElementById('productQty').value) || 1;
    addToCart(<?= $produk['id'] ?>, qty, true);
  }

  function handleBuyNow() {
    const qty = parseInt(document.getElementById('productQty').value) || 1;
    addToCart(<?= $produk['id'] ?>, qty, false);
    setTimeout(() => {
      window.location.href = '<?= BASE_URL ?>checkout.php';
    }, 400);
  }

  // Filter Ulasan Sisi Klien
  function filterReviews(star, hasPhoto, btn) {
    document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');

    const items = document.querySelectorAll('.review-item');
    items.forEach(item => {
      const r = parseInt(item.getAttribute('data-rating'));
      const p = item.getAttribute('data-hasphoto') === '1';

      let show = true;
      if (star > 0 && r !== star) show = false;
      if (hasPhoto === 1 && !p) show = false;

      item.style.display = show ? 'block' : 'none';
    });
  }

  // Submit Ulasan Handler
  const reviewForm = document.getElementById('reviewForm');
  if (reviewForm) {
    reviewForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = document.getElementById('btnSubmitReview');
      btn.disabled = true;
      btn.textContent = 'Mengirimkan...';

      const formData = new FormData(this);

      fetch('api/review.php?action=submit', {
        method: 'POST',
        body: formData
      })
        .then(res => res.json())
        .then(data => {
          btn.disabled = false;
          btn.textContent = 'Kirimkan Ulasan';
          if (data.success) {
            document.getElementById('reviewModal').classList.remove('show');
            showToast('✨ ' + data.message);
            setTimeout(() => location.reload(), 1200);
          } else {
            alert(data.message);
          }
        })
        .catch(err => {
          btn.disabled = false;
          btn.textContent = 'Kirimkan Ulasan';
          alert('Terjadi kesalahan koneksi.');
        });
    });
  }
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
