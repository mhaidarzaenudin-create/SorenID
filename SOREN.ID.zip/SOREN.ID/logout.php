<?php
// logout.php - Customer Logout Handler
require_once __DIR__ . '/config/database.php';

unset($_SESSION['user_id']);
unset($_SESSION['user_name']);
unset($_SESSION['user_email']);
unset($_SESSION['user_role']);

header('Location: ' . BASE_URL);
exit;
