-- Pembaruan Database SOREN.ID
-- Menambahkan tabel ulasan_produk, chat_messages, dan seed data realistis

USE `soren.id`;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Tabel Ulasan Produk (Fitur Ulasan Produk)
CREATE TABLE IF NOT EXISTS `ulasan_produk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_produk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_pesanan` int(11) DEFAULT NULL,
  `rating` tinyint(1) NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
  `ulasan` text NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `balasan_admin` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `id_produk` (`id_produk`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `fk_ulasan_produk` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ulasan_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Pastikan produk bisa dihapus meski sudah dipakai di keranjang, detail pesanan, dan ulasan
ALTER TABLE `detail_pesanan`
  DROP FOREIGN KEY IF EXISTS `detail_pesanan_ibfk_2`;
ALTER TABLE `detail_pesanan`
  ADD CONSTRAINT `detail_pesanan_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`) ON DELETE CASCADE;

ALTER TABLE `keranjang`
  DROP FOREIGN KEY IF EXISTS `keranjang_ibfk_2`;
ALTER TABLE `keranjang`
  ADD CONSTRAINT `keranjang_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`) ON DELETE CASCADE;

-- 2. Tabel Chat Messages (Fitur Chat dengan Admin)
CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `pengirim` enum('user','admin') NOT NULL,
  `nama_pengirim` varchar(100) NOT NULL,
  `pesan` text NOT NULL,
  `dibaca` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 3. Seed Data Profil Toko
DELETE FROM `toko`;
INSERT INTO `toko` (`id`, `nama_toko`, `alamat`, `link_maps`, `jam_buka`, `jam_tutup`, `hari_operasional`) VALUES
(1, 'SOREN.ID Official Store', 'Jl. Trunojoyo No. 42, Citarum, Kec. Bandung Wetan, Kota Bandung, Jawa Barat 40115', 'https://maps.google.com/?q=Bandung', '09:00:00', '21:00:00', 'Senin - Minggu (Setiap Hari)');

-- 4. Seed Data Kontak & Sosial Media
DELETE FROM `kontak_sosmed`;
INSERT INTO `kontak_sosmed` (`id`, `nama_platform`, `username`, `link`, `nomor`) VALUES
(1, 'WhatsApp Customer Care', 'Soren Care Admin', 'https://wa.me/6281223344556', '0812-2334-4556'),
(2, 'Instagram', '@soren.id', 'https://www.instagram.com/soren.id_?stkn=MXRrZHF3eWRodnF0aQ==', NULL),
(3, 'TikTok', '@soren.official', 'https://tiktok.com/@soren.official', NULL),
(4, 'Shopee', 'soren.official', 'https://shopee.co.id', NULL);

-- 5. Seed Data Pengguna (Users)
-- Password default: "admin123" dan "user123"
DELETE FROM `users`;
INSERT INTO `users` (`id`, `nama`, `email`, `password`, `no_hp`, `alamat`, `role`, `created_at`) VALUES
(1, 'Admin Soren', 'admin@soren.id', '$2y$10$zvailtb.KlHCXijXsknAOeaD59ZR4.7OT0qtlztf2.0/f85HLLGgm', '081223344556', 'Head Office SOREN.ID Bandung', 'admin', NOW()),
(2, 'Anisa Rahma', 'anisa@gmail.com', '$2y$10$8pgf8SwLSl/JP/k.6U2AHupnTmoIfngdwVHa1T.nJodPS9BdFZnHC', '081399887766', 'Jl. Dago Asri No. 15, Coblong, Kota Bandung', 'user', NOW()),
(3, 'Siti Nurhaliza', 'siti@gmail.com', '$2y$10$8pgf8SwLSl/JP/k.6U2AHupnTmoIfngdwVHa1T.nJodPS9BdFZnHC', '081234567890', 'Komp. Bintaro Sektor 7, Tangerang Selatan', 'user', NOW());

-- 6. Seed Data Kategori Produk
DELETE FROM `kategori`;
INSERT INTO `kategori` (`id`, `nama_kategori`) VALUES
(1, 'Atasan'),
(2, 'Bawahan'),
(3, 'One Set');

-- 7. Seed Data Produk
DELETE FROM `produk`;
INSERT INTO `produk` (`id`, `id_kategori`, `nama_produk`, `harga`, `stok`, `ukuran`, `warna`, `deskripsi`, `gambar`, `created_at`) VALUES
(1, 1, 'Riri Oversized Knit Top', 129000.00, 35, 'S - XL', 'Cream, Beige, Grey, Dusty Pink', 'Atasan wanita bergaya Korean dengan bahan knit lembut yang fall nicely dan nyaman untuk daily wear. Potongan oversized dengan detail neckline yang feminin.', 'oversized-knit-top.jpg', NOW()),
(2, 1, 'Yuna Satin Blouse', 149000.00, 28, 'S - XL', 'Ivory, Rose, Brown, Black', 'Blouse satin dengan cut elegant dan warna soft pastel yang cocok dipadukan dengan pants atau skirt. Nyaman, ringan, dan terlihat premium.', 'satin-blouse.jpg', NOW()),
(3, 2, 'Nana Wide Leg Pants', 159000.00, 30, 'S - XL', 'Stone, Beige, Black, Olive', 'Celana wide leg dengan bahan premium yang flowy dan nyaman. Cocok untuk tampilan kasual hingga semi-formal dengan siluet Korea yang santai.', 'wide-leg-pants.jpg', NOW()),
(4, 2, 'Iris Pleated Skirt', 139000.00, 24, 'S - XL', 'Mauve, Cream, Navy, Stone', 'Rok plisket dengan bahan ringan tapi tetap jatuh rapi. Digunakan untuk tampilan feminine daily look dengan sentuhan Korea yang chic.', 'pleated-skirt.jpg', NOW()),
(5, 3, 'Seulgi Matching Set', 249000.00, 18, 'S - XL', 'Lilac, Beige, Peach, Grey', 'One set dengan kombinasi top dan bawahan yang bisa dipakai sebagai set lengkap. Bahan lembut, nyaman, dan cocok untuk look total yang effortless.', 'matching-set.jpg', NOW()),
(6, 3, 'Hana Two Piece Set', 289000.00, 16, 'S - XL', 'Cream, Olive, Cherry, Black', 'Set premium untuk tampilan minimal dan stylish. Dipadukan dengan detail sederhana namun tetap terlihat modern dan mengikuti tren street style Korea.', 'two-piece-set.jpg', NOW());

-- 8. Seed Data Ulasan Produk (Fitur Ulasan)
DELETE FROM `ulasan_produk`;
INSERT INTO `ulasan_produk` (`id`, `id_produk`, `id_user`, `id_pesanan`, `rating`, `ulasan`, `foto`, `balasan_admin`, `created_at`) VALUES
(1, 1, 2, NULL, 5, 'Masya Allah pashminanya bagus bangeeet! Berkilau elegan tapi nggak licin sama sekali pas dipakai. Warna rose taupe-nya manis banget di kulit. Bakal repeat order warna lain! 💕', 'review-1.jpg', 'Terima kasih banyak Kak Anisa atas ulasan manisnya! Senang sekali produk Soren bisa melengkapi penampilan Kakak ✨', NOW() - INTERVAL 3 DAY),
(2, 1, 3, NULL, 5, 'Jahitannya super rapi, bahan silk cradenza beneran adem dan jatuhnya mewah. Packaging box-nya juga wangi banget, serasa dapet kado. Makasih Soren!', 'review-2.jpg', 'Alhamdulillah, terima kasih Kak Siti! Ditunggu koleksi berikutnya ya kak 🥰', NOW() - INTERVAL 2 DAY),
(3, 3, 2, NULL, 5, 'Voal laser cut terenak yang pernah aku punya! Tegak di dahi seharian kena angin tetep stay on point. Warnanya persis kayak di foto katalog.', NULL, 'Terima kasih banyak atas kepercayaannya Kak! Kami selalu menjaga kualitas bahan terbaik untuk kenyamanan Kakak.', NOW() - INTERVAL 1 DAY),
(4, 6, 3, NULL, 4, 'Kemejanya adem pol! Bahan linennya lembut nggak gatal. Cuma untuk tinggiku 155cm agak kepanjangan dikit, tapi dimasuki celana jadi kece parah.', NULL, 'Terima kasih reviewnya Kak! Desain Aura Shirt memang oversized casual look, cocok banget di-styling tucked-in. Semoga suka ya Kak ❤️', NOW() - INTERVAL 5 HOUR);

-- 9. Seed Data Chat Messages (Fitur Chat Admin)
DELETE FROM `chat_messages`;
INSERT INTO `chat_messages` (`id`, `session_id`, `id_user`, `pengirim`, `nama_pengirim`, `pesan`, `dibaca`, `created_at`) VALUES
(1, 'guest_demo_session_1', NULL, 'user', 'Rania (Guest)', 'Halo Min-Soren, untuk Pashmina Silk warna Rose Taupe apakah ready stock kak?', 1, NOW() - INTERVAL 120 MINUTE),
(2, 'guest_demo_session_1', NULL, 'admin', 'Min-Soren (Admin)', 'Halo Kak Rania! Salam kenal ya kak. Betul kak, warna Rose Taupe ready stock dan siap kirim hari ini ya kak 💕', 1, NOW() - INTERVAL 115 MINUTE),
(3, 'guest_demo_session_1', NULL, 'user', 'Rania (Guest)', 'Wah mantap min, kalau kirim ke Surabaya estimasi berapa hari ya?', 1, NOW() - INTERVAL 110 MINUTE),
(4, 'guest_demo_session_1', NULL, 'admin', 'Min-Soren (Admin)', 'Untuk pengiriman ke Surabaya dengan Reguler estimasi 2-3 hari kerja kak. Yuk checkout mumpung ada promo Free Ongkir!', 1, NOW() - INTERVAL 108 MINUTE),
(5, 'user_chat_anisa', 2, 'user', 'Anisa Rahma', 'Min, pesanan aku yang tunik Naomi bisa request kartu ucapan ulang tahun nggak ya?', 1, NOW() - INTERVAL 40 MINUTE),
(6, 'user_chat_anisa', 2, 'admin', 'Min-Soren (Admin)', 'Tentu bisa banget Kak Anisa! Silakan tuliskan ucapan di catatan pesanan saat checkout atau kirimkan teksnya di sini ya kak, tim kami siap bantu bungkuskan eksklusif 🥰', 1, NOW() - INTERVAL 35 MINUTE);

-- 10. Seed Data Pesanan Contoh
DELETE FROM `pesanan`;
INSERT INTO `pesanan` (`id`, `id_user`, `tanggal_pesanan`, `total_harga`, `status`, `note`, `alamat_pengiriman`) VALUES
(1, 2, NOW() - INTERVAL 4 DAY, 158000.00, 'Selesai', 'Tolong packing rapi ya min buat kado', 'Jl. Dago Asri No. 15, Coblong, Kota Bandung - Penerima: Anisa (081399887766)'),
(2, 3, NOW() - INTERVAL 2 DAY, 149000.00, 'Dikirim', 'Warna Warm Beige', 'Komp. Bintaro Sektor 7, Tangerang Selatan - Penerima: Siti (081234567890)'),
(3, 2, NOW() - INTERVAL 3 HOUR, 79000.00, 'Menunggu Pembayaran', 'Packing bubble wrap tebal', 'Jl. Dago Asri No. 15, Coblong, Kota Bandung - Penerima: Anisa (081399887766)');

-- 11. Seed Data Detail Pesanan
DELETE FROM `detail_pesanan`;
INSERT INTO `detail_pesanan` (`id`, `id_pesanan`, `id_produk`, `jumlah`, `harga`, `subtotal`) VALUES
(1, 1, 1, 2, 79000.00, 158000.00),
(2, 2, 6, 1, 149000.00, 149000.00),
(3, 3, 1, 1, 79000.00, 79000.00);

-- 12. Seed Data Pembayaran Contoh
DELETE FROM `pembayaran`;
INSERT INTO `pembayaran` (`id`, `id_pesanan`, `metode`, `jumlah`, `status`, `bukti_pembayaran`, `tanggal_pembayaran`) VALUES
(1, 1, 'Transfer Bank BCA', 158000.00, 'Dibayar', 'bukti-bca-1.jpg', NOW() - INTERVAL 4 DAY),
(2, 2, 'QRIS', 149000.00, 'Dibayar', 'bukti-qris-2.jpg', NOW() - INTERVAL 2 DAY),
(3, 3, 'Transfer Bank Mandiri', 79000.00, 'Menunggu Konfirmasi', 'bukti-mandiri-3.jpg', NOW() - INTERVAL 2 HOUR);

-- 13. Seed Data Pemasukan
DELETE FROM `pemasukan`;
INSERT INTO `pemasukan` (`id`, `keterangan`, `jumlah`, `tanggal`, `id_pesanan`) VALUES
(1, 'Pembayaran Pesanan #1 - Anisa Rahma', 158000.00, CURDATE() - INTERVAL 4 DAY, 1),
(2, 'Pembayaran Pesanan #2 - Siti Nurhaliza', 149000.00, CURDATE() - INTERVAL 2 DAY, 2);

-- 14. Seed Data Kritik Saran
DELETE FROM `kritik_saran`;
INSERT INTO `kritik_saran` (`id`, `id_user`, `isi`, `tanggal`, `status`) VALUES
(1, 2, 'Koleksi warnanya ditambah lagi dong min, terutama warna sage green dan terracotta untuk pashmina silk cradenza!', NOW() - INTERVAL 5 DAY, 'Sudah Dibaca');

SET FOREIGN_KEY_CHECKS = 1;
