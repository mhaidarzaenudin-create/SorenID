<?php
// checkout.php - Checkout & Payment Selection for SOREN.ID
$page_title = 'Checkout Pesanan';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$items = get_cart_items($pdo);
if (empty($items)) {
    header('Location: ' . BASE_URL . 'keranjang.php');
    exit;
}

// ── Wajib login sebelum checkout ───────────────────────────────────────────
if (!is_logged_in()) {
    header('Location: ' . BASE_URL . 'login.php?redirect=checkout.php');
    exit;
}

$subtotal = 0;
foreach ($items as $it) {
    $subtotal += ($it['harga'] * $it['jumlah']);
}

$ongkir = ($subtotal >= 150000) ? 0 : 15000;
$grand_total = $subtotal + $ongkir;

$user = current_user();
$error = '';

// Proses Simpan Pesanan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama    = clean_input($_POST['nama']    ?? '');
    $no_hp   = clean_input($_POST['no_hp']   ?? '');
    $email   = clean_input($_POST['email']   ?? '');
    $alamat  = clean_input($_POST['alamat']  ?? '');
    $catatan = clean_input($_POST['catatan'] ?? '');
    $metode  = clean_input($_POST['metode']  ?? 'Transfer Bank BCA');

    if (empty($nama) || empty($no_hp) || empty($alamat)) {
        $error = 'Harap lengkapi semua kolom bertanda bintang (*).';
    } else {
        try {
            $pdo->beginTransaction();

            $user_id = null;
            if (is_logged_in()) {
                $user_id = $_SESSION['user_id'];
            } else {
                $st = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $st->execute([$email]);
                $found = $st->fetch();
                if ($found) {
                    $user_id = $found['id'];
                } else {
                    $pwd = password_hash('user123', PASSWORD_DEFAULT);
                    $ins = $pdo->prepare("INSERT INTO users (nama, email, password, no_hp, alamat, role) VALUES (?, ?, ?, ?, ?, 'user')");
                    $ins->execute([$nama, $email, $pwd, $no_hp, $alamat]);
                    $user_id = $pdo->lastInsertId();
                }
            }

            $alamat_lengkap = $alamat . " | Penerima: " . $nama . " (" . $no_hp . ")";

            $ins_pesanan = $pdo->prepare("
                INSERT INTO pesanan (id_user, tanggal_pesanan, total_harga, status, note, alamat_pengiriman)
                VALUES (?, NOW(), ?, 'Menunggu Pembayaran', ?, ?)
            ");
            $ins_pesanan->execute([$user_id, $grand_total, $catatan, $alamat_lengkap]);
            $pesanan_id = $pdo->lastInsertId();

            $ins_detail = $pdo->prepare("
                INSERT INTO detail_pesanan (id_pesanan, id_produk, jumlah, harga, subtotal)
                VALUES (?, ?, ?, ?, ?)
            ");
            $up_stok = $pdo->prepare("UPDATE produk SET stok = GREATEST(0, stok - ?) WHERE id = ?");

            foreach ($items as $it) {
                $item_sub = $it['harga'] * $it['jumlah'];
                $ins_detail->execute([$pesanan_id, $it['produk_id'], $it['jumlah'], $it['harga'], $item_sub]);
                $up_stok->execute([$it['jumlah'], $it['produk_id']]);
            }

            $ins_bayar = $pdo->prepare("
                INSERT INTO pembayaran (id_pesanan, metode, jumlah, status)
                VALUES (?, ?, ?, 'Belum Dibayar')
            ");
            $ins_bayar->execute([$pesanan_id, $metode, $grand_total]);

            if (is_logged_in()) {
                $pdo->prepare("DELETE FROM keranjang WHERE id_user = ?")->execute([$_SESSION['user_id']]);
            } else {
                unset($_SESSION['cart']);
            }

            $pdo->commit();

            if (!is_logged_in()) {
                $_SESSION['user_id']    = $user_id;
                $_SESSION['user_name']  = $nama;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_role']  = 'user';
            }

            header("Location: " . BASE_URL . "pesanan-sukses.php?id=" . $pesanan_id);
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Gagal memproses pesanan: ' . $e->getMessage();
        }
    }
}

$default_nama   = '';
$default_email  = '';
$default_hp     = '';
$default_alamat = '';
if (is_logged_in()) {
    $st = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $st->execute([$_SESSION['user_id']]);
    $u_data = $st->fetch();
    if ($u_data) {
        $default_nama   = $u_data['nama'];
        $default_email  = $u_data['email'];
        $default_hp     = $u_data['no_hp']   ?? '';
        $default_alamat = $u_data['alamat']  ?? '';
    }
}

include __DIR__ . '/includes/header.php';
?>

<style>
/* ── Checkout Enhancement Styles ────────────────── */

/* Progress indicator */
.co-progress {
  display: flex; align-items: center;
  justify-content: center;
  gap: 0; padding: 22px 0 0;
  margin-bottom: 32px;
}
.co-step {
  display: flex; align-items: center; gap: 9px;
  font-size: 13px; font-weight: 600;
  color: var(--text-light);
}
.co-step.done { color: var(--primary-dark); }
.co-step-num {
  width: 30px; height: 30px; border-radius: 50%;
  border: 2px solid currentColor;
  display: flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 700;
  transition: all .3s;
}
.co-step.done .co-step-num {
  background: var(--primary-dark);
  border-color: var(--primary-dark);
  color: #fff;
}
.co-step-line {
  width: 56px; height: 2px;
  background: var(--border-color); margin: 0 6px;
}

/* Card */
.checkout-card {
  background: #fff;
  border: 1px solid var(--border-color);
  border-radius: 20px;
  padding: 32px;
  margin-bottom: 20px;
  box-shadow: 0 4px 20px rgba(122,77,94,0.05);
  transition: box-shadow .3s;
}
.checkout-card:hover {
  box-shadow: 0 8px 30px rgba(122,77,94,0.09);
}

/* Step header */
.checkout-step-header {
  display: flex; align-items: flex-start; gap: 18px;
  margin-bottom: 28px; padding-bottom: 20px;
  border-bottom: 1px solid var(--border-light);
}
.step-badge {
  width: 44px; height: 44px; border-radius: 14px;
  background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
  color: #fff;
  font-family: var(--font-serif); font-size: 20px; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 6px 16px rgba(197,131,133,0.35);
}
.step-title-group h3 {
  font-family: var(--font-serif); font-size: 20px;
  color: var(--text-dark); margin-bottom: 3px;
}
.step-title-group p { font-size: 13px; color: var(--text-muted); }

/* Floating label */
.co-float { position: relative; margin-bottom: 20px; }
.co-float input,
.co-float textarea {
  width: 100%;
  padding: 18px 40px 8px 16px;
  border: 1.5px solid var(--border-color);
  border-radius: var(--radius-md);
  font-size: 14px; font-family: var(--font-sans);
  background: #fdfafa; color: var(--text-dark);
  outline: none; box-sizing: border-box;
  transition: border-color .2s, background .2s, box-shadow .2s;
}
.co-float textarea {
  resize: vertical; min-height: 90px; padding-top: 22px;
}
.co-float input:focus,
.co-float textarea:focus {
  border-color: var(--primary); background: #fff;
  box-shadow: 0 0 0 3px rgba(217,163,176,0.18);
}
.co-float label {
  position: absolute; left: 16px; top: 14px;
  font-size: 14px; color: #b5a4ab;
  pointer-events: none; transition: .18s ease;
  transform-origin: left top;
}
.co-float input:focus ~ label,
.co-float input:not(:placeholder-shown) ~ label,
.co-float textarea:focus ~ label,
.co-float textarea:not(:placeholder-shown) ~ label {
  top: 6px; font-size: 10.5px; letter-spacing: .4px;
  color: var(--primary-dark); font-weight: 700;
  text-transform: uppercase;
}
.co-float .fi {
  position: absolute; right: 14px; top: 50%;
  transform: translateY(-50%);
  font-size: 15px; color: #d9a3b0; pointer-events: none;
}
.co-float textarea ~ .fi { top: 18px; transform: none; }

.co-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

.form-hint {
  display: flex; align-items: flex-start; gap: 6px;
  margin-top: 7px; font-size: 12px; color: var(--text-muted); line-height: 1.4;
}

/* Page title row */
.co-page-title {
  display: flex; align-items: center;
  justify-content: space-between; flex-wrap: wrap;
  gap: 12px; margin-bottom: 28px;
}
.co-page-title h1 {
  font-family: var(--font-serif); font-size: 32px;
  color: var(--text-dark); margin: 0;
}
.co-secure-badge {
  display: inline-flex; align-items: center; gap: 7px;
  background: #e8f5e9; color: #2e7d32;
  border: 1px solid #c8e6c9;
  font-size: 12px; font-weight: 700;
  padding: 7px 14px; border-radius: var(--radius-full);
}

@media (max-width: 640px) {
  .co-2col { grid-template-columns: 1fr; }
  .checkout-card { padding: 20px 18px; }
  .co-page-title h1 { font-size: 24px; }
}
</style>

<div class="container" style="padding-top:24px; padding-bottom:70px; max-width:1100px;">

  <!-- Breadcrumb -->
  <div class="breadcrumb" style="margin-bottom:16px;">
    <a href="<?= BASE_URL ?>">Beranda</a>
    <span>/</span>
    <a href="<?= BASE_URL ?>keranjang.php">Keranjang</a>
    <span>/</span>
    <span style="color:var(--primary-dark); font-weight:700;">Checkout</span>
  </div>

  <!-- Progress Steps -->
  <div class="co-progress">
    <div class="co-step done">
      <div class="co-step-num">✓</div>
      <span>Keranjang</span>
    </div>
    <div class="co-step-line"></div>
    <div class="co-step done">
      <div class="co-step-num">2</div>
      <span>Data Pengiriman</span>
    </div>
    <div class="co-step-line"></div>
    <div class="co-step">
      <div class="co-step-num">3</div>
      <span>Konfirmasi Bayar</span>
    </div>
  </div>

  <!-- Title row -->
  <div class="co-page-title">
    <h1>Checkout Pesananmu ✨</h1>
    <span class="co-secure-badge">🔒 Transaksi Aman & Terenkripsi</span>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background:#fde8e8; color:#c81e1e; padding:16px 20px; border-radius:14px; margin-bottom:24px; font-size:14px; border:1px solid #f7cacc; display:flex; align-items:center; gap:12px;">
      <span style="font-size:20px; flex-shrink:0;">⚠️</span>
      <span><?= htmlspecialchars($error) ?></span>
    </div>
  <?php endif; ?>

  <form method="POST" action="" id="checkoutForm">
    <div class="checkout-layout">

      <!-- ═══ LEFT ═══ -->
      <div>

        <!-- Step 1: Penerima & Pengiriman -->
        <div class="checkout-card">
          <div class="checkout-step-header">
            <div class="step-badge">1</div>
            <div class="step-title-group">
              <h3>Data Penerima & Pengiriman</h3>
              <p>Isi dengan lengkap agar paket sampai tepat ke tanganmu.</p>
            </div>
          </div>

          <div class="co-2col">
            <div class="co-float">
              <input type="text" name="nama" id="coNama" placeholder=" "
                     value="<?= htmlspecialchars($default_nama) ?>" required autocomplete="name">
              <label for="coNama">Nama Lengkap Penerima *</label>
              <span class="fi">👤</span>
            </div>
            <div class="co-float">
              <input type="tel" name="no_hp" id="coHp" placeholder=" "
                     value="<?= htmlspecialchars($default_hp) ?>" required autocomplete="tel">
              <label for="coHp">Nomor WhatsApp / HP *</label>
              <span class="fi">📱</span>
            </div>
          </div>

          <div class="co-float">
            <input type="email" name="email" id="coEmail" placeholder=" "
                   value="<?= htmlspecialchars($default_email) ?>" required autocomplete="email">
            <label for="coEmail">Alamat Email *</label>
            <span class="fi">✉️</span>
            <div class="form-hint">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
              Konfirmasi pesanan & nomor resi kurir dikirim otomatis ke email ini.
            </div>
          </div>

          <div class="co-float">
            <textarea name="alamat" id="coAlamat" placeholder=" " rows="3"
                      required><?= htmlspecialchars($default_alamat) ?></textarea>
            <label for="coAlamat">Alamat Lengkap Pengiriman *</label>
            <span class="fi">📍</span>
            <div class="form-hint">
              Nama jalan, nomor rumah, RT/RW, kelurahan, kecamatan, kota, kode pos.
            </div>
          </div>

          <div class="co-float" style="margin-bottom:0;">
            <textarea name="catatan" id="coCatatan" placeholder=" " rows="2"></textarea>
            <label for="coCatatan">Catatan Pesanan (Opsional)</label>
            <span class="fi">📝</span>
          </div>
        </div>

        <!-- Step 2: Metode Pembayaran -->
        <div class="checkout-card">
          <div class="checkout-step-header">
            <div class="step-badge">2</div>
            <div class="step-title-group">
              <h3>Pilih Metode Pembayaran</h3>
              <p>Semua metode aman. QRIS mendukung konfirmasi instan dari semua e-wallet.</p>
            </div>
          </div>

          <div class="payment-methods-grid">
            <label class="payment-method-card active" onclick="handlePaymentSelect(this,'bca')">
              <input type="radio" name="metode" value="Transfer Bank BCA" checked>
              <div class="custom-radio"></div>
              <div class="payment-details">
                <div class="payment-head-row">
                  <span class="payment-name">Transfer Bank BCA</span>
                  <span class="payment-badge badge-bca">BCA Virtual / Manual</span>
                </div>
                <p class="payment-desc">No. Rek: <b>123-456-7890</b> a/n <b>SOREN INDONESIA</b>. Verifikasi otomatis.</p>
              </div>
            </label>

            <label class="payment-method-card" onclick="handlePaymentSelect(this,'mandiri')">
              <input type="radio" name="metode" value="Transfer Bank Mandiri">
              <div class="custom-radio"></div>
              <div class="payment-details">
                <div class="payment-head-row">
                  <span class="payment-name">Transfer Bank Mandiri</span>
                  <span class="payment-badge badge-mandiri">Bank Mandiri</span>
                </div>
                <p class="payment-desc">No. Rek: <b>131-00-9876543</b> a/n <b>SOREN INDONESIA</b>.</p>
              </div>
            </label>

            <label class="payment-method-card" id="qrisCard" onclick="handlePaymentSelect(this,'qris')">
              <input type="radio" name="metode" value="QRIS">
              <div class="custom-radio"></div>
              <div class="payment-details">
                <div class="payment-head-row">
                  <span class="payment-name">QRIS — Semua E-Wallet & M-Banking</span>
                  <span class="payment-badge badge-qris">QRIS Resmi</span>
                </div>
                <p class="payment-desc">GoPay, OVO, DANA, ShopeePay, BCA Mobile, Livin' Mandiri, BRImo, LinkAja, dll.</p>
                <div class="qris-checkout-preview" id="qrisPreviewBox" onclick="event.stopPropagation()">
                  <div style="background:linear-gradient(180deg,#fff7f7,#fff);border:1.5px solid #ffccd0;border-radius:14px;padding:18px;text-align:center;">
                    <div style="display:inline-flex;align-items:center;gap:6px;background:#e1251b;color:#fff;padding:4px 12px;border-radius:6px;font-size:11px;font-weight:800;letter-spacing:1px;margin-bottom:8px;">🔴 QRIS NASIONAL</div>
                    <div style="font-size:15px;font-weight:800;color:#1a1a1a;margin-top:2px;">SOREN.ID OFFICIAL</div>
                    <div style="font-size:11px;color:#666;margin-bottom:14px;">NMID: ID1020240928019 • Aman & Instan</div>
                    <div style="background:#fff;padding:12px;border-radius:12px;display:inline-block;border:1px solid #ebdbe2;box-shadow:0 6px 16px rgba(0,0,0,0.06);">
                      <div id="checkoutQrisContainer" style="display:flex;justify-content:center;"></div>
                    </div>
                    <div style="margin-top:12px;">
                      <div style="font-size:12px;color:var(--text-muted);">Total Tagihan:</div>
                      <div style="font-size:20px;font-weight:800;color:var(--primary-dark);"><?= format_rupiah($grand_total) ?></div>
                    </div>
                    <div style="margin-top:10px;display:flex;flex-wrap:wrap;justify-content:center;gap:6px;">
                      <span class="wallet-chip">GoPay</span><span class="wallet-chip">OVO</span>
                      <span class="wallet-chip">DANA</span><span class="wallet-chip">ShopeePay</span>
                      <span class="wallet-chip">BCA Mobile</span><span class="wallet-chip">Livin'</span>
                    </div>
                  </div>
                </div>
              </div>
            </label>

            <label class="payment-method-card" onclick="handlePaymentSelect(this,'cod')">
              <input type="radio" name="metode" value="Cash On Delivery (COD)">
              <div class="custom-radio"></div>
              <div class="payment-details">
                <div class="payment-head-row">
                  <span class="payment-name">Cash on Delivery (COD)</span>
                  <span class="payment-badge badge-cod">Bayar di Tempat</span>
                </div>
                <p class="payment-desc">Bayar tunai ke kurir saat paket sampai di tanganmu.</p>
              </div>
            </label>
          </div>
        </div>
      </div>

      <!-- ═══ RIGHT: Order Summary ═══ -->
      <div>
        <div class="order-summary-box" style="position:sticky;top:90px;">
          <div class="order-summary-header">
            <span>Ringkasan Pesanan</span>
            <span style="font-size:12.5px;color:var(--primary);font-weight:700;background:var(--primary-light);padding:3px 10px;border-radius:20px;">
              <?= count($items) ?> item
            </span>
          </div>

          <div style="max-height:260px;overflow-y:auto;padding-right:4px;margin-bottom:16px;">
            <?php foreach ($items as $it):
              $thumb = !empty($it['gambar'])
                ? BASE_URL . 'uploads/' . htmlspecialchars($it['gambar'])
                : ASSETS_URL . 'images/products/placeholder.jpg';
            ?>
              <div class="summary-item-row">
                <img src="<?= $thumb ?>" alt="<?= htmlspecialchars($it['nama_produk']) ?>"
                     class="summary-item-thumb"
                     onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2260%22 height=%2270%22%3E%3Crect width=%2260%22 height=%2270%22 fill=%22%23f3e8ee%22/%3E%3C/svg%3E'">
                <div class="summary-item-info">
                  <div class="summary-item-title"><?= htmlspecialchars($it['nama_produk']) ?></div>
                  <div class="summary-item-meta">
                    <?= $it['jumlah'] ?> pcs
                    <?= !empty($it['warna'])  ? ' • '.htmlspecialchars($it['warna'])              : '' ?>
                    <?= !empty($it['ukuran']) ? ' ('.htmlspecialchars($it['ukuran']).')'           : '' ?>
                  </div>
                </div>
                <div class="summary-item-price"><?= format_rupiah($it['harga'] * $it['jumlah']) ?></div>
              </div>
            <?php endforeach; ?>
          </div>

          <div class="summary-breakdown">
            <div class="summary-breakdown-row">
              <span>Subtotal</span>
              <span style="font-weight:600;"><?= format_rupiah($subtotal) ?></span>
            </div>
            <div class="summary-breakdown-row">
              <span style="display:flex;align-items:center;gap:6px;">
                Ongkos Kirim
                <?php if ($ongkir === 0): ?>
                  <span style="background:#e6f7ec;color:#0f8a3c;font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;">GRATIS</span>
                <?php endif; ?>
              </span>
              <?php if ($ongkir === 0): ?>
                <span style="color:#0f8a3c;font-weight:700;">Rp 0</span>
              <?php else: ?>
                <span style="font-weight:600;"><?= format_rupiah($ongkir) ?></span>
              <?php endif; ?>
            </div>
            <div class="summary-total-row">
              <div>
                <div style="font-size:12.5px;color:var(--text-muted);">Total Pembayaran</div>
                <div style="font-size:24px;font-family:var(--font-serif);font-weight:700;color:var(--primary-dark);margin-top:2px;">
                  <?= format_rupiah($grand_total) ?>
                </div>
              </div>
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-block"
                  style="margin-top:22px;padding:16px;font-size:14.5px;font-weight:700;border-radius:14px;letter-spacing:.4px;box-shadow:0 10px 24px rgba(217,163,176,0.4);">
            Buat Pesanan Sekarang →
          </button>

          <p style="text-align:center;font-size:11px;color:var(--text-light);margin-top:10px;line-height:1.5;">
            Dengan melanjutkan, kamu menyetujui Ketentuan Pembelian SOREN.ID
          </p>

          <div class="summary-trust-badges">
            <div class="trust-badge-item"><span>🛡️</span><span>100% Original</span></div>
            <div class="trust-badge-item"><span>⚡</span><span>Kirim Hari Ini</span></div>
            <div class="trust-badge-item"><span>🔄</span><span>Retur 7 Hari</span></div>
            <div class="trust-badge-item"><span>💬</span><span>CS 24/7</span></div>
          </div>
        </div>
      </div>

    </div>
  </form>
</div>

<script src="<?= ASSETS_URL ?>js/qrcode.min.js"></script>
<script>
let qrisInstance = null;
const qrisPayload = "00020101021226680016ID.CO.QRIS.WWW01189360091100202409280215ID10202409280190303UMI51440014ID.LINKAJA.WWW0215ID10202409280190303UMI520458125303360540<?= $grand_total ?>5802ID5908SOREN.ID6007BANDUNG61054011562070703A016304";

function handlePaymentSelect(el, key) {
  document.querySelectorAll('.payment-method-card').forEach(c => {
    c.classList.remove('active');
    const r = c.querySelector('input[type="radio"]');
    if (r) r.checked = false;
  });
  el.classList.add('active');
  const r = el.querySelector('input[type="radio"]');
  if (r) r.checked = true;
  if (key === 'qris') renderCheckoutQris();
}

function renderCheckoutQris() {
  const c = document.getElementById('checkoutQrisContainer');
  if (!c || qrisInstance) return;
  c.innerHTML = '';
  try {
    if (typeof QRCode !== 'undefined') {
      qrisInstance = new QRCode(c, { text: qrisPayload, width:170, height:170, correctLevel: QRCode.CorrectLevel.M });
    } else {
      c.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(qrisPayload)}" style="width:170px;height:170px;">`;
    }
  } catch(e) {
    c.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(qrisPayload)}" style="width:170px;height:170px;">`;
  }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
