<?php
// api/review.php - Product Review Submission & Fetching API
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$action = $_GET['action'] ?? '';

try {
    if ($action === 'submit') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Metode request tidak diizinkan']);
            exit;
        }

        $id_produk = (int)($_POST['id_produk'] ?? 0);
        $rating = (int)($_POST['rating'] ?? 5);
        $ulasan = clean_input($_POST['ulasan'] ?? '');

        if ($id_produk <= 0) {
            echo json_encode(['success' => false, 'message' => 'Produk tidak valid']);
            exit;
        }

        if ($rating < 1 || $rating > 5) {
            echo json_encode(['success' => false, 'message' => 'Harap berikan rating antara 1 hingga 5 bintang']);
            exit;
        }

        if (empty($ulasan)) {
            echo json_encode(['success' => false, 'message' => 'Harap tuliskan ulasan pengalaman Anda']);
            exit;
        }

        // Tentukan user ID: jika login gunakan user_id, jika belum login buatkan/gunakan akun tamu
        $user_id = null;
        if (is_logged_in()) {
            $user_id = $_SESSION['user_id'];
        } else {
            // Jika tamu memasukkan nama
            $guest_name = clean_input($_POST['nama'] ?? 'Pelanggan');
            $guest_email = clean_input($_POST['email'] ?? 'guest_' . time() . '@soren.id');

            // Cek apakah email user sudah ada
            $st = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $st->execute([$guest_email]);
            $found = $st->fetch();

            if ($found) {
                $user_id = $found['id'];
            } else {
                $pwd = password_hash('guest123', PASSWORD_DEFAULT);
                $ins = $pdo->prepare("INSERT INTO users (nama, email, password, role) VALUES (?, ?, ?, 'user')");
                $ins->execute([$guest_name, $guest_email, $pwd]);
                $user_id = $pdo->lastInsertId();
            }
        }

        // Handle upload foto review jika ada
        $foto_filename = null;
        if (!empty($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $upload = upload_image($_FILES['foto'], __DIR__ . '/../uploads/reviews', 'rev');
            if ($upload['success']) {
                $foto_filename = $upload['filename'];
            }
        }

        // Insert ke ulasan_produk
        $stmt = $pdo->prepare("
            INSERT INTO ulasan_produk (id_produk, id_user, rating, ulasan, foto, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$id_produk, $user_id, $rating, $ulasan, $foto_filename]);

        echo json_encode([
            'success' => true,
            'message' => 'Terima kasih! Ulasan Anda berhasil diterbitkan 💕'
        ]);
        exit;
    }

    if ($action === 'list') {
        $id_produk = (int)($_GET['id_produk'] ?? 0);
        $filter_star = (int)($_GET['star'] ?? 0);
        $has_photo = (int)($_GET['photo'] ?? 0);

        $sql = "
            SELECT u.id, u.rating, u.ulasan, u.foto, u.balasan_admin, 
                   DATE_FORMAT(u.created_at, '%d %M %Y') as tanggal,
                   COALESCE(usr.nama, 'Pelanggan Terverifikasi') as nama_user
            FROM ulasan_produk u
            LEFT JOIN users usr ON u.id_user = usr.id
            WHERE u.id_produk = ?
        ";
        $params = [$id_produk];

        if ($filter_star > 0 && $filter_star <= 5) {
            $sql .= " AND u.rating = ?";
            $params[] = $filter_star;
        }

        if ($has_photo === 1) {
            $sql .= " AND u.foto IS NOT NULL AND u.foto != ''";
        }

        $sql .= " ORDER BY u.created_at DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $reviews = $stmt->fetchAll();

        echo json_encode([
            'success' => true,
            'reviews' => $reviews
        ]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Aksi tidak valid']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
