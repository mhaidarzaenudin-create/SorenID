<?php
// api/chat.php - Real-time Live Chat API Endpoint between Customers & Admin
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$action = $_GET['action'] ?? '';

try {
    // 1. Ambil pesan untuk customer (berdasarkan login atau guest session)
    if ($action === 'get_messages') {
        $session_id = $_SESSION['chat_session_id'] ?? '';
        $user_id = is_logged_in() ? $_SESSION['user_id'] : null;

        if ($user_id) {
            $stmt = $pdo->prepare("
                SELECT id, pengirim, nama_pengirim, pesan, dibaca, 
                       DATE_FORMAT(created_at, '%H:%i') as waktu, created_at
                FROM chat_messages
                WHERE id_user = ? OR session_id = ?
                ORDER BY created_at ASC
            ");
            $stmt->execute([$user_id, $session_id]);
        } else {
            $stmt = $pdo->prepare("
                SELECT id, pengirim, nama_pengirim, pesan, dibaca, 
                       DATE_FORMAT(created_at, '%H:%i') as waktu, created_at
                FROM chat_messages
                WHERE session_id = ?
                ORDER BY created_at ASC
            ");
            $stmt->execute([$session_id]);
        }

        $messages = $stmt->fetchAll();

        // Tandai pesan dari admin sebagai dibaca oleh customer
        if (!empty($messages)) {
            if ($user_id) {
                $up = $pdo->prepare("UPDATE chat_messages SET dibaca = 1 WHERE (id_user = ? OR session_id = ?) AND pengirim = 'admin'");
                $up->execute([$user_id, $session_id]);
            } else {
                $up = $pdo->prepare("UPDATE chat_messages SET dibaca = 1 WHERE session_id = ? AND pengirim = 'admin'");
                $up->execute([$session_id]);
            }
        }

        echo json_encode([
            'success' => true,
            'messages' => $messages
        ]);
        exit;
    }

    // 2. Kirim pesan dari customer
    if ($action === 'send_message') {
        $pesan = clean_input($_POST['pesan'] ?? '');
        if (empty($pesan)) {
            echo json_encode(['success' => false, 'message' => 'Pesan tidak boleh kosong']);
            exit;
        }

        $session_id = $_SESSION['chat_session_id'] ?? '';
        $user_id = is_logged_in() ? $_SESSION['user_id'] : null;
        $nama_pengirim = is_logged_in() ? ($_SESSION['user_name'] ?? 'Pelanggan') : 'Pelanggan (Tamu)';

        $stmt = $pdo->prepare("
            INSERT INTO chat_messages (session_id, id_user, pengirim, nama_pengirim, pesan, dibaca, created_at)
            VALUES (?, ?, 'user', ?, ?, 0, NOW())
        ");
        $stmt->execute([$session_id, $user_id, $nama_pengirim, $pesan]);

        echo json_encode(['success' => true, 'message' => 'Pesan terkirim']);
        exit;
    }

    // 3. Admin: Ambil semua thread chat yang aktif
    if ($action === 'admin_get_threads') {
        if (!is_admin()) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit;
        }

        // Ambil pesan unik per customer (user_id atau session_id)
        $query = "
            SELECT 
                COALESCE(CONCAT('user_', cm.id_user), cm.session_id) as thread_key,
                MAX(cm.id) as last_msg_id,
                MAX(cm.created_at) as last_activity,
                SUM(CASE WHEN cm.pengirim = 'user' AND cm.dibaca = 0 THEN 1 ELSE 0 END) as unread_count,
                MAX(CASE WHEN cm.pengirim = 'user' THEN cm.nama_pengirim ELSE 'Pelanggan' END) as customer_name
            FROM chat_messages cm
            GROUP BY COALESCE(CONCAT('user_', cm.id_user), cm.session_id)
            ORDER BY last_activity DESC
        ";
        $threads = $pdo->query($query)->fetchAll();

        // Ambil teks pesan terakhir untuk tiap thread
        foreach ($threads as &$t) {
            $st = $pdo->prepare("SELECT pesan, pengirim, DATE_FORMAT(created_at, '%H:%i') as waktu FROM chat_messages WHERE id = ?");
            $st->execute([$t['last_msg_id']]);
            $last = $st->fetch();
            $t['last_message'] = $last['pesan'] ?? '';
            $t['last_sender'] = $last['pengirim'] ?? '';
            $t['time_formatted'] = $last['waktu'] ?? '';
        }

        echo json_encode(['success' => true, 'threads' => $threads]);
        exit;
    }

    // 4. Admin: Ambil seluruh pesan dalam satu thread
    if ($action === 'admin_get_thread_messages') {
        if (!is_admin()) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit;
        }

        $thread_key = $_GET['thread_key'] ?? '';
        if (empty($thread_key)) {
            echo json_encode(['success' => false, 'message' => 'Thread tidak valid']);
            exit;
        }

        if (str_starts_with($thread_key, 'user_')) {
            $uid = (int)str_replace('user_', '', $thread_key);
            $stmt = $pdo->prepare("
                SELECT id, pengirim, nama_pengirim, pesan, dibaca, 
                       DATE_FORMAT(created_at, '%d/%m %H:%i') as waktu, created_at
                FROM chat_messages
                WHERE id_user = ?
                ORDER BY created_at ASC
            ");
            $stmt->execute([$uid]);

            // Tandai sudah dibaca
            $pdo->prepare("UPDATE chat_messages SET dibaca = 1 WHERE id_user = ? AND pengirim = 'user'")->execute([$uid]);
        } else {
            $stmt = $pdo->prepare("
                SELECT id, pengirim, nama_pengirim, pesan, dibaca, 
                       DATE_FORMAT(created_at, '%d/%m %H:%i') as waktu, created_at
                FROM chat_messages
                WHERE session_id = ?
                ORDER BY created_at ASC
            ");
            $stmt->execute([$thread_key]);

            // Tandai sudah dibaca
            $pdo->prepare("UPDATE chat_messages SET dibaca = 1 WHERE session_id = ? AND pengirim = 'user'")->execute([$thread_key]);
        }

        $messages = $stmt->fetchAll();
        echo json_encode(['success' => true, 'messages' => $messages]);
        exit;
    }

    // 5. Admin: Kirim balasan ke customer dalam thread
    if ($action === 'admin_send_message') {
        if (!is_admin()) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit;
        }

        $thread_key = $_POST['thread_key'] ?? '';
        $pesan = clean_input($_POST['pesan'] ?? '');

        if (empty($thread_key) || empty($pesan)) {
            echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
            exit;
        }

        $admin_name = 'Min-Soren (Admin)';
        if (str_starts_with($thread_key, 'user_')) {
            $uid = (int)str_replace('user_', '', $thread_key);
            $stmt = $pdo->prepare("
                INSERT INTO chat_messages (session_id, id_user, pengirim, nama_pengirim, pesan, dibaca, created_at)
                VALUES (NULL, ?, 'admin', ?, ?, 0, NOW())
            ");
            $stmt->execute([$uid, $admin_name, $pesan]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO chat_messages (session_id, id_user, pengirim, nama_pengirim, pesan, dibaca, created_at)
                VALUES (?, NULL, 'admin', ?, ?, 0, NOW())
            ");
            $stmt->execute([$thread_key, $admin_name, $pesan]);
        }

        echo json_encode(['success' => true, 'message' => 'Balasan berhasil dikirim']);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Aksi tidak valid']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
