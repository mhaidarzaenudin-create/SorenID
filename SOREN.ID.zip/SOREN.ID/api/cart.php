<?php
// api/cart.php - AJAX Cart Operations Endpoint
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$action = $_GET['action'] ?? '';

try {
    if ($action === 'get') {
        $items = get_cart_items($pdo);
        $total_count = get_cart_count($pdo);
        $subtotal = 0;
        foreach ($items as $it) {
            $subtotal += ($it['harga'] * $it['jumlah']);
        }
        echo json_encode([
            'success' => true,
            'items' => $items,
            'total_count' => $total_count,
            'subtotal' => $subtotal,
            'subtotal_formatted' => format_rupiah($subtotal)
        ]);
        exit;
    }

    if ($action === 'add') {
        $produk_id = (int)($_POST['produk_id'] ?? 0);
        $jumlah = max(1, (int)($_POST['jumlah'] ?? 1));

        if ($produk_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Produk tidak valid']);
            exit;
        }

        // Cek stok produk
        $stmt = $pdo->prepare("SELECT id, nama_produk, stok FROM produk WHERE id = ?");
        $stmt->execute([$produk_id]);
        $prod = $stmt->fetch();

        if (!$prod) {
            echo json_encode(['success' => false, 'message' => 'Produk tidak ditemukan']);
            exit;
        }

        if ($prod['stok'] < $jumlah) {
            echo json_encode(['success' => false, 'message' => 'Stok produk tidak mencukupi (tersisa ' . $prod['stok'] . ' pcs)']);
            exit;
        }

        if (is_logged_in()) {
            $user_id = $_SESSION['user_id'];
            $stmt = $pdo->prepare("SELECT id, jumlah FROM keranjang WHERE id_user = ? AND id_produk = ?");
            $stmt->execute([$user_id, $produk_id]);
            $existing = $stmt->fetch();

            if ($existing) {
                $new_qty = $existing['jumlah'] + $jumlah;
                $update = $pdo->prepare("UPDATE keranjang SET jumlah = ? WHERE id = ?");
                $update->execute([$new_qty, $existing['id']]);
            } else {
                $insert = $pdo->prepare("INSERT INTO keranjang (id_user, id_produk, jumlah) VALUES (?, ?, ?)");
                $insert->execute([$user_id, $produk_id, $jumlah]);
            }
        } else {
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            if (isset($_SESSION['cart'][$produk_id])) {
                $_SESSION['cart'][$produk_id]['jumlah'] += $jumlah;
            } else {
                $_SESSION['cart'][$produk_id] = [
                    'produk_id' => $produk_id,
                    'jumlah' => $jumlah
                ];
            }
        }

        echo json_encode([
            'success' => true,
            'message' => 'Berhasil ditambahkan ke keranjang!',
            'total_count' => get_cart_count($pdo)
        ]);
        exit;
    }

    if ($action === 'update') {
        $produk_id = (int)($_POST['produk_id'] ?? 0);
        $jumlah = (int)($_POST['jumlah'] ?? 1);

        if ($produk_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Produk tidak valid']);
            exit;
        }

        if ($jumlah <= 0) {
            // Hapus item jika jumlah 0
            if (is_logged_in()) {
                $stmt = $pdo->prepare("DELETE FROM keranjang WHERE id_user = ? AND id_produk = ?");
                $stmt->execute([$_SESSION['user_id'], $produk_id]);
            } else {
                unset($_SESSION['cart'][$produk_id]);
            }
        } else {
            if (is_logged_in()) {
                $stmt = $pdo->prepare("UPDATE keranjang SET jumlah = ? WHERE id_user = ? AND id_produk = ?");
                $stmt->execute([$jumlah, $_SESSION['user_id'], $produk_id]);
            } else {
                if (isset($_SESSION['cart'][$produk_id])) {
                    $_SESSION['cart'][$produk_id]['jumlah'] = $jumlah;
                }
            }
        }

        echo json_encode([
            'success' => true,
            'total_count' => get_cart_count($pdo)
        ]);
        exit;
    }

    if ($action === 'remove') {
        $produk_id = (int)($_POST['produk_id'] ?? 0);
        if (is_logged_in()) {
            $stmt = $pdo->prepare("DELETE FROM keranjang WHERE id_user = ? AND id_produk = ?");
            $stmt->execute([$_SESSION['user_id'], $produk_id]);
        } else {
            unset($_SESSION['cart'][$produk_id]);
        }

        echo json_encode([
            'success' => true,
            'message' => 'Item dihapus',
            'total_count' => get_cart_count($pdo)
        ]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Aksi tidak dikenali']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Terjadi kesalahan server: ' . $e->getMessage()]);
}
