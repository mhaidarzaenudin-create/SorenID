<?php
// pesanan-sukses.php - Order Success & Payment Instructions Page
$page_title = 'Pesanan Berhasil';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL);
    exit;
}

$stmt = $pdo->prepare("
    SELECT p.*, pb.metode, pb.status as status_bayar
    FROM pesanan p
    LEFT JOIN pembayaran pb ON p.id = pb.id_pesanan
    WHERE p.id = ?
");
$stmt->execute([$id]);
$pesanan = $stmt->fetch();

if (!$pesanan) {
    header('Location: ' . BASE_URL);
    exit;
}

$order_no = '#SOREN-' . str_pad($pesanan['id'], 5, '0', STR_PAD_LEFT);
$is_qris = (stripos($pesanan['metode'], 'QRIS') !== false);

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding-top: 36px; padding-bottom: 80px; max-width: 720px;">
  <div style="background:#ffffff; border-radius:22px; border:1px solid var(--border-color); padding: 36px 32px; text-align:center; box-shadow:0 10px 30px rgba(42,31,39,0.06);">
    <!-- Success Icon -->
    <div style="width: 72px; height: 72px; border-radius:50%; background: linear-gradient(135deg, #e8f5e9, #c8e6c9); color:#2e7d32; font-size:34px; display:inline-flex; align-items:center; justify-content:center; margin-bottom: 16px; box-shadow:0 8px 20px rgba(46,125,50,0.15);">
      ✓
    </div>

    <div style="font-size:12px; text-transform:uppercase; letter-spacing:2px; color:var(--primary); font-weight:800; margin-bottom:4px;">
      Alhamdulillah, Pesanan Diterima!
    </div>
    <h1 style="font-family: var(--font-serif); font-size: 28px; color:var(--text-dark); margin-bottom: 8px;">
      Pesanan Kamu Berhasil Dibuat
    </h1>
    <p style="color:var(--text-muted); font-size:14px; margin-bottom: 24px;">
      Nomor Pesanan: <b style="color:var(--primary-dark); letter-spacing:0.5px;"><?= $order_no ?></b>
    </p>

    <?php if ($is_qris): ?>
      <!-- OFFICIAL QRIS STANDEE / PAYMENT CARD -->
      <div class="qris-standee" style="margin-bottom: 28px;">
        <!-- Header QRIS -->
        <div class="qris-header-bar">
          <div style="text-align:left;">
            <div class="qris-logo-text">QRIS</div>
            <div class="qris-sub-tag">National QR Code Standard</div>
          </div>
          <div class="qris-gpn-badge">GPN</div>
        </div>

        <!-- Merchant Header -->
        <div class="qris-merchant-info">
          <div class="qris-merchant-title">SOREN.ID OFFICIAL STORE</div>
          <div class="qris-merchant-meta">
            <span>NMID: ID1020240928019</span>
            <span>•</span>
            <span>A01</span>
          </div>
        </div>

        <!-- QR Display Container -->
        <div class="qris-qr-container">
          <!-- Countdown Timer -->
          <div class="qris-countdown">
            <span class="countdown-pulse"></span>
            <span>Selesaikan pembayaran dalam <b id="countdownTimer">15:00</b></span>
          </div>

          <!-- High-Res QR Canvas -->
          <div class="qris-qr-box" id="qrisCaptureArea">
            <div id="qrisSuccessCanvas" style="display:flex; justify-content:center;"></div>
          </div>

          <!-- Total Tagihan -->
          <div style="width:100%; max-width:320px; background:var(--bg-main); border:1.5px solid var(--border-color); border-radius:12px; padding:12px 16px; margin: 10px 0 16px;">
            <div style="font-size:12px; color:var(--text-muted); margin-bottom:2px;">Total yang harus dibayar:</div>
            <div style="display:flex; align-items:center; justify-content:center; gap:8px;">
              <span style="font-size:22px; font-weight:800; color:var(--primary-dark); letter-spacing:0.5px;" id="orderTotalText">
                <?= format_rupiah($pesanan['total_harga']) ?>
              </span>
              <button type="button" onclick="copyAmount(<?= (int)$pesanan['total_harga'] ?>)" title="Salin Nominal" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:4px 8px; font-size:11px; font-weight:600; cursor:pointer; color:var(--text-muted);">
                📋 Salin
              </button>
            </div>
          </div>

          <!-- Download & Action Buttons -->
          <div class="qris-action-btn-group">
            <button type="button" class="btn btn-dark btn-sm" onclick="downloadQrisImage()" style="border-radius:10px; padding:10px 18px; font-size:12px;">
              📥 Unduh Kode QR
            </button>
            <button type="button" class="btn btn-outline btn-sm" onclick="copyAmount(<?= (int)$pesanan['total_harga'] ?>)" style="border-radius:10px; padding:10px 18px; font-size:12px;">
              📋 Salin Total
            </button>
          </div>
        </div>

        <!-- Accepted Wallets Banner -->
        <div class="qris-wallets-banner">
          <div class="wallets-label">Mendukung Semua Pembayaran QR:</div>
          <div class="wallets-chips">
            <span class="wallet-chip" style="color:#00a651;">GoPay</span>
            <span class="wallet-chip" style="color:#4c2a86;">OVO</span>
            <span class="wallet-chip" style="color:#118eea;">DANA</span>
            <span class="wallet-chip" style="color:#ee4d2d;">ShopeePay</span>
            <span class="wallet-chip" style="color:#e21a22;">LinkAja</span>
            <span class="wallet-chip" style="color:#00569e;">BCA Mobile</span>
            <span class="wallet-chip" style="color:#003d79;">Livin' Mandiri</span>
            <span class="wallet-chip" style="color:#00529c;">BRImo</span>
            <span class="wallet-chip" style="color:#f15a24;">BNI</span>
          </div>
        </div>
      </div>

      <!-- 4 Langkah Mudah Membayar QRIS -->
      <div style="background:#fffafc; border:1px solid var(--border-color); border-radius:16px; padding:22px; text-align:left; margin-bottom: 28px;">
        <h4 style="font-family:var(--font-serif); font-size:16px; color:var(--text-dark); margin-bottom:12px; display:flex; align-items:center; gap:8px;">
          <span>📱</span> Panduan Pembayaran via QRIS
        </h4>
        <ol style="font-size:13px; color:var(--text-muted); line-height:1.7; padding-left:18px; margin:0;">
          <li>Buka aplikasi <b>m-Banking</b> (BCA Mobile, Livin', BRImo, dll) atau <b>E-Wallet</b> (GoPay, OVO, ShopeePay, DANA).</li>
          <li>Pilih menu <b>Scan / Bayar QR</b>.</li>
          <li>Arahkan kamera ke kode QR di atas (atau klik <b>Unduh Kode QR</b> lalu pilih gambar dari galeri handphone).</li>
          <li>Pastikan nama merchant adalah <b>SOREN.ID</b> dan nominal sebesar <b><?= format_rupiah($pesanan['total_harga']) ?></b>.</li>
          <li>Konfirmasi pembayaran dengan memasukkan PIN aplikasi kamu.</li>
        </ol>
      </div>

    <?php elseif (stripos($pesanan['metode'], 'BCA') !== false): ?>
      <!-- BCA Instruction Box -->
      <div style="background:#fffafc; border-radius:16px; border:1px solid var(--border-color); padding:26px; text-align:left; margin-bottom: 28px;">
        <div style="font-size:13px; color:var(--text-muted); margin-bottom:4px;">Metode Pembayaran:</div>
        <div style="font-size:16px; font-weight:700; color:var(--text-dark); margin-bottom:14px;">
          <?= htmlspecialchars($pesanan['metode']) ?>
        </div>

        <div style="background:#fff; border:1px solid var(--border-color); border-radius:12px; padding:18px; margin-bottom:16px;">
          <div style="font-size:12px; color:var(--text-muted);">Nomor Rekening Bank BCA:</div>
          <div style="font-size:22px; font-weight:800; color:var(--text-dark); letter-spacing:1.5px; margin:6px 0;">123-456-7890</div>
          <div style="font-size:13px; color:var(--text-muted);">Atas Nama: <b style="color:var(--text-dark);">PT SOREN INDONESIA</b></div>
        </div>

        <div style="font-size:13px; color:var(--text-muted); margin-bottom:4px;">Total yang harus ditransfer:</div>
        <div style="font-size:24px; font-weight:800; color:var(--primary-dark); margin-bottom:14px;">
          <?= format_rupiah($pesanan['total_harga']) ?>
        </div>
      </div>

    <?php elseif (stripos($pesanan['metode'], 'Mandiri') !== false): ?>
      <!-- Mandiri Instruction Box -->
      <div style="background:#fffafc; border-radius:16px; border:1px solid var(--border-color); padding:26px; text-align:left; margin-bottom: 28px;">
        <div style="font-size:13px; color:var(--text-muted); margin-bottom:4px;">Metode Pembayaran:</div>
        <div style="font-size:16px; font-weight:700; color:var(--text-dark); margin-bottom:14px;">
          <?= htmlspecialchars($pesanan['metode']) ?>
        </div>

        <div style="background:#fff; border:1px solid var(--border-color); border-radius:12px; padding:18px; margin-bottom:16px;">
          <div style="font-size:12px; color:var(--text-muted);">Nomor Rekening Bank Mandiri:</div>
          <div style="font-size:22px; font-weight:800; color:var(--text-dark); letter-spacing:1.5px; margin:6px 0;">131-00-9876543</div>
          <div style="font-size:13px; color:var(--text-muted);">Atas Nama: <b style="color:var(--text-dark);">PT SOREN INDONESIA</b></div>
        </div>

        <div style="font-size:13px; color:var(--text-muted); margin-bottom:4px;">Total yang harus ditransfer:</div>
        <div style="font-size:24px; font-weight:800; color:var(--primary-dark); margin-bottom:14px;">
          <?= format_rupiah($pesanan['total_harga']) ?>
        </div>
      </div>

    <?php else: ?>
      <!-- COD Instruction Box -->
      <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:16px; padding:22px; text-align:left; margin-bottom: 28px;">
        <div style="font-size:15px; font-weight:700; color:#166534; margin-bottom:6px;">
          💵 Cash On Delivery (Bayar di Tempat)
        </div>
        <p style="font-size:13.5px; color:#166534; line-height:1.6; margin:0;">
          Pesananmu akan segera dikemas dan diserahkan ke kurir. Silakan siapkan uang pas sebesar <b><?= format_rupiah($pesanan['total_harga']) ?></b> saat kurir sampai di alamat tujuan.
        </p>
      </div>
    <?php endif; ?>

    <!-- Note Upload Bukti -->
    <p style="font-size:12.5px; color:var(--text-muted); line-height:1.6; margin-bottom:28px;">
      Setelah menyelesaikan pembayaran, silakan simpan bukti transaksi dan unggah melalui menu <b>Akun Saya &gt; Riwayat Pesanan</b> agar tim SOREN.ID segera menyiapkan paketmu 💕
    </p>

    <!-- Bottom Actions -->
    <div style="display:flex; gap:14px; justify-content:center; flex-wrap:wrap;">
      <a href="<?= BASE_URL ?>akun.php" class="btn btn-primary" style="padding:14px 24px; border-radius:12px; font-weight:700;">
        Lihat Pesanan & Unggah Bukti Bayar ➔
      </a>
      <a href="<?= BASE_URL ?>" class="btn btn-outline" style="padding:14px 24px; border-radius:12px; font-weight:600;">
        Kembali ke Beranda
      </a>
    </div>
  </div>
</div>

<!-- Load QRCode Client Generator -->
<script src="<?= ASSETS_URL ?>js/qrcode.min.js"></script>

<script>
  // Salin Nominal ke Clipboard
  function copyAmount(nominal) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(nominal.toString()).then(() => {
        alert("Nominal Rp " + nominal.toLocaleString('id-ID') + " berhasil disalin!");
      }).catch(() => {
        prompt("Salin nominal pembayaran berikut:", nominal);
      });
    } else {
      prompt("Salin nominal pembayaran berikut:", nominal);
    }
  }

  <?php if ($is_qris): ?>
  // Render Official QRIS
  const qrisPayloadSuccess = "00020101021226680016ID.CO.QRIS.WWW01189360091100202409280215ID10202409280190303UMI51440014ID.LINKAJA.WWW0215ID10202409280190303UMI520458125303360540<?= $pesanan['total_harga'] ?>5802ID5908SOREN.ID6007BANDUNG61054011562070703A016304";

  window.addEventListener('DOMContentLoaded', function () {
    const container = document.getElementById('qrisSuccessCanvas');
    if (container) {
      try {
        if (typeof QRCode !== 'undefined') {
          new QRCode(container, {
            text: qrisPayloadSuccess,
            width: 230,
            height: 230,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.M
          });
        } else {
          container.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=230x230&data=${encodeURIComponent(qrisPayloadSuccess)}" alt="QRIS SOREN.ID" style="display:block; width:230px; height:230px;">`;
        }
      } catch (e) {
        container.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=230x230&data=${encodeURIComponent(qrisPayloadSuccess)}" alt="QRIS SOREN.ID" style="display:block; width:230px; height:230px;">`;
      }
    }

    // Countdown Timer 15 Menit
    let timeLeft = 15 * 60; // 15 menit dalam detik
    const timerEl = document.getElementById('countdownTimer');
    const interval = setInterval(function () {
      if (timeLeft <= 0) {
        clearInterval(interval);
        if (timerEl) timerEl.textContent = "Waktu Habis";
        return;
      }
      timeLeft--;
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      if (timerEl) {
        timerEl.textContent = String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
      }
    }, 1000);
  });

  // Unduh Kode QR ke format gambar PNG
  function downloadQrisImage() {
    const canvas = document.querySelector('#qrisSuccessCanvas canvas');
    if (canvas) {
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = 'QRIS-SOREN-<?= $pesanan['id'] ?>.png';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      const img = document.querySelector('#qrisSuccessCanvas img');
      if (img) {
        window.open(img.src, '_blank');
      } else {
        alert("Gambar QR sedang dimuat, silakan coba sesaat lagi.");
      }
    }
  }
  <?php endif; ?>
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>

