<?php
// login.php - Customer Login Page
$page_title = 'Masuk ke Akun';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    header('Location: ' . BASE_URL . 'akun.php');
    exit;
}

// Simpan URL tujuan setelah login (dari checkout redirect)
$redirect_after = clean_input($_GET['redirect'] ?? '');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = clean_input($_POST['email']    ?? '');
    $password = $_POST['password']             ?? '';
    $redirect_after = clean_input($_POST['redirect_after'] ?? '');

    if (empty($email) || empty($password)) {
        $error = 'Email dan kata sandi wajib diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && verify_password($password, $user['password'])) {
            if ($user['role'] === 'admin') {
                $_SESSION['admin_id']    = $user['id'];
                $_SESSION['admin_name']  = $user['nama'];
                $_SESSION['admin_email'] = $user['email'];
                $_SESSION['user_role']   = 'admin';
                header('Location: ' . BASE_URL . 'admin/index.php');
                exit;
            } else {
                $_SESSION['user_id']    = $user['id'];
                $_SESSION['user_name']  = $user['nama'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role']  = 'user';

                // Redirect ke tujuan semula (misal checkout) atau akun
                $goto = (!empty($redirect_after) && strpos($redirect_after, 'http') === false)
                        ? BASE_URL . ltrim($redirect_after, '/')
                        : BASE_URL . 'akun.php';
                header('Location: ' . $goto);
                exit;
            }
        } else {
            $error = 'Email atau kata sandi tidak cocok. Silakan coba lagi.';
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<style>
/* ── Login Page ─────────────────────────────────── */
.auth-page-wrap {
  min-height: calc(100vh - 120px);
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: stretch;
}

/* Panel kiri: branding */
.auth-brand-panel {
  background: linear-gradient(145deg, #2d1520 0%, #6b3d50 45%, #c58385 100%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  padding: 60px 52px;
  position: relative;
  overflow: hidden;
  color: #fff;
}
.auth-brand-panel::before {
  content: '';
  position: absolute;
  width: 380px; height: 380px; border-radius: 50%;
  background: rgba(255,255,255,0.06);
  top: -100px; right: -100px;
}
.auth-brand-panel::after {
  content: '';
  position: absolute;
  width: 260px; height: 260px; border-radius: 50%;
  background: rgba(255,255,255,0.05);
  bottom: -70px; left: -50px;
}

/* Dekorasi lingkaran kecil-kecil */
.auth-deco-dots {
  position: absolute;
  bottom: 140px; right: 40px;
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
  opacity: 0.18;
  z-index: 0;
}
.auth-deco-dots span {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: #fff;
  display: block;
}

.auth-brand-logo {
  font-family: var(--font-serif);
  font-size: 44px; font-weight: 700;
  letter-spacing: 5px; margin-bottom: 4px;
  position: relative; z-index: 1;
}
.auth-brand-tagline {
  font-size: 11px; text-transform: uppercase;
  letter-spacing: 3px; opacity: 0.7;
  margin-bottom: 52px;
  position: relative; z-index: 1;
}

/* Kartu produk dekoratif */
.auth-product-cards {
  display: flex; gap: 14px;
  margin-bottom: 40px;
  position: relative; z-index: 1;
}
.auth-prod-card {
  width: 90px;
  background: rgba(255,255,255,0.12);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 14px;
  overflow: hidden;
  flex-shrink: 0;
  transition: transform .3s;
}
.auth-prod-card:hover { transform: translateY(-4px); }
.auth-prod-card img {
  width: 100%; aspect-ratio: 3/4;
  object-fit: cover; display: block;
  opacity: 0.88;
}
.auth-prod-card-label {
  padding: 6px 8px;
  font-size: 9.5px; font-weight: 700;
  color: rgba(255,255,255,0.9);
  text-align: center;
  letter-spacing: .3px;
  text-transform: uppercase;
}

.auth-brand-headline {
  font-family: var(--font-serif);
  font-size: 30px; line-height: 1.2; font-weight: 600;
  margin-bottom: 12px;
  position: relative; z-index: 1;
}
.auth-brand-desc {
  font-size: 13.5px; line-height: 1.7; opacity: 0.8;
  max-width: 320px; margin-bottom: 0;
  position: relative; z-index: 1;
}

/* Panel kanan: form */
.auth-form-panel {
  background: #fffafc;
  display: flex; flex-direction: column;
  justify-content: center;
  padding: 52px 56px;
  overflow-y: auto;
}

.auth-form-header { margin-bottom: 32px; }
.auth-form-header .auth-icon {
  width: 64px; height: 64px; border-radius: 50%;
  background: linear-gradient(135deg, #f9dfe8, #f0c5d0);
  display: flex; align-items: center; justify-content: center;
  font-size: 28px; margin-bottom: 16px;
  box-shadow: 0 8px 20px rgba(197,131,133,0.25);
}
.auth-form-header h1 {
  font-family: var(--font-serif);
  font-size: 32px; color: var(--text-dark); margin-bottom: 6px;
}
.auth-form-header p { font-size: 13.5px; color: var(--text-muted); }

/* Floating label */
.float-group { position: relative; margin-bottom: 20px; }
.float-group input {
  width: 100%;
  padding: 18px 44px 8px 16px;
  border: 1.5px solid var(--border-color);
  border-radius: var(--radius-md);
  font-size: 14px; font-family: var(--font-sans);
  background: #fff; color: var(--text-dark);
  outline: none; box-sizing: border-box;
  transition: border-color .2s, box-shadow .2s, background .2s;
}
.float-group input:focus {
  border-color: var(--primary); background: #fff;
  box-shadow: 0 0 0 3px rgba(217,163,176,0.18);
}
.float-group label {
  position: absolute; left: 16px; top: 14px;
  font-size: 14px; color: #b5a4ab;
  pointer-events: none; transition: .18s ease;
  transform-origin: left top;
}
.float-group input:focus ~ label,
.float-group input:not(:placeholder-shown) ~ label {
  top: 6px; font-size: 10.5px; letter-spacing: .4px;
  color: var(--primary-dark); font-weight: 700; text-transform: uppercase;
}
.float-group .fi {
  position: absolute; right: 14px; top: 50%;
  transform: translateY(-50%);
  font-size: 16px; color: #d9a3b0; pointer-events: none;
}
.float-group .pw-toggle {
  position: absolute; right: 12px; top: 50%;
  transform: translateY(-50%);
  background: none; border: none; cursor: pointer;
  color: var(--text-light); font-size: 16px; padding: 4px;
  transition: color .2s; z-index: 2;
}
.float-group .pw-toggle:hover { color: var(--primary); }

/* Submit btn */
.auth-submit-btn {
  width: 100%; padding: 15px 24px;
  background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
  color: #fff; font-size: 14px; font-weight: 700;
  text-transform: uppercase; letter-spacing: 1.2px;
  border: none; border-radius: var(--radius-full);
  cursor: pointer; transition: var(--transition);
  box-shadow: 0 8px 24px rgba(122,77,94,0.3);
  margin-bottom: 18px;
}
.auth-submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 30px rgba(122,77,94,0.4);
}

/* Social proof mini */
.auth-social-proof {
  display: flex; align-items: center; gap: 10px;
  background: var(--primary-soft);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  padding: 12px 16px; margin-bottom: 24px;
}
.auth-sp-avatars { display: flex; }
.auth-sp-avatars span {
  width: 28px; height: 28px; border-radius: 50%;
  border: 2px solid #fff;
  background: linear-gradient(135deg, #f0c5d0, #d9a3b0);
  display: flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 700; color: var(--primary-dark);
  margin-left: -8px;
}
.auth-sp-avatars span:first-child { margin-left: 0; }
.auth-sp-text { font-size: 12px; color: var(--text-muted); line-height: 1.4; }
.auth-sp-text b { color: var(--primary-dark); }

.auth-divider {
  text-align: center; font-size: 13px;
  color: var(--text-muted);
  padding-top: 18px; border-top: 1px solid var(--border-color);
}
.auth-divider a { color: var(--primary-dark); font-weight: 700; }
.auth-divider a:hover { color: var(--primary); }

/* Demo box */
.auth-demo-box {
  margin-top: 16px; background: #fff7fa;
  border: 1px solid var(--border-color);
  padding: 12px 16px; border-radius: 12px;
  font-size: 11.5px; color: var(--text-muted);
  text-align: center; line-height: 1.7;
  cursor: pointer; transition: border-color .2s;
}
.auth-demo-box:hover { border-color: var(--primary); }

/* Checkout redirect notice */
.auth-checkout-notice {
  background: linear-gradient(135deg, #fff3e0, #fff8f0);
  border: 1px solid #ffe0b2;
  border-left: 4px solid #f39c12;
  border-radius: var(--radius-md);
  padding: 14px 18px;
  margin-bottom: 24px;
  display: flex; align-items: flex-start; gap: 12px;
}
.auth-checkout-notice .notice-icon { font-size: 22px; flex-shrink: 0; }
.auth-checkout-notice .notice-text { font-size: 13px; color: #7d4e00; line-height: 1.5; }
.auth-checkout-notice .notice-text b { color: #e67e22; }

@media (max-width: 768px) {
  .auth-page-wrap { grid-template-columns: 1fr; }
  .auth-brand-panel { display: none; }
  .auth-form-panel { padding: 36px 24px; }
}
</style>

<div class="auth-page-wrap">

  <!-- ══ Panel Kiri: Branding ══ -->
  <div class="auth-brand-panel">
    <div class="auth-brand-logo">SOREN.</div>
    <div class="auth-brand-tagline">Korean Girls Fashion</div>

    <!-- Kartu produk dekoratif -->
    <div class="auth-product-cards">
      <?php
      // Ambil 3 foto produk terbaru untuk dekorasi
      $deco_prods = $pdo->query("SELECT gambar, nama_produk FROM produk WHERE gambar IS NOT NULL ORDER BY id DESC LIMIT 3")->fetchAll();
      foreach ($deco_prods as $dp):
      ?>
        <div class="auth-prod-card">
          <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($dp['gambar']) ?>"
               alt="<?= htmlspecialchars($dp['nama_produk']) ?>"
               onerror="this.parentElement.style.display='none'">
          <div class="auth-prod-card-label"><?= htmlspecialchars(mb_strimwidth($dp['nama_produk'],0,14,'…')) ?></div>
        </div>
      <?php endforeach; ?>
    </div>

    <h2 class="auth-brand-headline">Selamat Datang<br>Kembali ✨</h2>
    <p class="auth-brand-desc">
      Masuk dan temukan koleksi outfit Korea terbaru, pantau pesananmu, dan nikmati promo eksklusif member SOREN.
    </p>

    <!-- Dot decoration -->
    <div class="auth-deco-dots">
      <?php for ($i = 0; $i < 25; $i++): ?><span></span><?php endfor; ?>
    </div>
  </div>

  <!-- ══ Panel Kanan: Form ══ -->
  <div class="auth-form-panel">

    <div class="auth-form-header">
      <div class="auth-icon">✨</div>
      <h1>Masuk ke Akun</h1>
      <p>Lanjutkan belanja outfit Korea favoritmu</p>
    </div>

    <?php if (!empty($redirect_after)): ?>
      <div class="auth-checkout-notice">
        <div class="notice-icon">🛍️</div>
        <div class="notice-text">
          <b>Hampir selesai!</b> Kamu perlu masuk ke akun dulu untuk melanjutkan checkout pesananmu.
          Belum punya akun? <a href="<?= BASE_URL ?>register.php" style="color:#e67e22; font-weight:700;">Daftar gratis</a> hanya 1 menit!
        </div>
      </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
      <div style="background:#fde8e8; color:#c81e1e; padding:14px 18px; border-radius:12px; margin-bottom:22px; font-size:13.5px; border:1px solid #f7cacc; display:flex; align-items:center; gap:10px;">
        <span style="font-size:18px; flex-shrink:0;">⚠️</span>
        <span><?= htmlspecialchars($error) ?></span>
      </div>
    <?php endif; ?>

    <!-- Social proof -->
    <div class="auth-social-proof">
      <div class="auth-sp-avatars">
        <span>A</span><span>D</span><span>R</span><span>N</span>
      </div>
      <div class="auth-sp-text">
        <b>2.400+ pelanggan</b> sudah berbelanja di SOREN bulan ini ⭐
      </div>
    </div>

    <form method="POST" action="" id="loginForm" novalidate>
      <input type="hidden" name="redirect_after" value="<?= htmlspecialchars($redirect_after) ?>">

      <!-- Email -->
      <div class="float-group">
        <input type="email" name="email" id="fEmail" placeholder=" "
               required autocomplete="email" autofocus>
        <label for="fEmail">Alamat Email</label>
        <span class="fi">✉️</span>
      </div>

      <!-- Password -->
      <div class="float-group">
        <input type="password" name="password" id="fPassword" placeholder=" "
               required autocomplete="current-password">
        <label for="fPassword">Kata Sandi</label>
        <button type="button" class="pw-toggle" onclick="togglePw('fPassword', this)">👁</button>
      </div>

      <button type="submit" class="auth-submit-btn">
        Masuk Sekarang →
      </button>

      <div class="auth-divider">
        Belum punya akun?
        <a href="<?= BASE_URL ?>register.php<?= $redirect_after ? '?redirect='.urlencode($redirect_after) : '' ?>">
          Daftar Sekarang
        </a>
      </div>

      <!-- Demo credentials -->
      <div class="auth-demo-box" onclick="fillDemo('customer')" title="Klik untuk isi otomatis">
        💡 <b>Demo Customer:</b> anisa@gmail.com / user123 &nbsp;|&nbsp;
        👑 <b>Admin:</b> admin@soren.id / admin123
        <br><span style="font-size:10.5px; color:var(--primary);">← klik untuk isi otomatis</span>
      </div>
    </form>
  </div>
</div>

<script>
function togglePw(id, btn) {
  const inp = document.getElementById(id);
  if (inp.type === 'password') { inp.type = 'text';     btn.textContent = '🙈'; }
  else                         { inp.type = 'password'; btn.textContent = '👁'; }
}

function fillDemo(type) {
  if (type === 'customer') {
    document.getElementById('fEmail').value    = 'anisa@gmail.com';
    document.getElementById('fPassword').value = 'user123';
  }
  // Trigger floating label naik
  ['fEmail','fPassword'].forEach(id => {
    const el = document.getElementById(id);
    el.dispatchEvent(new Event('input'));
  });
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
