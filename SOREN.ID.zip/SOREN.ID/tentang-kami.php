<?php
// tentang-kami.php - About Us Brand Story for SOREN.ID
$page_title = 'Tentang Kami';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding-top: 30px; padding-bottom: 70px; max-width: 900px;">
  <div class="breadcrumb">
    <a href="<?= BASE_URL ?>">Beranda</a>
    <span>/</span>
    <span style="color:var(--primary-dark); font-weight:600;">Tentang SOREN.ID</span>
  </div>

  <div style="text-align: center; margin-bottom: 40px;">
    <div class="section-subtitle">Filosofi & Nilai Brand</div>
    <h1 style="font-family: var(--font-serif); font-size: 38px; margin-bottom: 12px;">Fashion Priawanita dengan Sentuhan Korea</h1>
    <p style="font-size: 16px; color: var(--text-muted); max-width: 650px; margin: 0 auto; line-height: 1.7;">
      SOREN lahir dari keinginan untuk menghadirkan busana wanita bergaya Korea yang nyaman, feminin, dan tetap stylish untuk hari-hari santai maupun momen spesial.
    </p>
  </div>

  <div style="border-radius:var(--radius-lg); overflow:hidden; margin-bottom: 40px; box-shadow:var(--shadow-md);">
    <img src="<?= ASSETS_URL ?>images/banners/hero-1.jpg" alt="Lookbook SOREN" style="width:100%; height:380px; object-fit:cover;">
  </div>

  <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 40px; box-shadow:var(--shadow-sm); line-height: 1.8; color: #3c3635; font-size:15px;">
    <h3 style="font-family: var(--font-serif); font-size: 24px; margin-bottom: 14px; color:var(--text-dark);">
      Kisah di Balik SOREN.ID
    </h3>
    <p style="margin-bottom: 16px;">
      Berdiri di Kota Kembang, Bandung, <b>SOREN.ID</b> menghadirkan koleksi fashion wanita dengan nuansa street style Korea: atasan nyaman, bawahan santai, hingga one set yang mudah dipadukan untuk tampilan sehari-hari yang tetap chic dan fresh.
    </p>
    <p style="margin-bottom: 24px;">
      Kami percaya bahwa fashion bukan hanya soal tren, tetapi juga tentang rasa percaya diri, kenyamanan, dan ekspresi keindahan natural seorang wanita.
    </p>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; border-top: 1px solid var(--border-color); padding-top: 24px; margin-top: 24px;">
      <div>
        <h4 style="font-size: 16px; font-weight:700; color:var(--primary-dark); margin-bottom:6px;">🌿 Material Pilihan</h4>
        <p style="font-size:13px; color:var(--text-muted);">Hanya menggunakan bahan yang teruji adem, tidak licin, dan tahan lama dipakai sehari-hari.</p>
      </div>
      <div>
        <h4 style="font-size: 16px; font-weight:700; color:var(--primary-dark); margin-bottom:6px;">🪡 Standar Jahitan Butik</h4>
        <p style="font-size:13px; color:var(--text-muted);">Dikerjakan oleh penjahit lokal berpengalaman dengan kerapian jahitan tepi halus dan laser cut presisi.</p>
      </div>
      <div>
        <h4 style="font-size: 16px; font-weight:700; color:var(--primary-dark); margin-bottom:6px;">💕 Pelayanan Sepenuh Hati</h4>
        <p style="font-size:13px; color:var(--text-muted);">Dukungan live chat ramah melalui tim Soren Care untuk memastikan kenyamanan belanjamu.</p>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
