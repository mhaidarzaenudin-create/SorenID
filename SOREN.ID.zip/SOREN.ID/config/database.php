<?php
// config/database.php - Koneksi Database & Konfigurasi Global SOREN.ID

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inisialisasi guest session id untuk fitur live chat jika belum ada
if (empty($_SESSION['chat_session_id'])) {
    $_SESSION['chat_session_id'] = 'guest_' . bin2hex(random_bytes(8));
}

$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = '';
$db_name = 'soren.id';

try {
    $pdo = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . htmlspecialchars($e->getMessage()));
}

// Deteksi BASE_URL otomatis
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$script_name = $_SERVER['SCRIPT_NAME'] ?? '';
$dir = dirname($script_name);

// Jika di dalam subfolder /admin atau /api, sesuaikan root path
$base_dir = preg_replace('/(\/admin|\/api).*$/i', '', $dir);
$base_dir = rtrim($base_dir, '/\\');
define('BASE_URL', $protocol . $host . $base_dir . '/');
define('ASSETS_URL', BASE_URL . 'assets/');
define('UPLOADS_URL', BASE_URL . 'uploads/');
