// assets/js/main.js - Interactive UI for SOREN.ID

document.addEventListener('DOMContentLoaded', function () {
  // 2. Cart Drawer Toggle
  const cartTrigger = document.getElementById('cartTrigger');
  const cartDrawer = document.getElementById('cartDrawer');
  const drawerBackdrop = document.getElementById('drawerBackdrop');
  const drawerClose = document.getElementById('drawerClose');

  function openCartDrawer() {
    if (cartDrawer && drawerBackdrop) {
      cartDrawer.classList.add('open');
      drawerBackdrop.classList.add('open');
      loadCartDrawer();
    }
  }

  function closeCartDrawer() {
    if (cartDrawer && drawerBackdrop) {
      cartDrawer.classList.remove('open');
      drawerBackdrop.classList.remove('open');
    }
  }

  if (cartTrigger) cartTrigger.addEventListener('click', openCartDrawer);
  if (drawerClose) drawerClose.addEventListener('click', closeCartDrawer);
  if (drawerBackdrop) drawerBackdrop.addEventListener('click', closeCartDrawer);

  // 2. Load Cart Drawer Items via AJAX
  window.loadCartDrawer = function () {
    const drawerBody = document.getElementById('drawerBody');
    const drawerSubtotal = document.getElementById('drawerSubtotal');
    const cartCountBadges = document.querySelectorAll('.cart-count-badge');

    if (!drawerBody) return;

    fetch('api/cart.php?action=get')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          // Update badges
          cartCountBadges.forEach(b => b.textContent = data.total_count);

          if (data.items.length === 0) {
            drawerBody.innerHTML = `
              <div style="text-align: center; padding: 40px 10px; color: var(--text-muted);">
                <div style="font-size: 40px; margin-bottom: 12px;">🛍️</div>
                <h4 style="font-family: var(--font-serif); margin-bottom: 6px;">Keranjang Masih Kosong</h4>
                <p style="font-size: 13px; margin-bottom: 18px;">Yuk temukan koleksi hijab & modest favoritmu!</p>
                <a href="katalog.php" class="btn btn-primary btn-sm" onclick="closeCartDrawer()">Mulai Belanja</a>
              </div>
            `;
            if (drawerSubtotal) drawerSubtotal.textContent = 'Rp 0';
          } else {
            let html = '';
            let total = 0;
            data.items.forEach(item => {
              const sub = item.harga * item.jumlah;
              total += sub;
              html += `
                <div class="cart-item-row" id="drawer-item-${item.produk_id}">
                  <div class="cart-item-img">
                    <img src="uploads/products/${item.gambar}" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="${item.nama_produk}">
                  </div>
                  <div class="cart-item-info">
                    <div class="cart-item-name">${item.nama_produk}</div>
                    <div class="cart-item-price">Rp ${Number(item.harga).toLocaleString('id-ID')}</div>
                    <div style="display: flex; align-items: center; justify-content: space-between;">
                      <div class="qty-stepper" style="transform: scale(0.85); transform-origin: left center;">
                        <button type="button" class="qty-btn" onclick="updateCartQty(${item.produk_id}, ${item.jumlah - 1})">-</button>
                        <span class="qty-input" style="display: flex; align-items: center; justify-content: center;">${item.jumlah}</span>
                        <button type="button" class="qty-btn" onclick="updateCartQty(${item.produk_id}, ${item.jumlah + 1})">+</button>
                      </div>
                      <button type="button" onclick="removeCartItem(${item.produk_id})" style="background:none; border:none; color:#c58385; font-size:12px; cursor:pointer;">Hapus</button>
                    </div>
                  </div>
                </div>
              `;
            });
            drawerBody.innerHTML = html;
            if (drawerSubtotal) drawerSubtotal.textContent = 'Rp ' + total.toLocaleString('id-ID');
          }
        }
      })
      .catch(err => console.error('Error fetching cart:', err));
  };

  // 3. Add to Cart Handler
  window.addToCart = function (produkId, qty = 1, openDrawer = true) {
    const formData = new FormData();
    formData.append('produk_id', produkId);
    formData.append('jumlah', qty);

    fetch('api/cart.php?action=add', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          showToast(`✨ ${data.message}`);
          loadCartDrawer();
          if (openDrawer) openCartDrawer();
        } else {
          showToast(`⚠️ ${data.message}`);
        }
      })
      .catch(err => console.error('Cart add error:', err));
  };

  window.updateCartQty = function (produkId, qty) {
    const formData = new FormData();
    formData.append('produk_id', produkId);
    formData.append('jumlah', qty);

    fetch('api/cart.php?action=update', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        loadCartDrawer();
        if (typeof renderCartPage === 'function') renderCartPage();
      });
  };

  window.removeCartItem = function (produkId) {
    const formData = new FormData();
    formData.append('produk_id', produkId);

    fetch('api/cart.php?action=remove', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        loadCartDrawer();
        showToast('Item berhasil dihapus dari keranjang');
        if (typeof renderCartPage === 'function') renderCartPage();
      });
  };

  // 4. Product Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', function () {
      const target = this.getAttribute('data-tab');
      tabBtns.forEach(b => b.classList.remove('active'));
      tabPanes.forEach(p => p.classList.remove('active'));

      this.classList.add('active');
      const activePane = document.getElementById(target);
      if (activePane) activePane.classList.add('active');
    });
  });

  // 5. Review Stars in Modal
  const stars = document.querySelectorAll('.star-rating-select .star');
  const ratingInput = document.getElementById('selectedRating');

  if (stars.length && ratingInput) {
    stars.forEach(star => {
      star.addEventListener('mouseover', function () {
        const val = parseInt(this.getAttribute('data-val'));
        stars.forEach(s => {
          s.classList.toggle('hover', parseInt(s.getAttribute('data-val')) <= val);
        });
      });

      star.addEventListener('mouseout', function () {
        stars.forEach(s => s.classList.remove('hover'));
      });

      star.addEventListener('click', function () {
        const val = parseInt(this.getAttribute('data-val'));
        ratingInput.value = val;
        stars.forEach(s => {
          s.classList.toggle('selected', parseInt(s.getAttribute('data-val')) <= val);
        });
      });
    });
  }

  // 6. Review Modal Toggle
  const openReviewBtn = document.getElementById('openReviewModal');
  const reviewModal = document.getElementById('reviewModal');
  const closeReviewBtn = document.getElementById('closeReviewModal');

  if (openReviewBtn && reviewModal) {
    openReviewBtn.addEventListener('click', () => reviewModal.classList.add('show'));
  }
  if (closeReviewBtn && reviewModal) {
    closeReviewBtn.addEventListener('click', () => reviewModal.classList.remove('show'));
  }
  if (reviewModal) {
    reviewModal.addEventListener('click', (e) => {
      if (e.target === reviewModal) reviewModal.classList.remove('show');
    });
  }

  // 7. Toast Notification Utility
  window.showToast = function (message) {
    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `${message}`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      toast.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      setTimeout(() => toast.remove(), 400);
    }, 4200);
  };

  // 8. Social Proof Toast Simulator (Real SOREN.ID Products)
  const simulatedBuyers = [
    { name: 'Dina', city: 'Jakarta Selatan' },
    { name: 'Nadia', city: 'Bandung' },
    { name: 'Aisyah', city: 'Surabaya' },
    { name: 'Clarissa', city: 'Jakarta Barat' },
    { name: 'Fitri', city: 'Yogyakarta' },
    { name: 'Zahra', city: 'Semarang' },
    { name: 'Sherly', city: 'Medan' },
    { name: 'Tiara', city: 'Malang' },
    { name: 'Natasha', city: 'Tangerang' },
    { name: 'Bella', city: 'Bekasi' }
  ];

  // Gunakan produk nyata dari database SOREN.ID
  let productsPool = (Array.isArray(window.SOREN_PRODUCTS) && window.SOREN_PRODUCTS.length > 0)
    ? window.SOREN_PRODUCTS
    : [
        { id: 24, nama: 'Y2K Off-Shoulder Striped Long Sleeve Top with Faux Tie' },
        { id: 25, nama: 'Two-Piece Blue Super Crop Bolero & White Tank Top Set' },
        { id: 26, nama: 'Grunge Y2K Fishnet Knit Shrug Top & Paint Splatter Baggy Jeans' },
        { id: 27, nama: 'Set Blus Off-Shoulder + Rok Mini' },
        { id: 28, nama: 'Gaun Leher Gantung Pita' },
        { id: 29, nama: 'Set Rajut + Rok Lipit' },
        { id: 30, nama: 'Blus Tulle Tali Panjang & Celana Jeans' },
        { id: 31, nama: 'Dress Motif Bunga + Kardigan' },
        { id: 32, nama: 'Retro Academia / Preppy Distressed Set' }
      ];

  let saleIdx = 0;
  function triggerSocialProof() {
    if (!productsPool || productsPool.length === 0) return;
    const buyer = simulatedBuyers[saleIdx % simulatedBuyers.length];
    const product = productsPool[saleIdx % productsPool.length];
    saleIdx++;

    const productTitle = product.nama || product;
    const productLink = product.id ? `produk-detail.php?id=${product.id}` : 'katalog.php';

    showToast(`
      <div style="display:flex; align-items:center; gap:10px; width:100%;">
        ${product.gambar ? `<img src="${product.gambar}" alt="${productTitle}" style="width:38px; height:38px; border-radius:8px; object-fit:cover; flex-shrink:0; border:1px solid #ebd9d2; box-shadow:0 2px 6px rgba(0,0,0,0.06);">` : ''}
        <div style="overflow:hidden;">
          <div style="font-size:11.5px; line-height:1.3; color:#6b5046;">
            🌸 <b>${buyer.name}</b> dari ${buyer.city} baru saja membeli
          </div>
          <div style="font-weight:600; font-size:12.5px; color:var(--primary-dark); margin-top:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
            <a href="${productLink}" style="color:inherit; text-decoration:none;" title="${productTitle}">
              <i>${productTitle}</i>
            </a>
          </div>
        </div>
      </div>
    `);
  }

  // Toast pertama muncul setelah 4 detik, lalu berganti setiap 24 detik
  setTimeout(triggerSocialProof, 4000);
  setInterval(triggerSocialProof, 24000);
});
