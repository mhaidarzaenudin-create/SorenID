// assets/js/chat.js - Customer Live Chat Widget for SOREN.ID

document.addEventListener('DOMContentLoaded', function () {
  const chatFab = document.getElementById('chatFab');
  const chatWindow = document.getElementById('chatWindow');
  const chatCloseBtn = document.getElementById('chatCloseBtn');
  const chatInput = document.getElementById('chatInput');
  const chatSendBtn = document.getElementById('chatSendBtn');
  const chatMessages = document.getElementById('chatMessages');
  const chatTooltip = document.getElementById('chatTooltip');
  const chatFabBadge = document.getElementById('chatFabBadge');
  const quickChips = document.querySelectorAll('.quick-chip');

  let lastMessageCount = 0;
  let isChatOpen = false;

  if (!chatFab || !chatWindow) return;

  // Toggle Chat
  chatFab.addEventListener('click', function () {
    isChatOpen = !isChatOpen;
    chatWindow.classList.toggle('open', isChatOpen);
    if (chatTooltip) chatTooltip.style.display = 'none';
    if (chatFabBadge) chatFabBadge.style.display = 'none';

    if (isChatOpen) {
      fetchMessages();
      if (chatInput) chatInput.focus();
    }
  });

  if (chatCloseBtn) {
    chatCloseBtn.addEventListener('click', function () {
      isChatOpen = false;
      chatWindow.classList.remove('open');
    });
  }

  // Quick chips
  quickChips.forEach(chip => {
    chip.addEventListener('click', function () {
      const msg = this.textContent.trim();
      sendMessage(msg);
    });
  });

  // Send message handler
  function handleSend() {
    const text = chatInput.value.trim();
    if (text) {
      sendMessage(text);
      chatInput.value = '';
    }
  }

  if (chatSendBtn) chatSendBtn.addEventListener('click', handleSend);
  if (chatInput) {
    chatInput.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSend();
      }
    });
  }

  function sendMessage(text) {
    const formData = new FormData();
    formData.append('pesan', text);

    // Optimistic UI append
    appendBubble({
      pengirim: 'user',
      pesan: text,
      waktu: 'Baru saja'
    });
    scrollToBottom();

    fetch('api/chat.php?action=send_message', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          fetchMessages();
        }
      })
      .catch(err => console.error('Error sending chat:', err));
  }

  function appendBubble(msg) {
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${msg.pengirim}`;
    bubble.innerHTML = `
      <div>${escapeHtml(msg.pesan)}</div>
      <div class="chat-bubble-time">${msg.waktu || ''}</div>
    `;
    chatMessages.appendChild(bubble);
  }

  function fetchMessages() {
    fetch('api/chat.php?action=get_messages')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          renderMessages(data.messages);

          // Check if new admin message arrived
          if (data.messages.length > lastMessageCount && !isChatOpen && lastMessageCount > 0) {
            const last = data.messages[data.messages.length - 1];
            if (last.pengirim === 'admin') {
              if (chatFabBadge) chatFabBadge.style.display = 'flex';
              if (window.showToast) window.showToast('💬 Pesan baru dari Min-Soren!');
            }
          }
          lastMessageCount = data.messages.length;
        }
      })
      .catch(err => console.error('Chat polling error:', err));
  }

  function renderMessages(messages) {
    if (!chatMessages) return;
    chatMessages.innerHTML = '';

    if (messages.length === 0) {
      chatMessages.innerHTML = `
        <div style="text-align:center; padding: 20px; color: var(--text-muted); font-size:13px;">
          <p>👋 Halo! Selamat datang di <b>SOREN.ID</b>.</p>
          <p style="margin-top:6px;">Ada yang bisa Min-Soren bantu terkait produk, warna, atau pengiriman hari ini?</p>
        </div>
      `;
      return;
    }

    messages.forEach(m => appendBubble(m));
    scrollToBottom();
  }

  function scrollToBottom() {
    if (chatMessages) {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Initial load
  fetchMessages();

  // Realtime Polling every 3.5 seconds
  setInterval(fetchMessages, 3500);
});
