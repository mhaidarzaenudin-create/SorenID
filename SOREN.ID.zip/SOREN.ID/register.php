<?php
// register.php - Customer Registration Page
$page_title = 'Daftar Akun Baru';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    header('Location: ' . BASE_URL . 'akun.php');
    exit;
}

$error   = '';
$success = '';
$old     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama    = clean_input($_POST['nama']     ?? '');
    $email   = clean_input($_POST['email']    ?? '');
    $password = $_POST['password']            ?? '';
    $no_hp   = clean_input($_POST['no_hp']    ?? '');
    $alamat  = clean_input($_POST['alamat']   ?? '');
    $old     = compact('nama','email','no_hp','alamat');

    if (empty($nama) || empty($email) || empty($password)) {
        $error = 'Nama, email, dan kata sandi wajib diisi.';
    } elseif (strlen($password) < 6) {
        $error = 'Kata sandi minimal 6 karakter.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email ini sudah terdaftar. Silakan <a href="' . BASE_URL . 'login.php" style="color:var(--primary-dark);font-weight:700;">login</a>.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $ins    = $pdo->prepare("INSERT INTO users (nama, email, password, no_hp, alamat, role) VALUES (?,?,?,?,?,'user')");
            if ($ins->execute([$nama, $email, $hashed, $no_hp, $alamat])) {
                $_SESSION['user_id']    = $pdo->lastInsertId();
                $_SESSION['user_name']  = $nama;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_role']  = 'user';
                header('Location: ' . BASE_URL . 'akun.php');
                exit;
            } else {
                $error = 'Gagal mendaftarkan akun. Silakan coba lagi.';
            }
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<style>
/* ── Register Page ─────────────────────────────── */
.auth-page-wrap {
  min-height: calc(100vh - 120px);
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: stretch;
}

/* Panel kiri: branding */
.auth-brand-panel {
  background: linear-gradient(145deg, #3d1f2e 0%, #7a4d5e 50%, #c58385 100%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  padding: 60px 52px;
  position: relative;
  overflow: hidden;
  color: #fff;
}

.auth-brand-panel::before {
  content: '';
  position: absolute;
  width: 420px; height: 420px;
  border-radius: 50%;
  background: rgba(255,255,255,0.05);
  top: -120px; right: -120px;
}
.auth-brand-panel::after {
  content: '';
  position: absolute;
  width: 280px; height: 280px;
  border-radius: 50%;
  background: rgba(255,255,255,0.06);
  bottom: -80px; left: -60px;
}

.auth-brand-logo {
  font-family: var(--font-serif);
  font-size: 42px;
  font-weight: 700;
  letter-spacing: 5px;
  margin-bottom: 6px;
  position: relative; z-index: 1;
}

.auth-brand-tagline {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 3px;
  opacity: 0.75;
  margin-bottom: 48px;
  position: relative; z-index: 1;
}

.auth-brand-headline {
  font-family: var(--font-serif);
  font-size: 32px;
  line-height: 1.2;
  font-weight: 600;
  margin-bottom: 16px;
  position: relative; z-index: 1;
}

.auth-brand-desc {
  font-size: 14px;
  line-height: 1.7;
  opacity: 0.82;
  margin-bottom: 40px;
  max-width: 340px;
  position: relative; z-index: 1;
}

.auth-perks {
  display: flex;
  flex-direction: column;
  gap: 14px;
  position: relative; z-index: 1;
}

.auth-perk-item {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 13.5px;
}

.auth-perk-icon {
  width: 36px; height: 36px;
  border-radius: 50%;
  background: rgba(255,255,255,0.15);
  display: flex; align-items: center; justify-content: center;
  font-size: 16px;
  flex-shrink: 0;
}

/* Panel kanan: form */
.auth-form-panel {
  background: #fffafc;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 52px 52px;
  overflow-y: auto;
}

.auth-form-header {
  margin-bottom: 32px;
}

.auth-form-header h1 {
  font-family: var(--font-serif);
  font-size: 30px;
  color: var(--text-dark);
  margin-bottom: 6px;
}

.auth-form-header p {
  font-size: 13.5px;
  color: var(--text-muted);
}

/* Floating label inputs */
.float-group {
  position: relative;
  margin-bottom: 22px;
}

.float-group input,
.float-group textarea {
  width: 100%;
  padding: 18px 16px 8px;
  border: 1.5px solid var(--border-color);
  border-radius: var(--radius-md);
  font-size: 14px;
  font-family: var(--font-sans);
  background: #fff;
  color: var(--text-dark);
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
  box-sizing: border-box;
}

.float-group textarea {
  resize: none;
  min-height: 80px;
  padding-top: 22px;
}

.float-group input:focus,
.float-group textarea:focus {
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(217,163,176,0.18);
}

.float-group label {
  position: absolute;
  left: 16px;
  top: 14px;
  font-size: 14px;
  color: #b5a4ab;
  pointer-events: none;
  transition: 0.18s ease;
  transform-origin: left top;
  background: transparent;
}

.float-group input:focus ~ label,
.float-group input:not(:placeholder-shown) ~ label,
.float-group textarea:focus ~ label,
.float-group textarea:not(:placeholder-shown) ~ label {
  top: 6px;
  font-size: 10.5px;
  letter-spacing: 0.4px;
  color: var(--primary-dark);
  font-weight: 700;
  text-transform: uppercase;
}

/* Password toggle */
.float-group .pw-toggle {
  position: absolute;
  right: 14px; top: 50%;
  transform: translateY(-50%);
  background: none; border: none;
  cursor: pointer; color: var(--text-light);
  font-size: 16px; padding: 4px;
  transition: color 0.2s;
}
.float-group .pw-toggle:hover { color: var(--primary); }

/* Row 2 kolom */
.form-row-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

/* Password strength */
.pw-strength-bar {
  margin-top: 6px;
  display: flex; gap: 4px;
}
.pw-strength-bar span {
  height: 3px; flex: 1;
  border-radius: 2px;
  background: #e8dae0;
  transition: background 0.3s;
}

/* Submit btn */
.auth-submit-btn {
  width: 100%;
  padding: 15px 24px;
  background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.2px;
  border: none;
  border-radius: var(--radius-full);
  cursor: pointer;
  transition: var(--transition);
  box-shadow: 0 8px 24px rgba(122,77,94,0.3);
  margin-bottom: 20px;
}
.auth-submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 30px rgba(122,77,94,0.4);
}

.auth-divider {
  text-align: center;
  font-size: 13px;
  color: var(--text-muted);
  padding-top: 18px;
  border-top: 1px solid var(--border-color);
}

.auth-divider a { color: var(--primary-dark); font-weight: 700; }
.auth-divider a:hover { color: var(--primary); }

/* Mobile */
@media (max-width: 768px) {
  .auth-page-wrap { grid-template-columns: 1fr; }
  .auth-brand-panel { display: none; }
  .auth-form-panel { padding: 36px 24px; }
  .form-row-2 { grid-template-columns: 1fr; }
}
</style>

<div class="auth-page-wrap">

  <!-- Panel Kiri: Branding -->
  <div class="auth-brand-panel">
    <div class="auth-brand-logo">SOREN.</div>
    <div class="auth-brand-tagline">Korean Girls Fashion</div>

    <h2 class="auth-brand-headline">Gabung & Belanja<br>Lebih Menyenangkan</h2>
    <p class="auth-brand-desc">
      Daftar sekarang dan nikmati pengalaman belanja outfit Korea yang mudah, personal, dan menyenangkan.
    </p>

    <div class="auth-perks">
      <div class="auth-perk-item">
        <div class="auth-perk-icon">🛍️</div>
        <span>Pantau status pesanan secara real-time</span>
      </div>
      <div class="auth-perk-item">
        <div class="auth-perk-icon">⭐</div>
        <span>Tulis ulasan produk & bantu sesama pembeli</span>
      </div>
      <div class="auth-perk-item">
        <div class="auth-perk-icon">💌</div>
        <span>Dapatkan notifikasi promo eksklusif member</span>
      </div>
      <div class="auth-perk-item">
        <div class="auth-perk-icon">🔄</div>
        <span>Proses retur & tukar size lebih mudah</span>
      </div>
    </div>
  </div>

  <!-- Panel Kanan: Form -->
  <div class="auth-form-panel">
    <div class="auth-form-header">
      <h1>Buat Akun SOREN ✨</h1>
      <p>Isi form di bawah ini — hanya butuh 1 menit!</p>
    </div>

    <?php if (!empty($error)): ?>
      <div style="background:#fde8e8; color:#c81e1e; padding:14px 18px; border-radius:12px; margin-bottom:22px; font-size:13.5px; border:1px solid #f7cacc; display:flex; align-items:center; gap:10px;">
        <span>⚠️</span><span><?= $error ?></span>
      </div>
    <?php endif; ?>

    <form method="POST" action="" id="registerForm" novalidate>

      <!-- Nama Lengkap -->
      <div class="float-group">
        <input type="text" name="nama" id="fNama" placeholder=" "
               value="<?= htmlspecialchars($old['nama'] ?? '') ?>" required autocomplete="name">
        <label for="fNama">Nama Lengkap *</label>
      </div>

      <!-- Email & No HP -->
      <div class="form-row-2">
        <div class="float-group">
          <input type="email" name="email" id="fEmail" placeholder=" "
                 value="<?= htmlspecialchars($old['email'] ?? '') ?>" required autocomplete="email">
          <label for="fEmail">Email *</label>
        </div>
        <div class="float-group">
          <input type="tel" name="no_hp" id="fHp" placeholder=" "
                 value="<?= htmlspecialchars($old['no_hp'] ?? '') ?>" autocomplete="tel">
          <label for="fHp">No. WhatsApp / HP</label>
        </div>
      </div>

      <!-- Kata Sandi -->
      <div class="float-group">
        <input type="password" name="password" id="fPassword" placeholder=" "
               required autocomplete="new-password" oninput="checkStrength(this.value)">
        <label for="fPassword">Kata Sandi (Min. 6 karakter) *</label>
        <button type="button" class="pw-toggle" onclick="togglePw('fPassword', this)">👁</button>
        <div class="pw-strength-bar">
          <span id="bar1"></span><span id="bar2"></span>
          <span id="bar3"></span><span id="bar4"></span>
        </div>
      </div>

      <!-- Alamat -->
      <div class="float-group">
        <textarea name="alamat" id="fAlamat" placeholder=" " rows="2"><?= htmlspecialchars($old['alamat'] ?? '') ?></textarea>
        <label for="fAlamat">Alamat Pengiriman (Opsional)</label>
      </div>

      <button type="submit" class="auth-submit-btn">
        Daftar Sekarang →
      </button>

      <div class="auth-divider">
        Sudah punya akun? <a href="<?= BASE_URL ?>login.php">Masuk di Sini</a>
      </div>
    </form>
  </div>
</div>

<script>
function togglePw(id, btn) {
  const inp = document.getElementById(id);
  if (inp.type === 'password') { inp.type = 'text'; btn.textContent = '🙈'; }
  else { inp.type = 'password'; btn.textContent = '👁'; }
}

function checkStrength(val) {
  const bars   = [1,2,3,4].map(i => document.getElementById('bar'+i));
  const colors = ['#e74c3c','#f39c12','#27ae60','#1abc9c'];
  let score = 0;
  if (val.length >= 6) score++;
  if (val.length >= 10) score++;
  if (/[A-Z]/.test(val) || /\d/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  bars.forEach((b,i) => {
    b.style.background = i < score ? colors[Math.min(score-1,3)] : '#e8dae0';
  });
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
