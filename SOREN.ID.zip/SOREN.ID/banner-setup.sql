-- ============================================================
-- SOREN.ID - Setup Tabel Banner Diskon
-- Jalankan di phpMyAdmin atau MySQL CLI
-- ============================================================

CREATE TABLE IF NOT EXISTS `banner_diskon` (
  `id`            INT(11)        NOT NULL AUTO_INCREMENT,
  `tipe`          VARCHAR(20)    NOT NULL DEFAULT 'diskon' COMMENT 'diskon | video',
  `judul`         VARCHAR(120)   NOT NULL,
  `subjudul`      VARCHAR(200)   DEFAULT NULL,
  `label_diskon`  VARCHAR(50)    DEFAULT NULL   COMMENT 'misal: DISKON 30%, FLASH SALE, VIDEO PROMO',
  `harga_asli`    DECIMAL(12,2)  DEFAULT NULL,
  `harga_diskon`  DECIMAL(12,2)  DEFAULT NULL,
  `gambar`        VARCHAR(255)   DEFAULT NULL   COMMENT 'Banner image / video poster thumbnail',
  `video_tipe`    VARCHAR(20)    DEFAULT 'upload' COMMENT 'upload | url',
  `video_url`     VARCHAR(500)   DEFAULT NULL   COMMENT 'URL video MP4 atau YouTube',
  `video_file`    VARCHAR(255)   DEFAULT NULL   COMMENT 'Nama file video di uploads/banners/videos/',
  `video_loop`    TINYINT(1)     NOT NULL DEFAULT 1,
  `video_muted`   TINYINT(1)     NOT NULL DEFAULT 1,
  `link_url`      VARCHAR(255)   DEFAULT NULL   COMMENT 'URL tujuan klik banner',
  `teks_tombol`   VARCHAR(60)    DEFAULT 'Belanja Sekarang',
  `urutan`        INT(4)         NOT NULL DEFAULT 0,
  `aktif`         TINYINT(1)     NOT NULL DEFAULT 1,
  `id_produk`     INT(11)        DEFAULT NULL,
  `warna_bg`      VARCHAR(20)    DEFAULT '#1a1218',
  `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Pastikan folder uploads/banners ada (buat manual atau via PHP)
-- Data contoh agar banner langsung muncul:
INSERT INTO `banner_diskon` (`judul`, `subjudul`, `label_diskon`, `harga_asli`, `harga_diskon`, `gambar`, `link_url`, `teks_tombol`, `urutan`, `aktif`) VALUES
('Flash Sale Akhir Bulan',   'Koleksi pilihan wanita Korea style', 'DISKON 30%', 250000, 175000, 'default-banner.jpg', 'katalog.php',        'Belanja Sekarang', 1, 1),
('New Arrival Minggu Ini',   'Atasan & bawahan terbaru sudah hadir!','NEW IN',    NULL,   NULL,   'default-banner.jpg', 'katalog.php?sort=new','Lihat Koleksi',    2, 1),
('Bundle Hemat 2 Pcs',       'Beli 2 item, hemat lebih banyak',    'HEMAT 20%', 400000, 320000, 'default-banner.jpg', 'katalog.php',        'Ambil Penawaran',  3, 1);
