<?php
// admin/login.php - Admin Portal Login Page
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (is_admin()) {
    header('Location: ' . BASE_URL . 'admin/index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean_input($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Harap isi email dan kata sandi admin.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin' LIMIT 1");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && verify_password($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['nama'];
            $_SESSION['admin_email'] = $admin['email'];
            $_SESSION['user_role'] = 'admin';
            header('Location: ' . BASE_URL . 'admin/index.php');
            exit;
        } else {
            $error = 'Kredensial admin tidak valid atau akun bukan administrator.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Administrator - SOREN.ID</title>
  <link rel="stylesheet" href="<?= ASSETS_URL ?>css/admin.css">
</head>
<body class="admin-login-page">
  <div class="admin-login-shell">
    <div class="admin-login-panel">
      <div class="admin-login-brand">
        <div class="admin-login-mark">S</div>
        <div>
          <div class="admin-login-logo">SOREN.ID</div>
          <div class="admin-login-subtitle">Admin Control Portal</div>
        </div>
      </div>

      <div class="admin-login-copy">
        <h1>Masuk ke Dashboard</h1>
        <p>Kelola produk, pesanan, dan pelanggan dengan aman.</p>
      </div>

      <?php if (!empty($error)): ?>
        <div class="admin-login-error">
          ⚠️ <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="" class="admin-login-form">
        <div class="form-group">
          <label class="form-label" for="email">Email Administrator</label>
          <input type="email" id="email" name="email" class="form-control" placeholder="admin@soren.id" autocomplete="email" required autofocus>
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Kata Sandi</label>
          <input type="password" id="password" name="password" class="form-control" placeholder="Masukkan kata sandi admin" autocomplete="current-password" required>
        </div>

        <button type="submit" class="btn-admin btn-admin-primary admin-login-button">
          Masuk ke Portal Admin
        </button>
      </form>

      <div class="admin-login-footer">
        <span>Demo Admin:</span>
        <strong>admin@soren.id / admin123</strong>
      </div>

      <div class="admin-login-backlink">
        <a href="<?= BASE_URL ?>">← Kembali ke Toko SOREN.ID</a>
      </div>
    </div>
  </div>
</body>
</html>
