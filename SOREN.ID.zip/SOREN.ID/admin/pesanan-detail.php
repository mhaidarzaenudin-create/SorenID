<?php
// admin/pesanan-detail.php - Order Detail & Status Updating
$admin_title = 'Detail Pesanan';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'admin/pesanan.php');
    exit;
}

$success = '';
$error = '';

// Handle Update Status Pesanan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $new_status = clean_input($_POST['status'] ?? '');
    $stmt = $pdo->prepare("UPDATE pesanan SET status = ? WHERE id = ?");
    if ($stmt->execute([$new_status, $id])) {
        $success = 'Status pesanan berhasil diperbarui menjadi: ' . $new_status;
    } else {
        $error = 'Gagal memperbarui status pesanan.';
    }
}

// Ambil data pesanan
$stmt = $pdo->prepare("
    SELECT p.*, usr.nama as customer_name, usr.email as customer_email, usr.no_hp as customer_phone,
           pb.metode, pb.status as status_bayar, pb.bukti_pembayaran
    FROM pesanan p
    JOIN users usr ON p.id_user = usr.id
    LEFT JOIN pembayaran pb ON p.id = pb.id_pesanan
    WHERE p.id = ?
");
$stmt->execute([$id]);
$pesanan = $stmt->fetch();

if (!$pesanan) {
    header('Location: ' . BASE_URL . 'admin/pesanan.php');
    exit;
}

// Ambil item pesanan
$stmt_items = $pdo->prepare("
    SELECT dp.*, p.nama_produk, p.gambar, p.id as id_produk
    FROM detail_pesanan dp
    JOIN produk p ON dp.id_produk = p.id
    WHERE dp.id_pesanan = ?
");
$stmt_items->execute([$id]);
$items = $stmt_items->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
  <div>
    <h2 style="font-size:22px; font-weight:700;">Pesanan #SOREN-<?= str_pad($pesanan['id'], 5, '0', STR_PAD_LEFT) ?></h2>
    <div style="font-size:12.5px; color:var(--admin-text-muted);">
      Dibuat pada: <?= date('d F Y, H:i', strtotime($pesanan['tanggal_pesanan'])) ?> WIB
    </div>
  </div>
  <a href="<?= BASE_URL ?>admin/pesanan.php" class="btn-admin btn-admin-outline btn-admin-sm">← Kembali ke Daftar Pesanan</a>
</div>

<?php if (!empty($success)): ?>
  <div style="background:#dcfce7; color:#166534; padding:12px 20px; border-radius:6px; margin-bottom:20px; font-size:13px;">
    ✓ <?= htmlspecialchars($success) ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; align-items: flex-start;">
  <!-- Left: Ordered Products & Delivery -->
  <div>
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Item Pesanan Pelanggan (<?= count($items) ?> Produk)</h3>
      </div>
      <div class="card-body" style="padding: 0;">
        <table class="table">
          <thead>
            <tr>
              <th>Produk</th>
              <th style="text-align: right;">Harga Satuan</th>
              <th style="text-align: center;">Jumlah</th>
              <th style="text-align: right;">Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $it): ?>
              <tr>
                <td>
                  <div style="display:flex; gap:12px; align-items:center;">
                    <div style="width:48px; height:48px; border-radius:6px; overflow:hidden; background:#eee; flex-shrink:0;">
                      <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($it['gambar']) ?>" onerror="this.src='../assets/images/banners/hero-1.jpg'" style="width:100%; height:100%; object-fit:cover;">
                    </div>
                    <div>
                      <b><?= htmlspecialchars($it['nama_produk']) ?></b>
                      <div style="font-size:11px; color:#888;">ID: #<?= $it['id_produk'] ?></div>
                    </div>
                  </div>
                </td>
                <td style="text-align: right;"><?= format_rupiah($it['harga']) ?></td>
                <td style="text-align: center;"><b><?= $it['jumlah'] ?></b></td>
                <td style="text-align: right; font-weight:700; color:var(--admin-primary);"><?= format_rupiah($it['subtotal']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3" style="text-align:right; font-weight:700; padding:16px;">Total Pembayaran:</td>
              <td style="text-align:right; font-weight:800; font-size:16px; color:var(--admin-primary); padding:16px;"><?= format_rupiah($pesanan['total_harga']) ?></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>

    <!-- Data Pengiriman -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Alamat & Catatan Pengiriman</h3>
      </div>
      <div class="card-body">
        <div style="font-size:13.5px; line-height:1.7;">
          <div style="margin-bottom:12px;">
            <b>Alamat Pengiriman Lengkap:</b><br>
            <?= nl2br(htmlspecialchars($pesanan['alamat_pengiriman'])) ?>
          </div>
          <?php if (!empty($pesanan['note'])): ?>
            <div style="background:#f8fafc; padding:12px; border-radius:6px; border-left:3px solid #3b82f6;">
              <b>Catatan dari Pembeli:</b><br>
              <?= nl2br(htmlspecialchars($pesanan['note'])) ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Right: Order Status & Payment -->
  <div>
    <!-- Form Update Status -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Ubah Status Pesanan</h3>
      </div>
      <div class="card-body">
        <form method="POST" action="">
          <input type="hidden" name="update_status" value="1">
          <div class="form-group">
            <label class="form-label">Status Saat Ini:</label>
            <select name="status" class="form-control" style="font-weight:600;">
              <option value="Menunggu Pembayaran" <?= $pesanan['status'] === 'Menunggu Pembayaran' ? 'selected' : '' ?>>Menunggu Pembayaran</option>
              <option value="Diproses" <?= $pesanan['status'] === 'Diproses' ? 'selected' : '' ?>>Diproses (Siap Kirim)</option>
              <option value="Dikirim" <?= $pesanan['status'] === 'Dikirim' ? 'selected' : '' ?>>Dikirim (Dalam Ekspedisi)</option>
              <option value="Selesai" <?= $pesanan['status'] === 'Selesai' ? 'selected' : '' ?>>Selesai (Diterima Pembeli)</option>
              <option value="Dibatalkan" <?= $pesanan['status'] === 'Dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
            </select>
          </div>
          <button type="submit" class="btn-admin btn-admin-primary" style="width:100%; justify-content:center; padding:10px;">
            Perbarui Status Pesanan
          </button>
        </form>
      </div>
    </div>

    <!-- Info Pembayaran -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Informasi Pembayaran</h3>
      </div>
      <div class="card-body">
        <div style="display:flex; flex-direction:column; gap:10px; font-size:13px;">
          <div>
            <span style="color:#888;">Metode Pembayaran:</span><br>
            <b><?= htmlspecialchars($pesanan['metode'] ?: 'Transfer Bank') ?></b>
          </div>
          <div>
            <span style="color:#888;">Status Pembayaran:</span><br>
            <span class="status-badge <?= $pesanan['status_bayar'] === 'Dibayar' ? 'status-completed' : 'status-pending' ?>">
              <?= htmlspecialchars($pesanan['status_bayar'] ?: 'Belum Dibayar') ?>
            </span>
          </div>
          <?php if (!empty($pesanan['bukti_pembayaran'])): ?>
            <div style="margin-top:8px;">
              <span style="color:#888;">Bukti Transfer:</span><br>
              <a href="<?= UPLOADS_URL ?>payments/<?= htmlspecialchars($pesanan['bukti_pembayaran']) ?>" target="_blank" style="display:block; margin-top:6px; border:1px solid #ddd; border-radius:6px; overflow:hidden;">
                <img src="<?= UPLOADS_URL ?>payments/<?= htmlspecialchars($pesanan['bukti_pembayaran']) ?>" alt="Bukti Pembayaran" style="width:100%; max-height:160px; object-fit:contain; background:#f0f0f0;">
              </a>
              <small style="color:#888; display:block; margin-top:4px;">Klik gambar untuk memperbesar</small>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
