<?php
// admin/chat.php - Admin Live Chat Center
$admin_title = 'Pusat Live Chat Pelanggan';
include __DIR__ . '/includes/header.php';
?>

<div class="card" style="margin-bottom: 0;">
  <div class="admin-chat-layout">
    <!-- Left Pane: Conversation Threads List -->
    <div class="chat-threads-list">
      <div class="threads-header">
        Obrolan Pelanggan (<span id="threadCount">0</span>)
      </div>
      <div class="threads-scroll" id="threadsContainer">
        <div style="text-align:center; padding:30px; color:#888; font-size:13px;">
          Memuat percakapan...
        </div>
      </div>
    </div>

    <!-- Right Pane: Active Chat Conversation -->
    <div class="chat-active-box" id="chatActiveBox">
      <!-- Chat Header -->
      <div class="chat-active-header">
        <div style="display:flex; align-items:center; gap:12px;">
          <div class="thread-avatar" id="activeCustomerAvatar" style="background:var(--admin-primary); color:#fff;">?</div>
          <div>
            <h4 id="activeCustomerName" style="font-size:15px; font-weight:700;">Pilih Percakapan</h4>
            <div id="activeCustomerSub" style="font-size:12px; color:var(--admin-text-muted);">Pilih salah satu chat di sebelah kiri untuk membalas</div>
          </div>
        </div>
      </div>

      <!-- Messages Thread -->
      <div class="chat-active-messages" id="activeChatMessages">
        <div style="text-align:center; padding:60px 20px; color:#888;">
          <div style="font-size:48px; margin-bottom:12px;">💬</div>
          <p>Silakan klik salah satu obrolan pelanggan di daftar sebelah kiri untuk melihat percakapan dan membalas pesan.</p>
        </div>
      </div>

      <!-- Quick Canned Replies for Admin -->
      <div style="display: flex; gap: 8px; padding: 8px 24px; background:#fff; border-top:1px solid var(--admin-border); overflow-x:auto; white-space:nowrap;">
        <span style="font-size:11px; color:#888; align-self:center; font-weight:700;">Template Balasan:</span>
        <button type="button" class="btn-admin btn-admin-outline btn-admin-sm" onclick="setReplyTemplate('Halo Kak! Terima kasih sudah menghubungi SOREN.ID. Ada yang bisa kami bantu?')">Sapaan Ramah</button>
        <button type="button" class="btn-admin btn-admin-outline btn-admin-sm" onclick="setReplyTemplate('Produk tersebut ready stock kak dan siap kami kirimkan hari ini ya kak 💕')">Ready Stock</button>
        <button type="button" class="btn-admin btn-admin-outline btn-admin-sm" onclick="setReplyTemplate('Estimasi pengiriman reguler adalah 2-3 hari kerja setelah paket diserahkan ke kurir kak.')">Estimasi Kirim</button>
        <button type="button" class="btn-admin btn-admin-outline btn-admin-sm" onclick="setReplyTemplate('Baik kak, pesanan Kakak saat ini sudah kami packing dengan aman dan siap di-pickup ekspedisi ya!')">Info Pesanan</button>
      </div>

      <!-- Reply Input Bar -->
      <form class="chat-active-input" id="adminReplyForm" onsubmit="sendAdminReply(event)">
        <input type="text" id="adminReplyInput" placeholder="Ketik balasan untuk pelanggan..." disabled autocomplete="off">
        <button type="submit" class="btn-admin btn-admin-primary" id="btnAdminSend" disabled>
          Kirim Balasan
        </button>
      </form>
    </div>
  </div>
</div>

<script>
  let currentThreadKey = null;
  let pollInterval = null;

  function loadThreads() {
    fetch('<?= BASE_URL ?>api/chat.php?action=admin_get_threads')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          const container = document.getElementById('threadsContainer');
          document.getElementById('threadCount').textContent = data.threads.length;

          if (data.threads.length === 0) {
            container.innerHTML = '<div style="text-align:center; padding:30px; color:#888; font-size:13px;">Belum ada pesan obrolan.</div>';
            return;
          }

          let html = '';
          data.threads.forEach(t => {
            const isActive = t.thread_key === currentThreadKey;
            const unreadBadge = t.unread_count > 0 ? `<span class="nav-counter">${t.unread_count}</span>` : '';
            const initial = t.customer_name ? t.customer_name.charAt(0).toUpperCase() : 'P';

            html += `
              <div class="thread-item ${isActive ? 'active' : ''}" onclick="selectThread('${t.thread_key}', '${escapeJs(t.customer_name)}')">
                <div class="thread-avatar">${initial}</div>
                <div class="thread-info">
                  <div class="thread-name">
                    <span>${escapeHtml(t.customer_name)}</span>
                    <span style="font-size:11px; color:#888; font-weight:normal;">${t.time_formatted}</span>
                  </div>
                  <div class="thread-preview">
                    ${t.last_sender === 'admin' ? '<span style="color:var(--admin-primary);">Anda: </span>' : ''}
                    ${escapeHtml(t.last_message || '')}
                  </div>
                </div>
                <div>${unreadBadge}</div>
              </div>
            `;
          });
          container.innerHTML = html;
        }
      })
      .catch(err => console.error('Error fetching threads:', err));
  }

  function selectThread(threadKey, customerName) {
    currentThreadKey = threadKey;
    document.getElementById('activeCustomerName').textContent = customerName;
    document.getElementById('activeCustomerSub').textContent = 'Percakapan Langsung • ID: ' + threadKey;
    document.getElementById('activeCustomerAvatar').textContent = customerName.charAt(0).toUpperCase();

    document.getElementById('adminReplyInput').disabled = false;
    document.getElementById('btnAdminSend').disabled = false;
    document.getElementById('adminReplyInput').focus();

    loadThreadMessages();
    loadThreads(); // Refresh thread unread counts
  }

  function loadThreadMessages() {
    if (!currentThreadKey) return;

    fetch(`<?= BASE_URL ?>api/chat.php?action=admin_get_thread_messages&thread_key=${encodeURIComponent(currentThreadKey)}`)
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          const box = document.getElementById('activeChatMessages');
          box.innerHTML = '';

          if (data.messages.length === 0) {
            box.innerHTML = '<div style="text-align:center; padding:40px; color:#888;">Belum ada pesan dalam obrolan ini.</div>';
            return;
          }

          data.messages.forEach(m => {
            const bubble = document.createElement('div');
            bubble.className = `admin-bubble ${m.pengirim}`;
            bubble.innerHTML = `
              <div style="font-size:11px; margin-bottom:3px; opacity:0.8; font-weight:600;">${escapeHtml(m.nama_pengirim)}</div>
              <div>${escapeHtml(m.pesan)}</div>
              <div style="font-size:10px; margin-top:4px; opacity:0.7; text-align:right;">${m.waktu || ''}</div>
            `;
            box.appendChild(bubble);
          });
          box.scrollTop = box.scrollHeight;
        }
      })
      .catch(err => console.error('Error fetching thread messages:', err));
  }

  function sendAdminReply(e) {
    e.preventDefault();
    const input = document.getElementById('adminReplyInput');
    const text = input.value.trim();

    if (!text || !currentThreadKey) return;

    const formData = new FormData();
    formData.append('thread_key', currentThreadKey);
    formData.append('pesan', text);

    input.value = '';

    fetch('<?= BASE_URL ?>api/chat.php?action=admin_send_message', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          loadThreadMessages();
          loadThreads();
        } else {
          alert(data.message);
        }
      })
      .catch(err => console.error('Send reply error:', err));
  }

  function setReplyTemplate(text) {
    const input = document.getElementById('adminReplyInput');
    if (!input.disabled) {
      input.value = text;
      input.focus();
    }
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function escapeJs(str) {
    return (str || '').replace(/'/g, "\\'");
  }

  // Polling setup
  loadThreads();
  setInterval(() => {
    loadThreads();
    if (currentThreadKey) {
      loadThreadMessages();
    }
  }, 3000);
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
