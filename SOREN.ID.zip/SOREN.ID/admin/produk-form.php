<?php
// admin/produk-form.php - Add & Edit Product Form
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
$is_edit = $id > 0;
$admin_title = $is_edit ? 'Edit Produk' : 'Tambah Produk Baru';

$categories = get_categories($pdo);
$error = '';
$success = '';

$p = [
    'nama_produk' => '',
    'id_kategori' => $categories[0]['id'] ?? 1,
    'harga' => '',
    'stok' => 10,
    'ukuran' => 'All Size',
    'warna' => '',
    'deskripsi' => '',
    'gambar' => ''
];

if ($is_edit) {
    $stmt = $pdo->prepare("SELECT * FROM produk WHERE id = ?");
    $stmt->execute([$id]);
    $existing = $stmt->fetch();
    if ($existing) {
        $p = $existing;
    } else {
        header('Location: ' . BASE_URL . 'admin/produk.php');
        exit;
    }

    // Handle Hapus Foto langsung dari form edit
    if (isset($_GET['action']) && $_GET['action'] === 'hapus_foto' || isset($_GET['hapus_foto'])) {
        if (!empty($p['gambar'])) {
            $old_filename = $p['gambar'];
            // Cek apakah file gambar ini masih digunakan oleh produk lain
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM produk WHERE gambar = ? AND id != ?");
            $check_stmt->execute([$old_filename, $id]);
            $is_used_elsewhere = (int)$check_stmt->fetchColumn() > 0;

            if (!$is_used_elsewhere) {
                $file_path = __DIR__ . '/../uploads/products/' . $old_filename;
                if (file_exists($file_path)) {
                    @unlink($file_path);
                }
            }

            $upd_stmt = $pdo->prepare("UPDATE produk SET gambar = NULL WHERE id = ?");
            $upd_stmt->execute([$id]);

            $_SESSION['flash_success'] = 'Foto produk berhasil dihapus.';
        }
        header('Location: ' . BASE_URL . 'admin/produk-form.php?id=' . $id);
        exit;
    }
}

if (!empty($_SESSION['flash_success'])) {
    $success = $_SESSION['flash_success'];
    unset($_SESSION['flash_success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_produk = clean_input($_POST['nama_produk'] ?? '');
    $id_kategori = (int)($_POST['id_kategori'] ?? 1);
    $harga = (float)($_POST['harga'] ?? 0);
    $stok = (int)($_POST['stok'] ?? 0);
    $ukuran = clean_input($_POST['ukuran'] ?? 'All Size');
    $warna = clean_input($_POST['warna'] ?? '');
    $deskripsi = clean_input($_POST['deskripsi'] ?? '');
    $hapus_foto = !empty($_POST['hapus_foto']);
    $gambar = $p['gambar'];

    // Jika opsi hapus foto dicentang dan tidak ada file baru diunggah
    if ($is_edit && $hapus_foto && (empty($_FILES['gambar']['name']) || $_FILES['gambar']['error'] !== UPLOAD_ERR_OK)) {
        if (!empty($p['gambar'])) {
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM produk WHERE gambar = ? AND id != ?");
            $check_stmt->execute([$p['gambar'], $id]);
            if ((int)$check_stmt->fetchColumn() === 0) {
                $old_image = __DIR__ . '/../uploads/products/' . $p['gambar'];
                if (file_exists($old_image)) {
                    @unlink($old_image);
                }
            }
            $gambar = null;
        }
    }

    if (empty($nama_produk) || $harga <= 0) {
        $error = 'Nama produk dan harga yang valid wajib diisi.';
    } else {
        // Upload Gambar jika ada
        if (!empty($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $target_dir = __DIR__ . '/../uploads/products';
            $up = upload_image($_FILES['gambar'], $target_dir, 'prod');
            if ($up['success']) {
                if ($is_edit && !empty($p['gambar']) && $p['gambar'] !== $up['filename']) {
                    // Cek apakah gambar lama masih dipakai produk lain sebelum di-unlink
                    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM produk WHERE gambar = ? AND id != ?");
                    $check_stmt->execute([$p['gambar'], $id]);
                    if ((int)$check_stmt->fetchColumn() === 0) {
                        $old_image = $target_dir . DIRECTORY_SEPARATOR . $p['gambar'];
                        if (file_exists($old_image)) {
                            @unlink($old_image);
                        }
                    }
                }
                $gambar = $up['filename'];
            } else {
                $error = $up['message'];
            }
        }

        if (empty($error)) {
            if ($is_edit) {
                $sql = "UPDATE produk SET nama_produk = ?, id_kategori = ?, harga = ?, stok = ?, ukuran = ?, warna = ?, deskripsi = ?, gambar = ? WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$nama_produk, $id_kategori, $harga, $stok, $ukuran, $warna, $deskripsi, $gambar, $id]);
                $_SESSION['flash_success'] = 'Produk berhasil diperbarui!';
                header('Location: ' . BASE_URL . 'admin/produk.php');
                exit;
            } else {
                $sql = "INSERT INTO produk (nama_produk, id_kategori, harga, stok, ukuran, warna, deskripsi, gambar) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$nama_produk, $id_kategori, $harga, $stok, $ukuran, $warna, $deskripsi, $gambar]);
                $_SESSION['flash_success'] = 'Produk baru berhasil ditambahkan!';
                header('Location: ' . BASE_URL . 'admin/produk.php');
                exit;
            }
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="card" style="max-width: 800px; margin: 0 auto;">
  <div class="card-header">
    <h3 class="card-title"><?= $is_edit ? 'Edit Data Produk' : 'Tambah Produk Baru' ?></h3>
    <a href="<?= BASE_URL ?>admin/produk.php" class="btn-admin btn-admin-outline btn-admin-sm">← Batal & Kembali</a>
  </div>

  <?php if (!empty($success)): ?>
    <div style="background:#dcfce7; color:#166534; padding:12px 20px; border-radius:6px; margin: 16px 24px 0 24px; font-size:13px; display:flex; align-items:center; gap:8px;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
      <span><?= htmlspecialchars($success) ?></span>
    </div>
  <?php endif; ?>

  <?php if (!empty($error)): ?>
    <div style="background:#fee2e2; color:#b91c1c; padding:12px 20px; border-radius:6px; margin: 16px 24px 0 24px; font-size:13px; display:flex; align-items:center; gap:8px;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
      <span><?= htmlspecialchars($error) ?></span>
    </div>
  <?php endif; ?>

  <div class="card-body">
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label class="form-label">Nama Produk *</label>
        <input type="text" name="nama_produk" class="form-control" value="<?= htmlspecialchars($p['nama_produk']) ?>" placeholder="Contoh: Pashmina Silk Cradenza" required>
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="form-group">
          <label class="form-label">Kategori *</label>
          <select name="id_kategori" class="form-control" required>
            <?php foreach ($categories as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $p['id_kategori'] == $c['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['nama_kategori']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Harga Produk (Rp) *</label>
          <input type="number" name="harga" class="form-control" value="<?= $p['harga'] ?>" placeholder="Contoh: 79000" required>
        </div>
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="form-group">
          <label class="form-label">Jumlah Stok Tersedia *</label>
          <input type="number" name="stok" class="form-control" value="<?= $p['stok'] ?>" required>
        </div>

        <div class="form-group">
          <label class="form-label">Ukuran / Dimensi</label>
          <input type="text" name="ukuran" class="form-control" value="<?= htmlspecialchars($p['ukuran']) ?>" placeholder="Contoh: 180 x 75 cm / All Size">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Pilihan Varian Warna (Pisahkan dengan koma)</label>
        <input type="text" name="warna" class="form-control" value="<?= htmlspecialchars($p['warna']) ?>" placeholder="Contoh: Rose Taupe, Soft Beige, Mauve, Champagne">
      </div>

      <div class="form-group">
        <label class="form-label">Deskripsi Lengkap Produk</label>
        <textarea name="deskripsi" rows="4" class="form-control" placeholder="Jelaskan karakteristik bahan, keunggulan, dan saran pemakaian..."><?= htmlspecialchars($p['deskripsi']) ?></textarea>
      </div>

      <div class="form-group">
        <label class="form-label" style="display:flex; justify-content:space-between; align-items:center;">
          <span>Foto Produk (JPG, PNG, WEBP)</span>
          <span style="font-size:12px; font-weight:normal; color:#64748b;">Maksimal 5MB</span>
        </label>
        <?php if (!empty($p['gambar'])): ?>
          <div style="margin-bottom: 12px; padding: 12px 14px; border: 1px solid #e2e8f0; border-radius: 8px; background: #f8fafc; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($p['gambar']) ?>" onerror="this.src='../assets/images/banners/hero-1.jpg'" style="width:68px; height:68px; object-fit:cover; border-radius:6px; border:1px solid #cbd5e1; box-shadow:0 1px 3px rgba(0,0,0,0.08);">
              <div>
                <div style="font-weight: 600; font-size: 13.5px; color: var(--admin-text-dark); word-break: break-all;">
                  <?= htmlspecialchars($p['gambar']) ?>
                </div>
                <div style="font-size: 12px; color: #16a34a; margin-top: 2px; display:flex; align-items:center; gap:4px;">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Foto produk saat ini</span>
                </div>
              </div>
            </div>
            
            <a href="<?= BASE_URL ?>admin/produk-form.php?id=<?= $p['id'] ?>&action=hapus_foto" 
               class="btn-admin btn-admin-danger btn-admin-sm" 
               onclick="return confirm('Apakah Anda yakin ingin menghapus foto produk ini? Tindakan ini akan segera menghapus foto dari sistem.');"
               style="background:#fee2e2; color:#b91c1c; border:1px solid #fecaca; font-weight:600; padding:7px 14px; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
              <span>Hapus Foto Sekarang</span>
            </a>
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: inline-flex; align-items: center; gap: 8px; font-size: 13px; color: #b91c1c; cursor: pointer; user-select: none;">
              <input type="checkbox" name="hapus_foto" value="1" id="checkHapusFoto">
              <span>Hapus foto saat ini saat formulir disimpan (tanpa mengganti dengan foto baru)</span>
            </label>
          </div>
        <?php else: ?>
          <div style="padding: 10px 14px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; margin-bottom: 12px; color: #64748b; font-size: 12.5px; display: flex; align-items: center; gap: 8px;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
              <circle cx="12" cy="13" r="4"></circle>
            </svg>
            <span>Produk ini belum memiliki foto. Silakan unggah gambar di bawah jika ingin menambahkan foto baru.</span>
          </div>
        <?php endif; ?>

        <input type="file" name="gambar" accept="image/jpeg,image/png,image/webp" class="form-control">
        <div style="font-size: 11.5px; color: #94a3b8; margin-top: 4px;">
          <?= !empty($p['gambar']) ? 'Pilih file baru jika ingin mengganti foto produk di atas.' : 'Format yang didukung: JPG, PNG, WEBP.' ?>
        </div>
      </div>

      <div style="margin-top: 24px;">
        <button type="submit" class="btn-admin btn-admin-primary" style="padding: 10px 24px;">
          <?= $is_edit ? 'Simpan Perubahan Produk' : 'Terbitkan Produk Baru' ?>
        </button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
