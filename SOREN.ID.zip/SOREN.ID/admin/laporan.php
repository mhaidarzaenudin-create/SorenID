<?php
// admin/laporan.php - Financial Income Reports & Customer Feedback (Kritik Saran)
$admin_title = 'Laporan Pemasukan & Kritik Saran';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$success = '';

// Handle Tandai Dibaca Kritik
if (isset($_GET['baca_kritik'])) {
    $id_k = (int)$_GET['baca_kritik'];
    $pdo->prepare("UPDATE kritik_saran SET status = 'Sudah Dibaca' WHERE id = ?")->execute([$id_k]);
    $success = 'Kritik & saran ditandai sudah dibaca.';
}

// Ambil data pemasukan
$stmt_income = $pdo->query("SELECT * FROM pemasukan ORDER BY tanggal DESC, id DESC");
$incomes = $stmt_income->fetchAll();

$total_omset = array_sum(array_column($incomes, 'jumlah'));

// Ambil data kritik saran
$stmt_kritik = $pdo->query("
    SELECT ks.*, usr.nama as customer_name, usr.email as customer_email
    FROM kritik_saran ks
    JOIN users usr ON ks.id_user = usr.id
    ORDER BY ks.id DESC
");
$feedbacks = $stmt_kritik->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<?php if (!empty($success)): ?>
  <div style="background:#dcfce7; color:#166534; padding:12px 20px; border-radius:6px; margin-bottom:20px; font-size:13px;">
    ✓ <?= htmlspecialchars($success) ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 3fr 2fr; gap: 24px; align-items: flex-start;">
  <!-- Laporan Pemasukan -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Buku Kas & Pemasukan Penjualan</h3>
      <div style="font-weight:700; color:var(--admin-primary); font-size:16px;">
        Total: <?= format_rupiah($total_omset) ?>
      </div>
    </div>
    <div class="card-body">
      <table class="table">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Keterangan Transaksi</th>
            <th>No. Pesanan</th>
            <th style="text-align: right;">Jumlah</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($incomes)): ?>
            <tr><td colspan="4" style="text-align:center; padding:24px; color:#888;">Belum ada catatan pemasukan.</td></tr>
          <?php else: ?>
            <?php foreach ($incomes as $inc): ?>
              <tr>
                <td><?= date('d/m/Y', strtotime($inc['tanggal'])) ?></td>
                <td><?= htmlspecialchars($inc['keterangan']) ?></td>
                <td>
                  <?php if ($inc['id_pesanan']): ?>
                    <a href="<?= BASE_URL ?>admin/pesanan-detail.php?id=<?= $inc['id_pesanan'] ?>" style="color:var(--admin-primary); font-weight:600;">
                      #SOREN-<?= str_pad($inc['id_pesanan'], 5, '0', STR_PAD_LEFT) ?>
                    </a>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td style="text-align: right; font-weight:700; color:#16a34a;">
                  + <?= format_rupiah($inc['jumlah']) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Kritik & Saran -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Kritik & Saran Pelanggan (<?= count($feedbacks) ?>)</h3>
    </div>
    <div class="card-body">
      <?php if (empty($feedbacks)): ?>
        <p style="text-align:center; color:#888; padding:20px; font-size:13px;">Belum ada kritik & saran masuk.</p>
      <?php else: ?>
        <div style="display:flex; flex-direction:column; gap:16px;">
          <?php foreach ($feedbacks as $fb): ?>
            <div style="border:1px solid var(--admin-border); border-radius:8px; padding:14px; background:#fcfcfd;">
              <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:6px;">
                <div>
                  <b style="font-size:13.5px;"><?= htmlspecialchars($fb['customer_name']) ?></b>
                  <div style="font-size:11px; color:#888;"><?= htmlspecialchars($fb['customer_email']) ?> • <?= date('d/m/Y H:i', strtotime($fb['tanggal'])) ?></div>
                </div>
                <span class="status-badge <?= $fb['status'] === 'Sudah Dibaca' ? 'status-completed' : 'status-pending' ?>">
                  <?= htmlspecialchars($fb['status']) ?>
                </span>
              </div>
              <div style="font-size:13px; color:#333; line-height:1.5; margin-bottom:10px;">
                "<?= nl2br(htmlspecialchars($fb['isi'])) ?>"
              </div>
              <?php if ($fb['status'] !== 'Sudah Dibaca'): ?>
                <a href="<?= BASE_URL ?>admin/laporan.php?baca_kritik=<?= $fb['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm">
                  ✓ Tandai Sudah Dibaca
                </a>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
