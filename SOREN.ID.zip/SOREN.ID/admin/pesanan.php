<?php
// admin/pesanan.php - Order List & Status Filtering
$admin_title = 'Daftar Pesanan Pelanggan';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$filter_status = $_GET['status'] ?? '';
$sql = "
    SELECT p.*, usr.nama as customer_name, usr.no_hp as customer_phone, pb.metode, pb.status as status_bayar
    FROM pesanan p
    JOIN users usr ON p.id_user = usr.id
    LEFT JOIN pembayaran pb ON p.id = pb.id_pesanan
    WHERE 1=1
";
$params = [];

if (!empty($filter_status)) {
    $sql .= " AND p.status = ?";
    $params[] = $filter_status;
}

$sql .= " ORDER BY p.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="card">
  <div class="card-header" style="flex-wrap:wrap; gap:12px;">
    <h3 class="card-title">Daftar Semua Pesanan (<?= count($orders) ?>)</h3>
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      <a href="<?= BASE_URL ?>admin/pesanan.php" class="btn-admin btn-admin-outline btn-admin-sm <?= empty($filter_status) ? 'btn-admin-primary' : '' ?>">Semua</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=Menunggu Pembayaran" class="btn-admin btn-admin-outline btn-admin-sm <?= $filter_status === 'Menunggu Pembayaran' ? 'btn-admin-primary' : '' ?>">Menunggu Bayar</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=Diproses" class="btn-admin btn-admin-outline btn-admin-sm <?= $filter_status === 'Diproses' ? 'btn-admin-primary' : '' ?>">Diproses</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=Dikirim" class="btn-admin btn-admin-outline btn-admin-sm <?= $filter_status === 'Dikirim' ? 'btn-admin-primary' : '' ?>">Dikirim</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=Selesai" class="btn-admin btn-admin-outline btn-admin-sm <?= $filter_status === 'Selesai' ? 'btn-admin-primary' : '' ?>">Selesai</a>
    </div>
  </div>

  <div class="card-body">
    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th>No. Pesanan</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Metode Bayar</th>
            <th>Total Belanja</th>
            <th>Status Pesanan</th>
            <th style="text-align: center;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($orders)): ?>
            <tr><td colspan="7" style="text-align:center; padding:30px; color:#888;">Tidak ada pesanan pada filter ini.</td></tr>
          <?php else: ?>
            <?php foreach ($orders as $ord): 
              $st_badge = 'status-pending';
              if ($ord['status'] === 'Diproses') $st_badge = 'status-process';
              elseif ($ord['status'] === 'Dikirim') $st_badge = 'status-shipped';
              elseif ($ord['status'] === 'Selesai') $st_badge = 'status-completed';
              elseif ($ord['status'] === 'Dibatalkan') $st_badge = 'status-cancelled';
            ?>
              <tr>
                <td><b>#SOREN-<?= str_pad($ord['id'], 5, '0', STR_PAD_LEFT) ?></b></td>
                <td>
                  <div style="font-size:12.5px;"><?= date('d/m/Y', strtotime($ord['tanggal_pesanan'])) ?></div>
                  <div style="font-size:11px; color:#888;"><?= date('H:i', strtotime($ord['tanggal_pesanan'])) ?> WIB</div>
                </td>
                <td>
                  <div style="font-weight:700; color:var(--admin-text-dark);"><?= htmlspecialchars($ord['customer_name']) ?></div>
                  <div style="font-size:11.5px; color:#888;"><?= htmlspecialchars($ord['customer_phone'] ?: '-') ?></div>
                </td>
                <td>
                  <div style="font-size:12.5px; font-weight:600;"><?= htmlspecialchars($ord['metode'] ?: 'Transfer') ?></div>
                  <div style="font-size:11px; color:#888;">Status: <?= htmlspecialchars($ord['status_bayar'] ?: 'Belum') ?></div>
                </td>
                <td style="font-weight:700; color:var(--admin-primary);">
                  <?= format_rupiah($ord['total_harga']) ?>
                </td>
                <td>
                  <span class="status-badge <?= $st_badge ?>">
                    <?= htmlspecialchars($ord['status']) ?>
                  </span>
                </td>
                <td style="text-align: center;">
                  <a href="<?= BASE_URL ?>admin/pesanan-detail.php?id=<?= $ord['id'] ?>" class="btn-admin btn-admin-primary btn-admin-sm">
                    Detail & Proses
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
