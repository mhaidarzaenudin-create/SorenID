<?php
// admin/banner.php - Kelola Banner Diskon & Iklan Video SOREN.ID
$admin_title = 'Kelola Iklan Video & Banner Diskon';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$error   = '';
$success = '';
$edit_data = null;

// Pastikan folder penyimpanan tersedia
$banner_dir = __DIR__ . '/../uploads/banners/';
$video_dir  = __DIR__ . '/../uploads/banners/videos/';
if (!is_dir($banner_dir)) @mkdir($banner_dir, 0777, true);
if (!is_dir($video_dir))  @mkdir($video_dir, 0777, true);

// ── Auto-Migration check: pastikan kolom-kolom baru selalu ada ────────────────
try {
    $col_check = $pdo->query("SHOW COLUMNS FROM `banner_diskon` LIKE 'tipe'")->fetch();
    if (!$col_check) {
        $pdo->exec("ALTER TABLE `banner_diskon` ADD COLUMN `tipe` VARCHAR(20) NOT NULL DEFAULT 'diskon' AFTER `id`");
        $pdo->exec("ALTER TABLE `banner_diskon` ADD COLUMN `video_tipe` VARCHAR(20) DEFAULT 'upload' AFTER `tipe`");
        $pdo->exec("ALTER TABLE `banner_diskon` ADD COLUMN `video_url` VARCHAR(500) NULL AFTER `video_tipe`");
        $pdo->exec("ALTER TABLE `banner_diskon` ADD COLUMN `video_file` VARCHAR(255) NULL AFTER `video_url`");
        $pdo->exec("ALTER TABLE `banner_diskon` ADD COLUMN `video_loop` TINYINT(1) NOT NULL DEFAULT 1 AFTER `video_file`");
        $pdo->exec("ALTER TABLE `banner_diskon` ADD COLUMN `video_muted` TINYINT(1) NOT NULL DEFAULT 1 AFTER `video_loop`");
        $pdo->exec("ALTER TABLE `banner_diskon` MODIFY COLUMN `gambar` VARCHAR(255) NULL");
    }
} catch (Exception $e) {
    // Kolom sudah ada
}

// Ambil semua produk untuk dropdown kaitkan produk
$all_products = $pdo->query("SELECT id, nama_produk, gambar, harga FROM produk ORDER BY nama_produk ASC")->fetchAll();

// ── Tentukan mode: list | form_add | form_edit ──────────────────────────────
$mode   = 'list';
$edit_id = (int)($_GET['edit'] ?? 0);
if ($edit_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM banner_diskon WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_data = $stmt->fetch();
    if ($edit_data) $mode = 'form_edit';
}
if (isset($_GET['tambah'])) $mode = 'form_add';

// ── Helper upload gambar poster/banner ──────────────────────────────────────
if (!function_exists('upload_banner_image')) {
    function upload_banner_image(array $file): string|false
    {
        $allowed_exts  = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        
        $mime = mime_content_type($file['tmp_name']) ?: $file['type'];
        $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed_exts) || !in_array($mime, $allowed_mimes)) return false;
        if ($file['size'] > 5 * 1024 * 1024) return false; // maks 5 MB

        $filename = 'banner_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $dest     = __DIR__ . '/../uploads/banners/' . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dest)) return false;
        return $filename;
    }
}

// ── Helper upload video MP4/WebM ───────────────────────────────────────────
if (!function_exists('upload_banner_video')) {
    function upload_banner_video(array $file): string|false
    {
        $allowed_exts  = ['mp4', 'webm', 'ogg', 'mov'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed_exts)) return false;
        if ($file['size'] > 40 * 1024 * 1024) return false; // maks 40 MB

        $filename = 'video_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $dest     = __DIR__ . '/../uploads/banners/videos/' . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dest)) return false;
        return $filename;
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// POST HANDLER (TAMBAH / EDIT / HAPUS / TOGGLE)
// ══════════════════════════════════════════════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── SIMPAN (TAMBAH / EDIT) ──────────────────────────────────────────────
    if (in_array($action, ['tambah', 'edit'])) {
        $tipe         = in_array($_POST['tipe'] ?? '', ['diskon', 'video']) ? $_POST['tipe'] : 'diskon';
        $judul        = trim($_POST['judul']        ?? '');
        $link_url     = trim($_POST['link_url']     ?? '');
        $urutan       = (int)($_POST['urutan']      ?? 0);
        $aktif        = isset($_POST['aktif']) ? 1 : 0;

        // Field khusus Diskon Produk
        $subjudul     = ($tipe === 'diskon') ? trim($_POST['subjudul'] ?? '') : '';
        $label_diskon = ($tipe === 'diskon') ? trim($_POST['label_diskon'] ?? '') : '';
        $teks_tombol  = ($tipe === 'diskon') ? trim($_POST['teks_tombol'] ?? 'Belanja Sekarang') : '';
        $harga_asli   = ($tipe === 'diskon' && $_POST['harga_asli'] !== '')   ? (float)$_POST['harga_asli']   : null;
        $harga_diskon = ($tipe === 'diskon' && $_POST['harga_diskon'] !== '') ? (float)$_POST['harga_diskon'] : null;
        $id_produk    = ($tipe === 'diskon' && !empty($_POST['id_produk']))   ? (int)$_POST['id_produk']      : null;
        $warna_bg     = preg_match('/^#[0-9a-fA-F]{3,6}$/', $_POST['warna_bg'] ?? '') ? $_POST['warna_bg'] : ($tipe === 'video' ? '#000000' : '#1a1218');

        // Field khusus Iklan Video
        $video_tipe   = in_array($_POST['video_tipe'] ?? '', ['upload', 'url']) ? $_POST['video_tipe'] : 'upload';
        $video_url    = ($tipe === 'video' && $video_tipe === 'url') ? trim($_POST['video_url'] ?? '') : null;
        $video_loop   = ($tipe === 'video' && isset($_POST['video_loop'])) ? 1 : 0;
        $video_muted  = ($tipe === 'video' && isset($_POST['video_muted'])) ? 1 : 0;

        if ($judul === '') {
            $error = ($tipe === 'video') ? 'Nama iklan video tidak boleh kosong.' : 'Judul banner diskon tidak boleh kosong.';
        } elseif ($tipe === 'video' && $video_tipe === 'url' && empty($video_url)) {
            $error = 'Tautan URL video wajib diisi untuk iklan video berbasis link.';
        } else {
            // Upload Gambar Banner / Poster Video (jika ada)
            $gambar_baru = null;
            if (!empty($_FILES['gambar']['name'])) {
                $gambar_baru = upload_banner_image($_FILES['gambar']);
                if ($gambar_baru === false) {
                    $error = 'Upload gambar gagal. Pastikan format JPG/PNG/WEBP dan ukuran ≤ 5 MB.';
                }
            }

            // Upload File Video (jika tipe video upload)
            $video_file_baru = null;
            if ($tipe === 'video' && $video_tipe === 'upload' && !empty($_FILES['video_file']['name'])) {
                $video_file_baru = upload_banner_video($_FILES['video_file']);
                if ($video_file_baru === false) {
                    $error = 'Upload video gagal. Pastikan format MP4/WebM dan ukuran ≤ 40 MB.';
                }
            }

            if ($error === '') {
                if ($action === 'tambah') {
                    // Validasi Tambah Baru
                    if ($tipe === 'diskon' && !$gambar_baru) {
                        $error = 'Gambar banner latar wajib diunggah untuk banner diskon produk.';
                    } elseif ($tipe === 'video' && $video_tipe === 'upload' && !$video_file_baru) {
                        $error = 'File video (MP4/WebM) wajib diunggah untuk iklan video.';
                    } else {
                        $stmt_ins = $pdo->prepare("
                            INSERT INTO banner_diskon
                                (tipe, judul, subjudul, label_diskon, harga_asli, harga_diskon,
                                 gambar, video_tipe, video_url, video_file, video_loop, video_muted,
                                 link_url, teks_tombol, urutan, aktif, id_produk, warna_bg)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt_ins->execute([
                            $tipe, $judul, $subjudul, $label_diskon, $harga_asli, $harga_diskon,
                            $gambar_baru, $video_tipe, $video_url, $video_file_baru, $video_loop, $video_muted,
                            $link_url, $teks_tombol, $urutan, $aktif, $id_produk, $warna_bg
                        ]);
                        $success = ($tipe === 'video') ? 'Iklan video beranda (atas) berhasil ditambahkan!' : 'Banner diskon produk (bawah) berhasil ditambahkan!';
                        $mode    = 'list';
                    }
                } else {
                    // Edit Data
                    $bid = (int)$_POST['banner_id'];
                    $stmt_old = $pdo->prepare("SELECT gambar, video_file FROM banner_diskon WHERE id = ?");
                    $stmt_old->execute([$bid]);
                    $old_row = $stmt_old->fetch();

                    // Simpan gambar & hapus yang lama jika diganti
                    $gambar_final = $gambar_baru ?: ($old_row['gambar'] ?? null);
                    if ($gambar_baru && !empty($old_row['gambar'])) {
                        $old_img_path = __DIR__ . '/../uploads/banners/' . $old_row['gambar'];
                        if (file_exists($old_img_path)) @unlink($old_img_path);
                    }

                    // Simpan video file & hapus yang lama jika diganti
                    $video_file_final = $video_file_baru ?: ($old_row['video_file'] ?? null);
                    if ($video_file_baru && !empty($old_row['video_file'])) {
                        $old_vid_path = __DIR__ . '/../uploads/banners/videos/' . $old_row['video_file'];
                        if (file_exists($old_vid_path)) @unlink($old_vid_path);
                    }

                    $stmt_upd = $pdo->prepare("
                        UPDATE banner_diskon SET
                            tipe = ?, judul = ?, subjudul = ?, label_diskon = ?,
                            harga_asli = ?, harga_diskon = ?,
                            gambar = ?, video_tipe = ?, video_url = ?, video_file = ?,
                            video_loop = ?, video_muted = ?,
                            link_url = ?, teks_tombol = ?, urutan = ?, aktif = ?,
                            id_produk = ?, warna_bg = ?
                        WHERE id = ?
                    ");
                    $stmt_upd->execute([
                        $tipe, $judul, $subjudul, $label_diskon,
                        $harga_asli, $harga_diskon,
                        $gambar_final, $video_tipe, $video_url, $video_file_final,
                        $video_loop, $video_muted,
                        $link_url, $teks_tombol, $urutan, $aktif,
                        $id_produk, $warna_bg,
                        $bid
                    ]);
                    $success = 'Data promosi berhasil diperbarui!';
                    $mode    = 'list';
                }
            }
        }
    }

    // ── HAPUS ───────────────────────────────────────────────────────────────
    if ($action === 'hapus') {
        $bid = (int)$_POST['banner_id'];
        $stmt_del = $pdo->prepare("SELECT gambar, video_file FROM banner_diskon WHERE id = ?");
        $stmt_del->execute([$bid]);
        $del_row = $stmt_del->fetch();
        if ($del_row) {
            if (!empty($del_row['gambar'])) {
                $p = __DIR__ . '/../uploads/banners/' . $del_row['gambar'];
                if (file_exists($p)) @unlink($p);
            }
            if (!empty($del_row['video_file'])) {
                $vp = __DIR__ . '/../uploads/banners/videos/' . $del_row['video_file'];
                if (file_exists($vp)) @unlink($vp);
            }
            $pdo->prepare("DELETE FROM banner_diskon WHERE id = ?")->execute([$bid]);
            $success = 'Promosi berhasil dihapus.';
        }
    }

    // ── TOGGLE AKTIF ────────────────────────────────────────────────────────
    if ($action === 'toggle') {
        $bid = (int)$_POST['banner_id'];
        $pdo->prepare("UPDATE banner_diskon SET aktif = NOT aktif WHERE id = ?")->execute([$bid]);
        $success = 'Status visibilitas promosi berhasil diubah.';
    }
}

// Ambil semua banner untuk list dengan info produk
$banners = $pdo->query("
    SELECT b.*, p.nama_produk, p.gambar as gambar_produk, p.harga as harga_produk
    FROM banner_diskon b
    LEFT JOIN produk p ON b.id_produk = p.id
    ORDER BY b.urutan ASC, b.id ASC
")->fetchAll();

// Pisahkan banner video dan banner produk
$list_video  = array_values(array_filter($banners, fn($b) => ($b['tipe'] ?? 'diskon') === 'video'));
$list_diskon = array_values(array_filter($banners, fn($b) => ($b['tipe'] ?? 'diskon') === 'diskon'));

include __DIR__ . '/includes/header.php';
?>

<style>
/* ── Reset & Container Styles ── */
.banner-admin-page {
  width: 100%;
}

/* ── Top Header Actions ── */
.btn-top-video {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: #2563eb;
  color: #ffffff !important;
  font-weight: 700;
  font-size: 13.5px;
  padding: 10px 20px;
  border-radius: 10px;
  text-decoration: none;
  border: 1px solid #1d4ed8;
  box-shadow: 0 4px 14px rgba(37, 99, 235, 0.28);
  transition: all 0.2s ease;
}
.btn-top-video:hover {
  background: #1d4ed8;
  transform: translateY(-1px);
  box-shadow: 0 6px 18px rgba(37, 99, 235, 0.35);
}

.btn-top-diskon {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: #ffffff;
  color: #e11d48 !important;
  font-weight: 700;
  font-size: 13.5px;
  padding: 10px 18px;
  border-radius: 10px;
  text-decoration: none;
  border: 1.5px solid #fecdd3;
  box-shadow: 0 2px 8px rgba(225, 29, 72, 0.08);
  transition: all 0.2s ease;
}
.btn-top-diskon:hover {
  background: #fff1f2;
  border-color: #f43f5e;
  transform: translateY(-1px);
}

/* ── Metric Stats Counter Grid ── */
.promo-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 18px;
  margin-bottom: 26px;
}
@media (max-width: 1024px) {
  .promo-stats-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .promo-stats-grid { grid-template-columns: 1fr; }
}

.promo-stat-card {
  background: #ffffff;
  border-radius: 14px;
  padding: 18px 22px;
  border: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.promo-stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 18px rgba(0, 0, 0, 0.05);
}
.promo-stat-card .stat-val {
  font-size: 26px;
  font-weight: 800;
  color: #0f172a;
  line-height: 1.1;
  margin-bottom: 4px;
}
.promo-stat-card .stat-lbl {
  font-size: 12.5px;
  font-weight: 600;
  color: #64748b;
}
.promo-stat-icon-box {
  width: 46px;
  height: 46px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}

/* ── Filter Tabs Segmented Control ── */
.filter-pill-nav {
  display: inline-flex;
  align-items: center;
  background: #f1f5f9;
  padding: 5px;
  border-radius: 12px;
  gap: 4px;
  margin-bottom: 28px;
  border: 1px solid #e2e8f0;
  flex-wrap: wrap;
}
.filter-pill {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 8px 18px;
  border-radius: 9px;
  border: none;
  background: transparent;
  color: #475569;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
  outline: none;
}
.filter-pill:hover {
  color: #0f172a;
  background: rgba(255, 255, 255, 0.7);
}
.filter-pill.active {
  background: #ffffff;
  color: #0f172a;
  font-weight: 700;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}
.filter-pill .count-badge {
  background: #e2e8f0;
  color: #475569;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  transition: background 0.2s ease, color 0.2s ease;
}
.filter-pill.active .count-badge {
  background: #0f172a;
  color: #ffffff;
}
.filter-pill.active[data-filter="video"] .count-badge {
  background: #2563eb;
  color: #ffffff;
}
.filter-pill.active[data-filter="diskon"] .count-badge {
  background: #e11d48;
  color: #ffffff;
}
.filter-pill.active[data-filter="active"] .count-badge {
  background: #16a34a;
  color: #ffffff;
}

/* ── Section Block & Headers ── */
.promo-section-block {
  margin-bottom: 40px;
}
.promo-section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
  padding: 16px 22px;
  background: #ffffff;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  flex-wrap: wrap;
  gap: 12px;
}
.promo-section-header.header-video {
  border-left: 4px solid #2563eb;
}
.promo-section-header.header-diskon {
  border-left: 4px solid #e11d48;
}

/* ── Cards Grid & Promo Card ── */
.promo-cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
  gap: 22px;
  margin-bottom: 24px;
}
@media (max-width: 640px) {
  .promo-cards-grid { grid-template-columns: 1fr; }
}

.promo-card {
  position: relative;
  background: #ffffff;
  border-radius: 14px;
  border: 1px solid #e2e8f0;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
  transition: transform 0.25s ease, box-shadow 0.25s ease;
  display: flex;
  flex-direction: column;
}
.promo-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 24px rgba(0, 0, 0, 0.08);
}

.promo-card-preview {
  position: relative;
  height: 185px;
  width: 100%;
  overflow: hidden;
  background: #0f172a;
}
.promo-card-preview img,
.promo-card-preview video {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.promo-card-body {
  padding: 18px;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background: #ffffff;
}

.promo-card-actions {
  padding: 12px 18px;
  background: #f8fafc;
  border-top: 1px solid #e2e8f0;
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
}

/* ── Type & Position Badges ── */
.badge-type-video {
  background: rgba(37, 99, 235, 0.95);
  color: #ffffff;
  font-size: 10.5px;
  font-weight: 800;
  letter-spacing: 0.5px;
  padding: 4px 10px;
  border-radius: 20px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.badge-type-diskon {
  background: rgba(225, 29, 72, 0.95);
  color: #ffffff;
  font-size: 10.5px;
  font-weight: 800;
  letter-spacing: 0.5px;
  padding: 4px 10px;
  border-radius: 20px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

/* ── Form View Styles (Interactive Live Preview) ── */
.banner-layout-grid {
  display: grid;
  grid-template-columns: 1fr 440px;
  gap: 28px;
  align-items: start;
}
@media (max-width: 1100px) {
  .banner-layout-grid { grid-template-columns: 1fr; }
}

.promo-type-selector {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  margin-bottom: 22px;
}
@media (max-width: 640px) {
  .promo-type-selector { grid-template-columns: 1fr; }
}

.promo-type-card {
  position: relative;
  background: #ffffff;
  border: 2px solid #e2e8f0;
  border-radius: 12px;
  padding: 16px 18px;
  cursor: pointer;
  transition: all 0.25s ease;
  display: flex;
  gap: 14px;
  align-items: flex-start;
}
.promo-type-card:hover {
  border-color: #cbd5e1;
  background: #fafafa;
}
.promo-type-card.active.type-video {
  border-color: #2563eb;
  background: #eff6ff;
  box-shadow: 0 4px 14px rgba(37, 99, 235, 0.12);
}
.promo-type-card.active.type-diskon {
  border-color: #e11d48;
  background: #fff1f2;
  box-shadow: 0 4px 14px rgba(225, 29, 72, 0.12);
}
.promo-check-indicator {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: #2563eb;
  color: #fff;
  font-size: 12px;
  font-weight: 800;
  display: none;
  align-items: center;
  justify-content: center;
}
.promo-type-card.active .promo-check-indicator {
  display: flex;
}
.promo-type-card.active.type-diskon .promo-check-indicator {
  background: #e11d48;
}
.promo-type-icon {
  font-size: 28px;
  line-height: 1;
  flex-shrink: 0;
}
.promo-type-title {
  font-size: 14px;
  font-weight: 800;
  color: #1e293b;
  margin-bottom: 4px;
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}
.promo-type-desc {
  font-size: 12px;
  color: #64748b;
  line-height: 1.45;
}

.sticky-preview-box {
  position: sticky;
  top: 90px;
  background: #ffffff;
  border-radius: 14px;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}
.preview-header {
  padding: 14px 18px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.preview-header-title {
  font-size: 13px;
  font-weight: 800;
  color: #1e293b;
  display: flex;
  align-items: center;
  gap: 8px;
}
.preview-screen {
  padding: 20px;
  background: #f1f5f9;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 240px;
}
.preview-banner-mockup {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.25);
  transition: all 0.3s ease;
  background-color: #000;
}
.preview-banner-bg,
.preview-banner-video {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  background-size: cover;
  background-position: center;
}
.preview-banner-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.7) 100%);
  pointer-events: none;
}
.preview-content {
  position: absolute;
  inset: 0;
  padding: 18px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  z-index: 2;
  color: #fff;
  pointer-events: none;
}
.preview-badge-pill {
  display: inline-block;
  background: #e11d48;
  color: #fff;
  font-size: 10px;
  font-weight: 800;
  padding: 3px 8px;
  border-radius: 4px;
  text-transform: uppercase;
  letter-spacing: 0.8px;
  margin-bottom: 6px;
}
.preview-title-text {
  font-size: 18px;
  font-weight: 800;
  line-height: 1.2;
  text-shadow: 0 1px 4px rgba(0,0,0,0.6);
  margin-bottom: 4px;
}
.preview-sub-text {
  font-size: 11px;
  opacity: 0.9;
  line-height: 1.35;
  text-shadow: 0 1px 3px rgba(0,0,0,0.6);
  margin-bottom: 8px;
}
.preview-price-box {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
.preview-price-now {
  font-size: 16px;
  font-weight: 800;
  color: #fb7185;
  text-shadow: 0 1px 3px rgba(0,0,0,0.6);
}
.preview-price-was {
  font-size: 11.5px;
  text-decoration: line-through;
  opacity: 0.7;
}
.preview-btn-mock {
  display: inline-block;
  background: #ffffff;
  color: #0f172a;
  font-size: 11px;
  font-weight: 700;
  padding: 6px 14px;
  border-radius: 6px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.3);
}
.preview-product-chip {
  position: absolute;
  top: 14px;
  right: 14px;
  background: rgba(255, 255, 255, 0.94);
  backdrop-filter: blur(8px);
  padding: 6px 10px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  display: flex;
  align-items: center;
  gap: 8px;
  z-index: 3;
}
.preview-product-chip img {
  width: 32px;
  height: 32px;
  border-radius: 6px;
  object-fit: cover;
}
.color-preset-dot {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  cursor: pointer;
  border: 2px solid #ffffff;
  box-shadow: 0 0 0 1px #d1d5db;
  display: inline-block;
  transition: transform 0.15s ease;
}
.color-preset-dot:hover {
  transform: scale(1.2);
}
</style>

<!-- Alert Feedback -->
<?php if ($success): ?>
  <div style="background:#e6f9ed; border:1px solid #bbf7d0; color:#166534; padding:14px 20px; border-radius:12px; margin-bottom:24px; display:flex; align-items:center; gap:12px; font-weight:500; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
    <span style="font-size:18px;">✅</span>
    <span><?= htmlspecialchars($success) ?></span>
  </div>
<?php endif; ?>

<?php if ($error): ?>
  <div style="background:#fff1f2; border:1px solid #fecdd3; color:#9f1239; padding:14px 20px; border-radius:12px; margin-bottom:24px; display:flex; align-items:center; gap:12px; font-weight:500; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
    <span style="font-size:18px;">⚠️</span>
    <span><?= htmlspecialchars($error) ?></span>
  </div>
<?php endif; ?>

<?php
// ══════════════════════════════════════════════════════════════════════════════
// MODE: FORM TAMBAH / FORM EDIT DENGAN LIVE PREVIEW
// ══════════════════════════════════════════════════════════════════════════════
if ($mode === 'form_add' || $mode === 'form_edit'):
    $d = $edit_data ?? [];
    $is_edit_mode = ($mode === 'form_edit');
    $current_type = $d['tipe'] ?? ($_GET['type'] ?? 'diskon');
    if (!in_array($current_type, ['diskon', 'video'])) $current_type = 'diskon';
?>

<!-- Header Halaman Form -->
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap; gap:14px;">
  <div>
    <div style="font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:1px; color:var(--admin-text-muted); margin-bottom:4px;">
      Promosi Beranda SOREN.ID
    </div>
    <h2 style="font-size:22px; font-weight:800; color:#1e293b; margin:0; display:flex; align-items:center; gap:10px;">
      <?= $is_edit_mode ? '✏️ Edit: ' . htmlspecialchars($d['judul']) : '➕ Tambah Promosi Baru' ?>
    </h2>
  </div>
  <a href="<?= BASE_URL ?>admin/banner.php" class="btn-admin btn-admin-outline" style="border-radius:10px;">
    ← Kembali ke Daftar Promosi
  </a>
</div>

<!-- 2-Kolom Form & Live Real-Time Interactive Preview -->
<div class="banner-layout-grid">

  <!-- KOLOM KIRI: FORM CONTROLS -->
  <div>
    <form method="POST" enctype="multipart/form-data" id="bannerForm">
      <input type="hidden" name="action" value="<?= $is_edit_mode ? 'edit' : 'tambah' ?>">
      <input type="hidden" name="tipe" id="inputTipe" value="<?= htmlspecialchars($current_type) ?>">
      <?php if ($is_edit_mode): ?>
        <input type="hidden" name="banner_id" value="<?= (int)$d['id'] ?>">
      <?php endif; ?>

      <!-- 1. PILIH TIPE PROMOSI -->
      <div style="margin-bottom:8px;">
        <label class="form-label" style="font-size:14px; font-weight:700; color:#1e293b; margin-bottom:8px;">
          Pilih Posisi & Tipe Promosi <span style="color:#ef4444;">*</span>
        </label>
        <div class="promo-type-selector">
          <!-- Opsi 1: Iklan Video (Bagian Atas) -->
          <div class="promo-type-card type-video <?= $current_type === 'video' ? 'active' : '' ?>"
               onclick="switchPromoType('video')" id="cardTypeVideo">
            <div class="promo-check-indicator">✓</div>
            <div class="promo-type-icon">🎬</div>
            <div>
              <div class="promo-type-title">
                Iklan Video (Bagian Atas)
                <span class="badge-type badge-type-video">ATAS • MURNI VIDEO</span>
              </div>
              <div class="promo-type-desc">
                Tampil di <b>paling atas beranda</b> sebagai video sinematik murni bergerak otomatis <b>tanpa teks apapun</b>.
              </div>
            </div>
          </div>

          <!-- Opsi 2: Banner Diskon Produk (Bagian Bawah) -->
          <div class="promo-type-card type-diskon <?= $current_type === 'diskon' ? 'active' : '' ?>"
               onclick="switchPromoType('diskon')" id="cardTypeDiskon">
            <div class="promo-check-indicator">✓</div>
            <div class="promo-type-icon">🏷️</div>
            <div>
              <div class="promo-type-title">
                Banner Diskon Produk (Bagian Bawah)
                <span class="badge-type badge-type-diskon">BAWAH • PROMO</span>
              </div>
              <div class="promo-type-desc">
                Tampil di <b>bawah iklan video</b>: slider promo diskon, harga coret, badge %, teks, dan showcase baju.
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 2A. FORM KHUSUS IKLAN VIDEO (BAGIAN ATAS - TANPA TEKS) -->
      <div id="sectionVideoFields" style="display: <?= $current_type === 'video' ? 'block' : 'none' ?>;">
        <div class="card" style="border-radius:14px; margin-bottom:20px; border-left:4px solid #2563eb;">
          <div class="card-header" style="background:#eff6ff; padding:16px 22px;">
            <h3 class="card-title" style="font-size:15px; color:#1d4ed8; display:flex; align-items:center; gap:8px;">
              <span>🎬</span> Konfigurasi Iklan Video (Murni Video Tanpa Teks)
            </h3>
          </div>
          <div class="card-body" style="padding:22px;">
            <div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#166534; padding:12px 16px; border-radius:8px; font-size:12.5px; margin-bottom:18px; display:flex; gap:10px; align-items:center;">
              <span style="font-size:18px;">💡</span>
              <div>
                <b>Info Penempatan:</b> Iklan video ini akan tampil di bagian <b>paling atas</b> beranda sebagai <b>video murni tanpa teks/judul overlay</b>, dilengkapi tombol kontrol suara.
              </div>
            </div>

            <!-- Nama Referensi Admin -->
            <div style="margin-bottom:18px;">
              <label class="form-label">Nama Iklan Video (Untuk Referensi Admin) <span style="color:#ef4444;">*</span></label>
              <input type="text" name="judul_video" id="inputJudulVideo" class="form-input"
                     value="<?= htmlspecialchars($d['judul'] ?? '') ?>"
                     placeholder="cth: Video Summer Lookbook 2026"
                     oninput="syncJudul(this.value)">
              <small class="form-hint">Hanya digunakan sebagai nama pengenal di daftar admin toko</small>
            </div>

            <!-- Pilihan Sumber Video -->
            <div style="margin-bottom:18px;">
              <label class="form-label">Sumber Video <span style="color:#ef4444;">*</span></label>
              <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <label style="border:1px solid #d1d5db; padding:12px 14px; border-radius:10px; cursor:pointer; display:flex; align-items:center; gap:10px; font-weight:600; font-size:13px;"
                       id="labelSourceUpload">
                  <input type="radio" name="video_tipe" value="upload"
                         <?= ($d['video_tipe'] ?? 'upload') === 'upload' ? 'checked' : '' ?>
                         onchange="toggleVideoSource('upload')">
                  <span>📤 Upload File Video MP4</span>
                </label>
                <label style="border:1px solid #d1d5db; padding:12px 14px; border-radius:10px; cursor:pointer; display:flex; align-items:center; gap:10px; font-weight:600; font-size:13px;"
                       id="labelSourceUrl">
                  <input type="radio" name="video_tipe" value="url"
                         <?= ($d['video_tipe'] ?? '') === 'url' ? 'checked' : '' ?>
                         onchange="toggleVideoSource('url')">
                  <span>🔗 Link URL / YouTube</span>
                </label>
              </div>
            </div>

            <!-- File Upload Video -->
            <div id="boxVideoUpload" style="margin-bottom:18px; display: <?= ($d['video_tipe'] ?? 'upload') === 'upload' ? 'block' : 'none' ?>;">
              <label class="form-label">File Video MP4 / WebM <?= ($is_edit_mode && !empty($d['video_file'])) ? '' : '<span style="color:#ef4444;">*</span>' ?></label>
              <?php if ($is_edit_mode && !empty($d['video_file'])): ?>
                <div style="display:flex; align-items:center; gap:14px; margin-bottom:12px; background:#f8fafc; padding:10px 14px; border-radius:10px; border:1px solid #e2e8f0;">
                  <span style="font-size:24px;">🎥</span>
                  <div style="font-size:12px; color:#64748b;">
                    <b>Video aktif saat ini:</b> <?= htmlspecialchars($d['video_file']) ?><br>
                    <span>Upload video baru jika ingin mengganti</span>
                  </div>
                </div>
              <?php endif; ?>
              <input type="file" name="video_file" id="inputVideoFile" class="form-input"
                     accept="video/mp4,video/webm,video/ogg,video/quicktime"
                     onchange="previewVideoFile(this)">
              <small class="form-hint">Maks 40 MB. Resolusi 16:9 disarankan untuk tampilan hero yang optimal</small>
            </div>

            <!-- Link URL Video -->
            <div id="boxVideoUrl" style="margin-bottom:18px; display: <?= ($d['video_tipe'] ?? '') === 'url' ? 'block' : 'none' ?>;">
              <label class="form-label">Tautan URL Video (YouTube atau Direct MP4) <span style="color:#ef4444;">*</span></label>
              <input type="url" name="video_url" id="inputVideoUrl" class="form-input"
                     value="<?= htmlspecialchars($d['video_url'] ?? '') ?>"
                     placeholder="cth: https://www.youtube.com/watch?v=... atau https://domain/video.mp4"
                     oninput="previewVideoUrl(this.value)">
              <small class="form-hint">Bisa berupa link YouTube biasa, Shorts, atau URL file .mp4 hosting</small>
            </div>

            <!-- Tautan Klik (Opsional) -->
            <div style="margin-bottom:18px;">
              <label class="form-label">Tautan Klik Video (Opsional)</label>
              <input type="text" name="link_url_video" id="inputLinkVideo" class="form-input"
                     value="<?= htmlspecialchars($d['link_url'] ?? '') ?>"
                     placeholder="cth: katalog.php atau promo-spesial.php"
                     oninput="syncLink(this.value)">
              <small class="form-hint">Jika diisi, pengunjung yang mengklik video akan diarahkan ke halaman ini</small>
            </div>

            <!-- Thumbnail Poster (Opsional) -->
            <div style="margin-bottom:18px;">
              <label class="form-label">Poster Thumbnail (Opsional)</label>
              <input type="file" name="gambar_poster" class="form-input" accept="image/jpeg,image/png,image/webp">
              <small class="form-hint">Gambar penutup awal yang tampil sebelum video dimuat</small>
            </div>

            <!-- Opsi Loop & Muted -->
            <div style="background:#f8fafc; padding:16px; border-radius:10px; border:1px solid #e2e8f0; display:grid; grid-template-columns:1fr 1fr; gap:14px;">
              <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-weight:600; font-size:13px;">
                <input type="checkbox" name="video_loop" value="1" <?= ($d['video_loop'] ?? 1) ? 'checked' : '' ?>
                       style="width:18px; height:18px;">
                <span>🔁 Ulangi Video Terus (Loop)</span>
              </label>
              <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-weight:600; font-size:13px;">
                <input type="checkbox" name="video_muted" value="1" <?= ($d['video_muted'] ?? 1) ? 'checked' : '' ?>
                       style="width:18px; height:18px;">
                <span>🔇 Mulai Hening (Muted) + Tombol Suara</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      <!-- 2B. FORM KHUSUS BANNER DISKON PRODUK (BAGIAN BAWAH) -->
      <div id="sectionDiskonFields" style="display: <?= $current_type === 'diskon' ? 'block' : 'none' ?>;">
        <!-- Card: Konten Teks & Diskon -->
        <div class="card" style="border-radius:14px; margin-bottom:20px; border-left:4px solid #e11d48;">
          <div class="card-header" style="background:#fff1f2; padding:16px 22px;">
            <h3 class="card-title" style="font-size:15px; color:#be123c; display:flex; align-items:center; gap:8px;">
              <span>🏷️</span> Konten Teks & Penawaran Diskon
            </h3>
          </div>
          <div class="card-body" style="padding:22px;">
            <div style="background:#fffbeb; border:1px solid #fef3c7; color:#92400e; padding:12px 16px; border-radius:8px; font-size:12.5px; margin-bottom:18px; display:flex; gap:10px; align-items:center;">
              <span style="font-size:18px;">💡</span>
              <div>
                <b>Info Penempatan:</b> Banner ini akan tampil di <b>bawah iklan video</b> sebagai slider penawaran produk diskon dengan harga coret dan tombol belanja.
              </div>
            </div>

            <!-- Judul & Subjudul -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:18px;">
              <div>
                <label class="form-label">Judul Banner Diskon <span style="color:#ef4444;">*</span></label>
                <input type="text" name="judul_diskon" id="inputJudulDiskon" class="form-input"
                       value="<?= htmlspecialchars($d['judul'] ?? '') ?>"
                       placeholder="cth: Flash Sale Akhir Bulan"
                       oninput="syncJudul(this.value)">
                <small class="form-hint">Headline promosi yang tampil besar di slider</small>
              </div>
              <div>
                <label class="form-label">Subjudul / Deskripsi Singkat</label>
                <input type="text" name="subjudul" id="inputSubjudul" class="form-input"
                       value="<?= htmlspecialchars($d['subjudul'] ?? '') ?>"
                       placeholder="cth: Koleksi Korea Style diskon s.d 50%"
                       oninput="updateLivePreview()">
                <small class="form-hint">Teks penjelasan singkat di bawah judul</small>
              </div>
            </div>

            <!-- Label Badge Diskon -->
            <div style="margin-bottom:18px;">
              <label class="form-label">Badge Label Diskon</label>
              <input type="text" name="label_diskon" id="inputBadge" class="form-input"
                     value="<?= htmlspecialchars($d['label_diskon'] ?? '') ?>"
                     placeholder="cth: DISKON 30%  /  FLASH SALE"
                     oninput="updateLivePreview()">
              <div style="display:flex; align-items:center; gap:8px; margin-top:8px; flex-wrap:wrap;">
                <span style="font-size:11.5px; color:#888;">Contoh cepat:</span>
                <button type="button" class="btn-admin btn-admin-sm btn-admin-outline"
                        onclick="setBadgeValue('DISKON 50%')">🔥 DISKON 50%</button>
                <button type="button" class="btn-admin btn-admin-sm btn-admin-outline"
                        onclick="setBadgeValue('FLASH SALE')">⚡ FLASH SALE</button>
                <button type="button" class="btn-admin btn-admin-sm btn-admin-outline"
                        onclick="setBadgeValue('HEMAT 30%')">💥 HEMAT 30%</button>
                <button type="button" class="btn-admin btn-admin-sm btn-admin-outline"
                        onclick="setBadgeValue('BUY 1 GET 1')">🎁 BUY 1 GET 1</button>
              </div>
            </div>

            <!-- Harga Asli & Diskon -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:18px;">
              <div>
                <label class="form-label">Harga Asli (Rp)</label>
                <input type="number" name="harga_asli" id="inputHargaAsli" class="form-input"
                       value="<?= htmlspecialchars($d['harga_asli'] ?? '') ?>"
                       placeholder="cth: 250000" min="0" oninput="updateLivePreview()">
                <small class="form-hint">Akan dicoret otomatis di sebelah harga promo</small>
              </div>
              <div>
                <label class="form-label">Harga Promo / Diskon (Rp)</label>
                <input type="number" name="harga_diskon" id="inputHargaDiskon" class="form-input"
                       value="<?= htmlspecialchars($d['harga_diskon'] ?? '') ?>"
                       placeholder="cth: 175000" min="0" oninput="updateLivePreview()">
                <small class="form-hint">Harga spesial yang berlaku saat ini</small>
              </div>
            </div>

            <!-- Teks Tombol & Link -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:18px;">
              <div>
                <label class="form-label">Teks Tombol Aksi (CTA)</label>
                <input type="text" name="teks_tombol" id="inputTombol" class="form-input"
                       value="<?= htmlspecialchars($d['teks_tombol'] ?? 'Belanja Sekarang') ?>"
                       placeholder="cth: Belanja Sekarang" oninput="updateLivePreview()">
              </div>
              <div>
                <label class="form-label">Link Tujuan Tombol</label>
                <input type="text" name="link_url_diskon" id="inputLinkDiskon" class="form-input"
                       value="<?= htmlspecialchars($d['link_url'] ?? '') ?>"
                       placeholder="cth: katalog.php atau katalog.php?kategori=1"
                       oninput="syncLink(this.value)">
              </div>
            </div>

            <!-- Hubungkan Produk Toko -->
            <div style="margin-bottom:18px;">
              <label class="form-label">Showcase Foto Produk Toko (Opsional)</label>
              <select name="id_produk" class="form-input" id="selectProduk" onchange="onProdukChange(this)">
                <option value="" data-gambar="" data-harga="" data-nama="">— Tidak tampilkan kartu produk terkait —</option>
                <?php foreach ($all_products as $pr): ?>
                  <option value="<?= $pr['id'] ?>"
                          data-gambar="<?= htmlspecialchars($pr['gambar']) ?>"
                          data-harga="<?= (float)$pr['harga'] ?>"
                          data-harga-fmt="<?= format_rupiah($pr['harga']) ?>"
                          data-nama="<?= htmlspecialchars($pr['nama_produk']) ?>"
                          <?= ($d['id_produk'] ?? '') == $pr['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($pr['nama_produk']) ?> — <?= format_rupiah($pr['harga']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <small class="form-hint">Jika dipilih, foto produk akan tampil melayang di sisi kanan banner diskon</small>
            </div>

            <!-- Upload Gambar Banner Latar -->
            <div style="margin-bottom:18px;">
              <label class="form-label">Gambar Latar Banner <?= ($is_edit_mode && !empty($d['gambar'])) ? '' : '<span style="color:#ef4444;">*</span>' ?></label>
              <?php if ($is_edit_mode && !empty($d['gambar']) && $d['tipe'] === 'diskon'): ?>
                <div style="display:flex; align-items:center; gap:14px; margin-bottom:12px; background:#f8fafc; padding:10px 14px; border-radius:10px; border:1px solid #e2e8f0;">
                  <img src="<?= BASE_URL ?>uploads/banners/<?= htmlspecialchars($d['gambar']) ?>"
                       style="width:90px; height:50px; object-fit:cover; border-radius:6px; border:1px solid #cbd5e1;">
                  <div style="font-size:12px; color:#64748b;">
                    <b>Gambar saat ini:</b> <?= htmlspecialchars($d['gambar']) ?><br>
                    <span>Upload foto baru di bawah jika ingin mengganti</span>
                  </div>
                </div>
              <?php endif; ?>
              <input type="file" name="gambar" id="inputGambarBanner" class="form-input"
                     accept="image/jpeg,image/png,image/webp,image/gif"
                     onchange="previewImageFile(this)">
              <small class="form-hint">Format didukung: JPG, PNG, WEBP. Maks 5 MB. Rekomendasi: 1200 × 500 px</small>
            </div>

            <!-- Warna Background -->
            <div>
              <label class="form-label">Warna Latar Belakang Banner</label>
              <div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">
                <input type="color" name="warna_bg" id="warnaBg"
                       value="<?= htmlspecialchars($d['warna_bg'] ?? '#1a1218') ?>"
                       style="width:50px; height:40px; border:1px solid #d1d5db; border-radius:8px; cursor:pointer; padding:2px;"
                       oninput="syncColor(this.value)">
                <input type="text" id="warnaBgText" class="form-input" style="max-width:140px;"
                       value="<?= htmlspecialchars($d['warna_bg'] ?? '#1a1218') ?>"
                       oninput="syncColor(this.value)">
              </div>
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-size:11.5px; color:#888;">Preset warna gelap:</span>
                <span class="color-preset-dot" style="background:#1a1218;" onclick="syncColor('#1a1218')" title="Dark Charcoal"></span>
                <span class="color-preset-dot" style="background:#2a111a;" onclick="syncColor('#2a111a')" title="Velvet Wine"></span>
                <span class="color-preset-dot" style="background:#0f172a;" onclick="syncColor('#0f172a')" title="Slate Navy"></span>
                <span class="color-preset-dot" style="background:#1e1b4b;" onclick="syncColor('#1e1b4b')" title="Deep Indigo"></span>
                <span class="color-preset-dot" style="background:#064e3b;" onclick="syncColor('#064e3b')" title="Forest Emerald"></span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Hidden Master Inputs -->
      <input type="hidden" name="judul" id="masterJudul" value="<?= htmlspecialchars($d['judul'] ?? '') ?>">
      <input type="hidden" name="link_url" id="masterLink" value="<?= htmlspecialchars($d['link_url'] ?? '') ?>">

      <!-- 3. URUTAN & STATUS PUBLIKASI -->
      <div class="card" style="border-radius:14px; margin-bottom:28px;">
        <div class="card-body" style="padding:22px; display:grid; grid-template-columns:1fr 1fr; gap:20px; align-items:center;">
          <div>
            <label class="form-label">Urutan Tampil</label>
            <input type="number" name="urutan" id="inputUrutan" class="form-input"
                   value="<?= (int)($d['urutan'] ?? 0) ?>" min="0" max="99" style="max-width:140px;">
            <small class="form-hint">Angka 0 = prioritas tampil paling awal</small>
          </div>
          <div style="display:flex; align-items:center; gap:12px; padding-top:6px;">
            <input type="checkbox" name="aktif" id="chkAktif" value="1"
                   <?= ($d['aktif'] ?? 1) ? 'checked' : '' ?>
                   style="width:20px; height:20px; cursor:pointer;"
                   onchange="updateLivePreview()">
            <div>
              <label for="chkAktif" style="font-weight:700; cursor:pointer; font-size:14px; color:#1e293b;">
                Publikasikan di Toko Online
              </label>
              <small class="form-hint" style="margin-top:2px;">Jika tidak dicentang, promosi disimpan sebagai draft</small>
            </div>
          </div>
        </div>
      </div>

      <!-- TOMBOL SUBMIT & BATAL -->
      <div style="display:flex; gap:14px; align-items:center;">
        <button type="submit" class="btn-admin btn-admin-primary" style="padding:12px 28px; font-size:14px; border-radius:10px;">
          <?= $is_edit_mode ? '💾 Simpan Perubahan' : '🚀 Terbitkan Promosi Sekarang' ?>
        </button>
        <a href="<?= BASE_URL ?>admin/banner.php" class="btn-admin btn-admin-outline" style="padding:12px 22px; font-size:14px; border-radius:10px;">
          Batal
        </a>
      </div>
    </form>
  </div>

  <!-- KOLOM KANAN: STICKY REAL-TIME LIVE PREVIEW -->
  <div>
    <div class="sticky-preview-box">
      <div class="preview-header">
        <div class="preview-header-title">
          <span id="previewHeaderIcon">🎬</span>
          <span id="previewHeaderLabel"><?= $current_type === 'video' ? 'Preview: Iklan Video (Atas - Murni Video)' : 'Preview: Banner Diskon (Bawah)' ?></span>
        </div>
        <div style="display:flex; gap:6px;">
          <button type="button" class="btn-admin btn-admin-sm btn-admin-outline" id="btnPreviewDesktop"
                  onclick="setPreviewDevice('desktop')" style="border-radius:6px; background:#fff; font-weight:700;">💻 Desktop</button>
          <button type="button" class="btn-admin btn-admin-sm btn-admin-outline" id="btnPreviewMobile"
                  onclick="setPreviewDevice('mobile')" style="border-radius:6px;">📱 Mobile</button>
        </div>
      </div>

      <div class="preview-screen" id="previewContainer">
        <!-- Mockup Box -->
        <div class="preview-banner-mockup" id="previewMockup"
             style="background-color:<?= htmlspecialchars($d['warna_bg'] ?? ($current_type === 'video' ? '#000000' : '#1a1218')) ?>;">
          
          <!-- Background Image (Hanya Diskon) -->
          <div class="preview-banner-bg" id="previewBgImg"
               style="background-image:url('<?= (!empty($d['gambar']) && $current_type === 'diskon') ? BASE_URL . 'uploads/banners/' . htmlspecialchars($d['gambar']) : BASE_URL . 'uploads/banners/default-banner.jpg' ?>'); display:<?= $current_type === 'diskon' ? 'block' : 'none' ?>;">
          </div>

          <!-- Video Player (Hanya Video) -->
          <video class="preview-banner-video" id="previewVideoEl" autoplay muted loop playsinline
                 style="display:<?= ($current_type === 'video' && !empty($d['video_file'])) ? 'block' : 'none' ?>;">
            <?php if (!empty($d['video_file'])): ?>
              <source src="<?= BASE_URL ?>uploads/banners/videos/<?= htmlspecialchars($d['video_file']) ?>" type="video/mp4">
            <?php endif; ?>
          </video>
          <iframe id="previewYtIframe" class="preview-banner-video" style="display:none; border:none;" allow="autoplay"></iframe>

          <!-- Overlay Sinematik (Hanya Diskon) -->
          <div class="preview-banner-overlay" id="previewOverlay" style="display:<?= $current_type === 'diskon' ? 'block' : 'none' ?>;"></div>

          <!-- KONTEN TEKS: HANYA TAMPIL UNTUK DISKON PRODUK -->
          <div class="preview-content" id="previewTextContent" style="display:<?= $current_type === 'diskon' ? 'flex' : 'none' ?>;">
            <div>
              <!-- Badge Diskon -->
              <div class="preview-badge-pill" id="previewBadge">
                <?= htmlspecialchars(!empty($d['label_diskon']) ? $d['label_diskon'] : '🔥 PROMO SPESIAL') ?>
              </div>

              <!-- Judul -->
              <div class="preview-title-text" id="previewJudul">
                <?= htmlspecialchars(!empty($d['judul']) ? $d['judul'] : 'Flash Sale Akhir Bulan') ?>
              </div>

              <!-- Subjudul -->
              <div class="preview-sub-text" id="previewSubjudul">
                <?= htmlspecialchars(!empty($d['subjudul']) ? $d['subjudul'] : 'Koleksi pilihan dengan potongan harga hingga 50%.') ?>
              </div>

              <!-- Harga Promo -->
              <div class="preview-price-box" id="previewPriceBox">
                <span class="preview-price-now" id="previewPriceNow">
                  <?= !empty($d['harga_diskon']) ? format_rupiah($d['harga_diskon']) : 'Rp 175.000' ?>
                </span>
                <span class="preview-price-was" id="previewPriceWas">
                  <?= !empty($d['harga_asli']) ? format_rupiah($d['harga_asli']) : 'Rp 250.000' ?>
                </span>
              </div>
            </div>

            <!-- Tombol CTA -->
            <div>
              <div class="preview-btn-mock" id="previewBtn">
                <span id="previewBtnText"><?= htmlspecialchars(!empty($d['teks_tombol']) ? $d['teks_tombol'] : 'Belanja Sekarang') ?></span> →
              </div>
            </div>
          </div>

          <!-- Foto Produk Melayang (Hanya Diskon) -->
          <div class="preview-product-chip" id="previewProductChip"
               style="display:<?= (!empty($d['id_produk']) && $current_type === 'diskon') ? 'flex' : 'none' ?>;">
            <img src="" id="previewProductImg" alt="Produk">
            <div>
              <div style="font-size:10px; font-weight:700; line-height:1.2;" id="previewProductName">Produk</div>
              <div style="font-size:10px; color:#e11d48; font-weight:800;" id="previewProductPrice">Rp 0</div>
            </div>
          </div>

          <!-- Kontrol Suara Murni Video (Hanya Video) -->
          <div id="previewVideoCtrlBox" style="position:absolute; bottom:14px; right:14px; display:<?= $current_type === 'video' ? 'flex' : 'none' ?>; z-index:5;">
            <span style="background:rgba(0,0,0,0.65); color:#fff; font-size:12px; width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:1px solid rgba(255,255,255,0.4);">
              🔇
            </span>
          </div>

        </div>
      </div>

      <!-- Info Footer Preview -->
      <div style="padding:14px 20px; background:#fcfcfd; border-top:1px solid var(--admin-border); font-size:12px; color:#64748b; display:flex; justify-content:space-between; align-items:center;">
        <div>
          Posisi: <b id="previewTypeBadge" style="color:#1e293b;"><?= $current_type === 'video' ? '🎬 Bagian Atas (Murni Video)' : '🏷️ Bagian Bawah (Banner Diskon)' ?></b>
        </div>
        <div id="previewStatusBadge" style="color:#16a34a; font-weight:700;">
          ● Aktif di Beranda
        </div>
      </div>
    </div>
  </div>

</div>

<!-- JAVASCRIPT LOGIC FORM & PREVIEW -->
<script>
let currentPromoType = '<?= $current_type ?>';

function syncJudul(val) {
  document.getElementById('masterJudul').value = val;
  updateLivePreview();
}

function syncLink(val) {
  document.getElementById('masterLink').value = val;
}

function switchPromoType(type) {
  currentPromoType = type;
  document.getElementById('inputTipe').value = type;

  // Toggle card state
  document.getElementById('cardTypeVideo').classList.toggle('active', type === 'video');
  document.getElementById('cardTypeDiskon').classList.toggle('active', type === 'diskon');

  // Toggle form sections
  document.getElementById('sectionVideoFields').style.display  = (type === 'video') ? 'block' : 'none';
  document.getElementById('sectionDiskonFields').style.display = (type === 'diskon') ? 'block' : 'none';

  // Toggle preview mockup presentation
  const isVid = (type === 'video');
  document.getElementById('previewTextContent').style.display   = isVid ? 'none' : 'flex';
  document.getElementById('previewBgImg').style.display         = isVid ? 'none' : 'block';
  document.getElementById('previewOverlay').style.display       = isVid ? 'none' : 'block';
  document.getElementById('previewProductChip').style.display   = isVid ? 'none' : (document.getElementById('selectProduk').value ? 'flex' : 'none');
  document.getElementById('previewVideoCtrlBox').style.display  = isVid ? 'flex' : 'none';

  // Header and badge labels
  document.getElementById('previewHeaderIcon').textContent  = isVid ? '🎬' : '🏷️';
  document.getElementById('previewHeaderLabel').textContent = isVid ? 'Preview: Iklan Video (Atas - Murni Video)' : 'Preview: Banner Diskon (Bawah)';
  document.getElementById('previewTypeBadge').textContent   = isVid ? '🎬 Bagian Atas (Murni Video)' : '🏷️ Bagian Bawah (Banner Diskon)';

  // Sync title from corresponding input
  if (isVid) {
    document.getElementById('masterJudul').value = document.getElementById('inputJudulVideo').value;
    document.getElementById('masterLink').value  = document.getElementById('inputLinkVideo').value;
    document.getElementById('previewMockup').style.backgroundColor = '#000000';
  } else {
    document.getElementById('masterJudul').value = document.getElementById('inputJudulDiskon').value;
    document.getElementById('masterLink').value  = document.getElementById('inputLinkDiskon').value;
    document.getElementById('previewMockup').style.backgroundColor = document.getElementById('warnaBg').value || '#1a1218';
  }

  updateLivePreview();
}

function setBadgeValue(val) {
  document.getElementById('inputBadge').value = val;
  updateLivePreview();
}

function syncColor(val) {
  document.getElementById('warnaBg').value = val;
  document.getElementById('warnaBgText').value = val;
  if (currentPromoType === 'diskon') {
    document.getElementById('previewMockup').style.backgroundColor = val;
  }
}

function toggleVideoSource(src) {
  document.getElementById('boxVideoUpload').style.display = (src === 'upload') ? 'block' : 'none';
  document.getElementById('boxVideoUrl').style.display    = (src === 'url') ? 'block' : 'none';
}

function setPreviewDevice(dev) {
  const mock = document.getElementById('previewMockup');
  const btnD = document.getElementById('btnPreviewDesktop');
  const btnM = document.getElementById('btnPreviewMobile');

  if (dev === 'mobile') {
    mock.style.maxWidth = '300px';
    btnM.style.background = '#fff';
    btnM.style.fontWeight = '700';
    btnD.style.background = 'transparent';
    btnD.style.fontWeight = 'normal';
  } else {
    mock.style.maxWidth = '100%';
    btnD.style.background = '#fff';
    btnD.style.fontWeight = '700';
    btnM.style.background = 'transparent';
    btnM.style.fontWeight = 'normal';
  }
}

function formatRupiahJs(num) {
  return 'Rp ' + Number(num).toLocaleString('id-ID');
}

function onProdukChange(sel) {
  const opt = sel.options[sel.selectedIndex];
  const chip = document.getElementById('previewProductChip');
  const img  = document.getElementById('previewProductImg');
  const name = document.getElementById('previewProductName');
  const prc  = document.getElementById('previewProductPrice');

  if (currentPromoType === 'diskon' && opt.value && opt.dataset.gambar) {
    img.src = '<?= BASE_URL ?>uploads/products/' + opt.dataset.gambar;
    name.textContent = opt.dataset.nama || opt.text;
    prc.textContent  = opt.dataset.hargaFmt || '';
    chip.style.display = 'flex';
  } else {
    chip.style.display = 'none';
  }
}

function previewImageFile(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      document.getElementById('previewBgImg').style.backgroundImage = 'url(' + e.target.result + ')';
    };
    reader.readAsDataURL(input.files[0]);
  }
}

function previewVideoFile(input) {
  if (input.files && input.files[0]) {
    const fileUrl = URL.createObjectURL(input.files[0]);
    const vid = document.getElementById('previewVideoEl');
    const ifr = document.getElementById('previewYtIframe');
    ifr.style.display = 'none';
    vid.src = fileUrl;
    vid.style.display = 'block';
    vid.play().catch(()=>{});
  }
}

function previewVideoUrl(url) {
  const vid = document.getElementById('previewVideoEl');
  const ifr = document.getElementById('previewYtIframe');

  if (!url) {
    vid.style.display = 'none';
    ifr.style.display = 'none';
    return;
  }

  const regYt = /(?:youtube(?:-nocookie)?\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/ ]{11})/i;
  const match = url.match(regYt);

  if (match && match[1]) {
    vid.style.display = 'none';
    ifr.src = 'https://www.youtube-nocookie.com/embed/' + match[1] + '?autoplay=1&mute=1&loop=1&playlist=' + match[1] + '&controls=0';
    ifr.style.display = 'block';
  } else if (url.match(/\.(mp4|webm|ogg)$/i)) {
    ifr.style.display = 'none';
    vid.src = url;
    vid.style.display = 'block';
    vid.play().catch(()=>{});
  }
}

function updateLivePreview() {
  if (currentPromoType === 'diskon') {
    const j = document.getElementById('inputJudulDiskon').value;
    const s = document.getElementById('inputSubjudul').value;
    const b = document.getElementById('inputBadge').value;
    const t = document.getElementById('inputTombol').value;
    const ha = document.getElementById('inputHargaAsli').value;
    const hd = document.getElementById('inputHargaDiskon').value;

    document.getElementById('previewJudul').textContent    = j || 'Judul Banner Diskon';
    document.getElementById('previewSubjudul').textContent = s || 'Deskripsi singkat promosi diskon produk.';
    document.getElementById('previewBadge').textContent    = b || '🔥 PROMO SPESIAL';
    document.getElementById('previewBtnText').textContent  = t || 'Belanja Sekarang';

    if (hd) {
      document.getElementById('previewPriceNow').textContent = formatRupiahJs(hd);
    }
    if (ha) {
      document.getElementById('previewPriceWas').textContent = formatRupiahJs(ha);
      document.getElementById('previewPriceWas').style.display = 'inline';
    } else {
      document.getElementById('previewPriceWas').style.display = 'none';
    }
  }

  const isAktif = document.getElementById('chkAktif').checked;
  const stat = document.getElementById('previewStatusBadge');
  if (isAktif) {
    stat.textContent = '● Aktif di Beranda';
    stat.style.color = '#16a34a';
  } else {
    stat.textContent = '○ Nonaktif (Draft)';
    stat.style.color = '#e11d48';
  }
}

window.addEventListener('DOMContentLoaded', () => {
  const selPr = document.getElementById('selectProduk');
  if (selPr && selPr.value) onProdukChange(selPr);
});
</script>

<?php
// ══════════════════════════════════════════════════════════════════════════════
// MODE: DAFTAR PROMOSI (TERPISAH ANTARA IKLAN VIDEO & BANNER DISKON)
// ══════════════════════════════════════════════════════════════════════════════
else:
    $count_all    = count($banners);
    $count_video  = count($list_video);
    $count_diskon = count($list_diskon);
    $count_aktif  = count(array_filter($banners, fn($b) => !empty($b['aktif'])));
?>

<!-- Header & Quick Actions -->
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap; gap:16px;">
  <div>
    <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1.2px; color:var(--admin-text-muted); margin-bottom:4px;">
      Etalase Promosi Toko
    </div>
    <h2 style="font-size:24px; font-weight:800; color:#0f172a; margin:0; display:flex; align-items:center; gap:10px;">
      Kelola Iklan Video & Banner Diskon
    </h2>
    <p style="font-size:13.5px; color:#64748b; margin:4px 0 0 0;">
      Kelola <b>Iklan Video (Bagian Atas Beranda)</b> dan <b>Banner Diskon Produk (Bagian Bawah)</b> secara terpisah.
    </p>
  </div>

  <div class="promo-top-actions">
    <a href="<?= BASE_URL ?>admin/banner.php?tambah&type=video" class="btn-top-video">
      🎬 + Tambah Iklan Video (Atas)
    </a>
    <a href="<?= BASE_URL ?>admin/banner.php?tambah&type=diskon" class="btn-top-diskon">
      🏷️ + Tambah Banner Diskon (Bawah)
    </a>
  </div>
</div>

<!-- Stats Counter Grid -->
<div class="promo-stats-grid">
  <div class="promo-stat-card">
    <div>
      <div class="stat-val"><?= $count_all ?></div>
      <div class="stat-lbl">Total Promosi</div>
    </div>
    <div class="promo-stat-icon-box" style="background:#f1f5f9; color:#475569;">📊</div>
  </div>

  <div class="promo-stat-card" style="border-left:4px solid #2563eb;">
    <div>
      <div class="stat-val" style="color:#2563eb;"><?= $count_video ?></div>
      <div class="stat-lbl">🎬 Iklan Video (Atas)</div>
    </div>
    <div class="promo-stat-icon-box" style="background:#eff6ff; color:#2563eb;">🎥</div>
  </div>

  <div class="promo-stat-card" style="border-left:4px solid #e11d48;">
    <div>
      <div class="stat-val" style="color:#e11d48;"><?= $count_diskon ?></div>
      <div class="stat-lbl">🏷️ Banner Diskon (Bawah)</div>
    </div>
    <div class="promo-stat-icon-box" style="background:#fff1f2; color:#e11d48;">🛍️</div>
  </div>

  <div class="promo-stat-card">
    <div>
      <div class="stat-val" style="color:#16a34a;"><?= $count_aktif ?></div>
      <div class="stat-lbl">Tayang Aktif di Beranda</div>
    </div>
    <div class="promo-stat-icon-box" style="background:#f0fdf4; color:#16a34a;">●</div>
  </div>
</div>

<!-- Filter Tabs Segmented Control -->
<div class="filter-pill-nav">
  <button type="button" class="filter-pill active" data-filter="all" onclick="filterBanners('all', this)">
    <span>Semua Promosi</span>
    <span class="count-badge"><?= $count_all ?></span>
  </button>
  <button type="button" class="filter-pill" data-filter="video" onclick="filterBanners('video', this)">
    <span>🎬 Iklan Video (Atas)</span>
    <span class="count-badge"><?= $count_video ?></span>
  </button>
  <button type="button" class="filter-pill" data-filter="diskon" onclick="filterBanners('diskon', this)">
    <span>🏷️ Banner Diskon (Bawah)</span>
    <span class="count-badge"><?= $count_diskon ?></span>
  </button>
  <button type="button" class="filter-pill" data-filter="active" onclick="filterBanners('active', this)">
    <span>● Tayang Aktif</span>
    <span class="count-badge"><?= $count_aktif ?></span>
  </button>
</div>

<!-- SECTION 1: IKLAN VIDEO (BAGIAN ATAS BERANDA) -->
<div class="promo-section-block" id="blockSectionVideo">
  <div class="promo-section-header header-video">
    <div>
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:4px; flex-wrap:wrap;">
        <h3 style="font-size:16px; font-weight:800; color:#1e293b; margin:0; display:flex; align-items:center; gap:8px;">
          <span>🎬</span> Iklan Video
        </h3>
        <span style="background:#eff6ff; color:#1d4ed8; font-size:11px; font-weight:800; padding:2px 8px; border-radius:6px; border:1px solid #bfdbfe;">
          BAGIAN ATAS BERANDA • HERO MURNI VIDEO
        </span>
      </div>
      <p style="font-size:12.5px; color:#64748b; margin:0;">
        Video bergerak otomatis sinematik murni tanpa teks/judul overlay yang menyambut pengunjung toko dengan tombol kontrol suara.
      </p>
    </div>
    <a href="<?= BASE_URL ?>admin/banner.php?tambah&type=video" class="btn-top-video" style="padding:8px 16px; font-size:12.5px;">
      + Tambah Video
    </a>
  </div>

  <?php if (empty($list_video)): ?>
    <div style="background:#ffffff; border:1.5px dashed #cbd5e1; border-radius:14px; padding:36px 20px; text-align:center; color:#64748b;">
      <div style="font-size:36px; margin-bottom:8px;">🎬</div>
      <div style="font-weight:800; color:#1e293b; font-size:15px;">Belum ada iklan video yang ditambahkan</div>
      <p style="font-size:12.5px; margin:4px auto 16px auto; max-width:480px;">
        Tambahkan video lookbook atau promosi MP4/YouTube untuk tampil di bagian paling atas beranda toko (tanpa teks).
      </p>
      <a href="<?= BASE_URL ?>admin/banner.php?tambah&type=video" class="btn-top-video" style="padding:8px 18px; font-size:13px;">
        Tambah Iklan Video Pertama
      </a>
    </div>
  <?php else: ?>
    <div class="promo-cards-grid">
      <?php foreach ($list_video as $b):
        $yt_thumb = '';
        if (!empty($b['video_url'])) {
          if (preg_match('/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/', $b['video_url'], $ym)) {
            $yt_thumb = 'https://img.youtube.com/vi/' . $ym[1] . '/mqdefault.jpg';
          }
        }
      ?>
        <div class="promo-card" data-type="video" data-active="<?= $b['aktif'] ? '1' : '0' ?>" style="border-top:3px solid #2563eb;">
          <!-- Video Preview Box (Grounded Relative Container) -->
          <div class="promo-card-preview" style="position:relative; height:185px; width:100%; overflow:hidden; background:#0b0f19;">
            <?php if (!empty($b['video_file'])): ?>
              <video style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover; opacity:0.9;"
                     muted loop playsinline
                     onmouseenter="this.play()" onmouseleave="this.pause()">
                <source src="<?= BASE_URL ?>uploads/banners/videos/<?= htmlspecialchars($b['video_file']) ?>" type="video/mp4">
              </video>
              <div style="position:absolute; bottom:10px; right:12px; background:rgba(0,0,0,0.65); color:#fff; font-size:10.5px; padding:3px 8px; border-radius:6px; z-index:2; pointer-events:none;">
                ▶ Arahkan mouse untuk putar
              </div>
            <?php elseif (!empty($yt_thumb)): ?>
              <img src="<?= $yt_thumb ?>" style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover;" alt="YouTube Thumbnail">
              <div style="position:absolute; inset:0; background:rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center;">
                <span style="background:rgba(220,38,38,0.95); color:#fff; width:44px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:16px; box-shadow:0 4px 12px rgba(0,0,0,0.4);">
                  ▶
                </span>
              </div>
            <?php else: ?>
              <div style="position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#fff; background:linear-gradient(135deg,#1e1b4b,#0f172a);">
                <span style="font-size:34px; margin-bottom:6px;">🎥</span>
                <span style="font-size:11px; opacity:0.85; padding:0 16px; text-align:center; word-break:break-all;">
                  <?= htmlspecialchars(mb_strimwidth($b['video_url'] ?? 'Video Stream', 0, 36, '…')) ?>
                </span>
              </div>
            <?php endif; ?>

            <!-- Badges Top -->
            <div style="position:absolute; top:12px; left:12px; right:12px; display:flex; justify-content:space-between; align-items:center; z-index:2;">
              <span class="badge-type-video" style="box-shadow:0 2px 6px rgba(0,0,0,0.3);">
                🎬 ATAS • MURNI VIDEO
              </span>
              <span style="background:<?= $b['aktif'] ? '#16a34a' : '#dc2626' ?>; color:#fff; font-size:10px; font-weight:800; padding:3px 10px; border-radius:20px; box-shadow:0 2px 6px rgba(0,0,0,0.3);">
                <?= $b['aktif'] ? '● AKTIF' : '○ NONAKTIF' ?>
              </span>
            </div>
          </div>

          <!-- Video Body Details -->
          <div class="promo-card-body">
            <div>
              <div style="font-size:15px; font-weight:800; color:#1e293b; margin-bottom:8px; line-height:1.3;">
                <?= htmlspecialchars($b['judul']) ?>
              </div>
              <div style="background:#eff6ff; padding:8px 12px; border-radius:8px; margin-bottom:10px; font-size:11.5px; color:#1e40af; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                <span><?= ($b['video_tipe'] ?? '') === 'url' ? '🔗 Tautan YouTube / URL' : '📁 File MP4 Lokal' ?></span>
                <?php if (!empty($b['video_loop'])): ?><span>• 🔁 Loop</span><?php endif; ?>
                <?php if (!empty($b['video_muted'])): ?><span>• 🔊 Kontrol Suara</span><?php endif; ?>
              </div>
              <?php if (!empty($b['link_url'])): ?>
                <div style="font-size:11.5px; color:#64748b; margin-bottom:8px;">
                  🔗 Klik Video: <a href="<?= htmlspecialchars($b['link_url']) ?>" target="_blank" style="color:#2563eb; font-weight:600; text-decoration:underline;"><?= htmlspecialchars(mb_strimwidth($b['link_url'], 0, 32, '…')) ?></a>
                </div>
              <?php endif; ?>
              <div style="font-size:11.5px; color:#94a3b8;">
                Urutan: <b>#<?= $b['urutan'] ?></b>
              </div>
            </div>
          </div>

          <!-- Actions -->
          <div class="promo-card-actions">
            <a href="<?= BASE_URL ?>admin/banner.php?edit=<?= $b['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm" style="border-radius:6px;">
              ✏️ Edit
            </a>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="banner_id" value="<?= $b['id'] ?>">
              <button type="submit" class="btn-admin btn-admin-sm"
                      style="border-radius:6px; background:<?= $b['aktif'] ? '#fffbeb' : '#ecfdf5' ?>; border:1px solid <?= $b['aktif'] ? '#fde68a' : '#a7f3d0' ?>; color:<?= $b['aktif'] ? '#b45309' : '#047857' ?>;">
                <?= $b['aktif'] ? '⏸ Nonaktifkan' : '▶ Aktifkan' ?>
              </button>
            </form>
            <form method="POST" style="display:inline; margin-left:auto;"
                  onsubmit="return confirm('Hapus iklan video \'<?= htmlspecialchars(addslashes($b['judul'])) ?>\'?')">
              <input type="hidden" name="action" value="hapus">
              <input type="hidden" name="banner_id" value="<?= $b['id'] ?>">
              <button type="submit" class="btn-admin btn-admin-sm" style="border-radius:6px; background:#fff1f2; border:1px solid #fecdd3; color:#be123c;">
                🗑
              </button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- SECTION 2: BANNER DISKON PRODUK (BAGIAN BAWAH BERANDA) -->
<div class="promo-section-block" id="blockSectionDiskon">
  <div class="promo-section-header header-diskon">
    <div>
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:4px; flex-wrap:wrap;">
        <h3 style="font-size:16px; font-weight:800; color:#1e293b; margin:0; display:flex; align-items:center; gap:8px;">
          <span>🏷️</span> Banner Diskon Produk
        </h3>
        <span style="background:#fff1f2; color:#be123c; font-size:11px; font-weight:800; padding:2px 8px; border-radius:6px; border:1px solid #fecdd3;">
          BAGIAN BAWAH BERANDA • SLIDER DISKON
        </span>
      </div>
      <p style="font-size:12.5px; color:#64748b; margin:0;">
        Slider promosi potongan harga, flash sale, voucher diskon %, dan showcase produk terkait di bawah iklan video.
      </p>
    </div>
    <a href="<?= BASE_URL ?>admin/banner.php?tambah&type=diskon" class="btn-top-diskon" style="padding:8px 16px; font-size:12.5px;">
      + Tambah Banner Diskon
    </a>
  </div>

  <?php if (empty($list_diskon)): ?>
    <div style="background:#ffffff; border:1.5px dashed #cbd5e1; border-radius:14px; padding:36px 20px; text-align:center; color:#64748b;">
      <div style="font-size:36px; margin-bottom:8px;">🏷️</div>
      <div style="font-weight:800; color:#1e293b; font-size:15px;">Belum ada banner diskon produk</div>
      <p style="font-size:12.5px; margin:4px auto 16px auto; max-width:480px;">
        Buat banner diskon dengan potongan harga spesial dan link produk untuk ditampilkan di slider beranda.
      </p>
      <a href="<?= BASE_URL ?>admin/banner.php?tambah&type=diskon" class="btn-top-diskon" style="padding:8px 18px; font-size:13px;">
        Tambah Banner Diskon Pertama
      </a>
    </div>
  <?php else: ?>
    <div class="promo-cards-grid">
      <?php foreach ($list_diskon as $b):
        $pct = (!empty($b['harga_asli']) && !empty($b['harga_diskon']))
               ? round((1 - $b['harga_diskon'] / $b['harga_asli']) * 100) : 0;
      ?>
        <div class="promo-card" data-type="diskon" data-active="<?= $b['aktif'] ? '1' : '0' ?>" style="border-top:3px solid #e11d48;">
          <!-- Image Diskon Preview (Grounded Relative Container) -->
          <div class="promo-card-preview" style="position:relative; height:185px; width:100%; overflow:hidden; background-color:<?= htmlspecialchars($b['warna_bg'] ?? '#111827') ?>;">
            <?php if (!empty($b['gambar'])): ?>
              <img src="<?= BASE_URL ?>uploads/banners/<?= htmlspecialchars($b['gambar']) ?>"
                   style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover;"
                   onerror="this.style.display='none'"
                   alt="Banner">
            <?php endif; ?>
            <div style="position:absolute; inset:0; background:linear-gradient(180deg, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.72) 100%); pointer-events:none;"></div>

            <!-- Badges Top -->
            <div style="position:absolute; top:12px; left:12px; right:12px; display:flex; justify-content:space-between; align-items:center; z-index:2;">
              <span class="badge-type-diskon" style="box-shadow:0 2px 6px rgba(0,0,0,0.2);">
                🏷️ BAWAH • DISKON
              </span>
              <span style="background:<?= $b['aktif'] ? '#16a34a' : '#dc2626' ?>; color:#fff; font-size:10px; font-weight:800; padding:3px 10px; border-radius:20px; box-shadow:0 2px 6px rgba(0,0,0,0.2);">
                <?= $b['aktif'] ? '● AKTIF' : '○ NONAKTIF' ?>
              </span>
            </div>

            <!-- Bottom Promo Info (Strictly Contained Inside Preview) -->
            <div style="position:absolute; bottom:12px; left:14px; right:14px; z-index:2; pointer-events:none;">
              <?php if (!empty($b['label_diskon'])): ?>
                <span style="display:inline-block; background:#e11d48; color:#fff; font-size:10px; font-weight:800; padding:2px 7px; border-radius:4px; letter-spacing:0.8px; text-transform:uppercase; margin-bottom:4px;">
                  <?= htmlspecialchars($b['label_diskon']) ?>
                </span>
              <?php endif; ?>
              <div style="font-size:16px; font-weight:800; color:#ffffff; line-height:1.25; text-shadow:0 1px 4px rgba(0,0,0,0.8); overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                <?= htmlspecialchars($b['judul']) ?>
              </div>
            </div>
          </div>

          <!-- Diskon Details -->
          <div class="promo-card-body">
            <div>
              <?php if (!empty($b['subjudul'])): ?>
                <p style="font-size:12.5px; color:#64748b; margin-bottom:12px; line-height:1.4;">
                  <?= htmlspecialchars(mb_strimwidth($b['subjudul'], 0, 75, '…')) ?>
                </p>
              <?php endif; ?>

              <?php if (!empty($b['harga_diskon']) || !empty($b['harga_asli'])): ?>
                <div style="display:flex; align-items:baseline; gap:8px; margin-bottom:10px;">
                  <?php if (!empty($b['harga_diskon'])): ?>
                    <span style="font-size:16px; font-weight:800; color:#e11d48;">
                      <?= format_rupiah($b['harga_diskon']) ?>
                    </span>
                  <?php endif; ?>
                  <?php if (!empty($b['harga_asli'])): ?>
                    <span style="font-size:12px; text-decoration:line-through; color:#94a3b8;">
                      <?= format_rupiah($b['harga_asli']) ?>
                    </span>
                  <?php endif; ?>
                  <?php if ($pct > 0): ?>
                    <span style="background:#fee2e2; color:#b91c1c; font-size:10.5px; font-weight:700; padding:2px 6px; border-radius:4px;">
                      -<?= $pct ?>%
                    </span>
                  <?php endif; ?>
                </div>
              <?php endif; ?>

              <?php if (!empty($b['nama_produk'])): ?>
                <div style="font-size:12px; color:#475569; background:#f8fafc; padding:6px 10px; border-radius:6px; margin-bottom:10px; display:flex; align-items:center; gap:6px; border:1px solid #e2e8f0;">
                  <span>👗 Produk:</span>
                  <b style="color:#1e293b;"><?= htmlspecialchars(mb_strimwidth($b['nama_produk'], 0, 26, '…')) ?></b>
                </div>
              <?php endif; ?>

              <div style="font-size:11.5px; color:#94a3b8; display:flex; justify-content:space-between; margin-bottom:4px;">
                <span>Urutan: <b>#<?= $b['urutan'] ?></b></span>
                <span>CTA: <b><?= htmlspecialchars($b['teks_tombol'] ?: 'Belanja Sekarang') ?></b></span>
              </div>
            </div>
          </div>

          <!-- Actions -->
          <div class="promo-card-actions">
            <a href="<?= BASE_URL ?>admin/banner.php?edit=<?= $b['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm" style="border-radius:6px;">
              ✏️ Edit
            </a>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="banner_id" value="<?= $b['id'] ?>">
              <button type="submit" class="btn-admin btn-admin-sm"
                      style="border-radius:6px; background:<?= $b['aktif'] ? '#fffbeb' : '#ecfdf5' ?>; border:1px solid <?= $b['aktif'] ? '#fde68a' : '#a7f3d0' ?>; color:<?= $b['aktif'] ? '#b45309' : '#047857' ?>;">
                <?= $b['aktif'] ? '⏸ Nonaktifkan' : '▶ Aktifkan' ?>
              </button>
            </form>
            <form method="POST" style="display:inline; margin-left:auto;"
                  onsubmit="return confirm('Hapus banner diskon \'<?= htmlspecialchars(addslashes($b['judul'])) ?>\'?')">
              <input type="hidden" name="action" value="hapus">
              <input type="hidden" name="banner_id" value="<?= $b['id'] ?>">
              <button type="submit" class="btn-admin btn-admin-sm" style="border-radius:6px; background:#fff1f2; border:1px solid #fecdd3; color:#be123c;">
                🗑
              </button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<script>
// Filter Tab Pills
function filterBanners(type, btn) {
  document.querySelectorAll('.filter-pill').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  const blockVid = document.getElementById('blockSectionVideo');
  const blockDsk = document.getElementById('blockSectionDiskon');

  if (type === 'all') {
    if (blockVid) blockVid.style.display = 'block';
    if (blockDsk) blockDsk.style.display = 'block';
    document.querySelectorAll('.promo-card').forEach(c => c.style.display = 'flex');
  } else if (type === 'video') {
    if (blockVid) blockVid.style.display = 'block';
    if (blockDsk) blockDsk.style.display = 'none';
    document.querySelectorAll('#blockSectionVideo .promo-card').forEach(c => c.style.display = 'flex');
  } else if (type === 'diskon') {
    if (blockVid) blockVid.style.display = 'none';
    if (blockDsk) blockDsk.style.display = 'block';
    document.querySelectorAll('#blockSectionDiskon .promo-card').forEach(c => c.style.display = 'flex');
  } else if (type === 'active') {
    if (blockVid) blockVid.style.display = 'block';
    if (blockDsk) blockDsk.style.display = 'block';
    document.querySelectorAll('.promo-card').forEach(c => {
      c.style.display = (c.dataset.active === '1') ? 'flex' : 'none';
    });
  }
}
</script>

<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
