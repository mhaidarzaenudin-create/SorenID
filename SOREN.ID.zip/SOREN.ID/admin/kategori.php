<?php
// admin/kategori.php - Category Management
$admin_title = 'Kelola Kategori Produk';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$success = '';
$error = '';

// Tambah Kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_kategori'])) {
    $nama = clean_input($_POST['nama_kategori'] ?? '');
    if (!empty($nama)) {
        $stmt = $pdo->prepare("INSERT INTO kategori (nama_kategori) VALUES (?)");
        $stmt->execute([$nama]);
        $success = 'Kategori baru berhasil ditambahkan!';
    } else {
        $error = 'Nama kategori tidak boleh kosong.';
    }
}

// Edit Kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_kategori'])) {
    $id_kat = (int)$_POST['id'];
    $nama = clean_input($_POST['nama_kategori'] ?? '');
    if (!empty($nama)) {
        $stmt = $pdo->prepare("UPDATE kategori SET nama_kategori = ? WHERE id = ?");
        $stmt->execute([$nama, $id_kat]);
        $success = 'Nama kategori berhasil diubah!';
    }
}

// Hapus Kategori
if (isset($_GET['hapus'])) {
    $id_del = (int)$_GET['hapus'];
    try {
        $del = $pdo->prepare("DELETE FROM kategori WHERE id = ?");
        $del->execute([$id_del]);
        $success = 'Kategori berhasil dihapus.';
    } catch (Exception $e) {
        $error = 'Tidak dapat menghapus kategori yang masih memiliki produk.';
    }
}

$categories = get_categories($pdo);

include __DIR__ . '/includes/header.php';
?>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; align-items: flex-start;">
  <!-- Form Tambah -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Tambah Kategori Baru</h3>
    </div>
    <div class="card-body">
      <?php if (!empty($success)): ?>
        <div style="background:#dcfce7; color:#166534; padding:10px 14px; border-radius:6px; margin-bottom:14px; font-size:12.5px;">
          ✓ <?= htmlspecialchars($success) ?>
        </div>
      <?php endif; ?>
      <?php if (!empty($error)): ?>
        <div style="background:#fee2e2; color:#b91c1c; padding:10px 14px; border-radius:6px; margin-bottom:14px; font-size:12.5px;">
          ⚠️ <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="">
        <input type="hidden" name="tambah_kategori" value="1">
        <div class="form-group">
          <label class="form-label">Nama Kategori Produk</label>
          <input type="text" name="nama_kategori" class="form-control" placeholder="Contoh: Atasan / Bawahan / One Set" required>
        </div>
        <button type="submit" class="btn-admin btn-admin-primary" style="width: 100%; justify-content: center;">
          + Simpan Kategori
        </button>
      </form>
    </div>
  </div>

  <!-- List Kategori -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Daftar Kategori Aktif (<?= count($categories) ?>)</h3>
    </div>
    <div class="card-body">
      <table class="table">
        <thead>
          <tr>
            <th style="width: 60px;">ID</th>
            <th>Nama Kategori</th>
            <th style="text-align: center;">Jumlah Produk</th>
            <th style="text-align: center; width: 140px;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($categories as $c): ?>
            <tr>
              <td>#<?= $c['id'] ?></td>
              <td><b><?= htmlspecialchars($c['nama_kategori']) ?></b></td>
              <td style="text-align: center;">
                <span class="status-badge" style="background:#f1f5f9; color:#475569;">
                  <?= $c['total_produk'] ?> Produk
                </span>
              </td>
              <td style="text-align: center;">
                <button type="button" class="btn-admin btn-admin-outline btn-admin-sm" onclick="editCat(<?= $c['id'] ?>, '<?= htmlspecialchars(addslashes($c['nama_kategori'])) ?>')">
                  Edit
                </button>
                <a href="<?= BASE_URL ?>admin/kategori.php?hapus=<?= $c['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm" onclick="return confirm('Hapus kategori ini?')" style="color:#ef4444; border-color:#fee2e2;">
                  Hapus
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
  function editCat(id, currentName) {
    const newName = prompt('Ubah nama kategori:', currentName);
    if (newName && newName.trim() !== '') {
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = '';
      form.innerHTML = `
        <input type="hidden" name="edit_kategori" value="1">
        <input type="hidden" name="id" value="${id}">
        <input type="hidden" name="nama_kategori" value="${newName.trim()}">
      `;
      document.body.appendChild(form);
      form.submit();
    }
  }
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
