<?php
// admin/pembayaran.php - Payment Verification & Auto Revenue Recording
$admin_title = 'Verifikasi Pembayaran Pelanggan';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$success = '';
$error = '';

// Handle Konfirmasi Pembayaran
if (isset($_GET['konfirmasi'])) {
    $id_bayar = (int)$_GET['konfirmasi'];

    try {
        $pdo->beginTransaction();

        // Ambil data pembayaran
        $st = $pdo->prepare("SELECT pb.*, p.id_user, usr.nama as customer_name FROM pembayaran pb JOIN pesanan p ON pb.id_pesanan = p.id JOIN users usr ON p.id_user = usr.id WHERE pb.id = ?");
        $st->execute([$id_bayar]);
        $pay = $st->fetch();

        if ($pay) {
            // 1. Update status pembayaran
            $up_pay = $pdo->prepare("UPDATE pembayaran SET status = 'Dibayar', tanggal_pembayaran = NOW() WHERE id = ?");
            $up_pay->execute([$id_bayar]);

            // 2. Update status pesanan jadi Diproses
            $up_ord = $pdo->prepare("UPDATE pesanan SET status = 'Diproses' WHERE id = ?");
            $up_ord->execute([$pay['id_pesanan']]);

            // 3. Catat otomatis ke tabel pemasukan
            $ket = "Pembayaran Pesanan #SOREN-" . str_pad($pay['id_pesanan'], 5, '0', STR_PAD_LEFT) . " - " . $pay['customer_name'];
            $ins_inc = $pdo->prepare("INSERT INTO pemasukan (keterangan, jumlah, tanggal, id_pesanan) VALUES (?, ?, CURDATE(), ?)");
            $ins_inc->execute([$ket, $pay['jumlah'], $pay['id_pesanan']]);

            $pdo->commit();
            $success = 'Pembayaran berhasil dikonfirmasi! Pesanan diubah ke status "Diproses" dan pemasukan telah otomatis dicatat.';
        } else {
            $pdo->rollBack();
            $error = 'Data pembayaran tidak ditemukan.';
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = 'Gagal memproses konfirmasi: ' . $e->getMessage();
    }
}

// Handle Tolak Pembayaran
if (isset($_GET['tolak'])) {
    $id_bayar = (int)$_GET['tolak'];
    $pdo->prepare("UPDATE pembayaran SET status = 'Gagal' WHERE id = ?")->execute([$id_bayar]);
    $success = 'Pembayaran ditandai sebagai Gagal.';
}

// Ambil daftar pembayaran
$stmt = $pdo->query("
    SELECT pb.*, p.id as pesanan_id, p.tanggal_pesanan, usr.nama as customer_name, usr.no_hp
    FROM pembayaran pb
    JOIN pesanan p ON pb.id_pesanan = p.id
    JOIN users usr ON p.id_user = usr.id
    ORDER BY CASE WHEN pb.status = 'Menunggu Konfirmasi' THEN 0 ELSE 1 END, pb.id DESC
");
$payments = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <h3 class="card-title">Daftar Transaksi Pembayaran (<?= count($payments) ?>)</h3>
  </div>

  <?php if (!empty($success)): ?>
    <div style="background:#dcfce7; color:#166534; padding:12px 20px; border-radius:6px; margin: 16px 24px 0 24px; font-size:13px; display:flex; align-items:center; gap:8px;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
      <span><?= htmlspecialchars($success) ?></span>
    </div>
  <?php endif; ?>

  <?php if (!empty($error)): ?>
    <div style="background:#fee2e2; color:#b91c1c; padding:12px 20px; border-radius:6px; margin: 16px 24px 0 24px; font-size:13px; display:flex; align-items:center; gap:8px;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
      <span><?= htmlspecialchars($error) ?></span>
    </div>
  <?php endif; ?>

  <div class="card-body">
    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th>No. Pesanan</th>
            <th>Pelanggan</th>
            <th>Metode & Tanggal</th>
            <th>Jumlah Tagihan</th>
            <th style="text-align: center;">Bukti Transfer</th>
            <th>Status Pembayaran</th>
            <th style="text-align: center;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($payments)): ?>
            <tr><td colspan="7" style="text-align:center; padding:30px; color:#888;">Belum ada data pembayaran.</td></tr>
          <?php else: ?>
            <?php foreach ($payments as $pb): ?>
              <tr>
                <td>
                  <a href="<?= BASE_URL ?>admin/pesanan-detail.php?id=<?= $pb['pesanan_id'] ?>" style="font-weight:700; color:var(--admin-primary);">
                    #SOREN-<?= str_pad($pb['pesanan_id'], 5, '0', STR_PAD_LEFT) ?>
                  </a>
                </td>
                <td>
                  <div style="font-weight:700; color:var(--admin-text-dark);"><?= htmlspecialchars($pb['customer_name']) ?></div>
                  <div style="font-size:11.5px; color:#888;"><?= htmlspecialchars($pb['no_hp'] ?: '-') ?></div>
                </td>
                <td>
                  <div style="font-weight:600; font-size:13px;"><?= htmlspecialchars($pb['metode']) ?></div>
                  <div style="font-size:11.5px; color:#888;"><?= date('d/m/Y H:i', strtotime($pb['tanggal_pesanan'])) ?></div>
                </td>
                <td style="font-weight:700; font-size:14px; color:var(--admin-primary);">
                  <?= format_rupiah($pb['jumlah']) ?>
                </td>
                <td style="text-align: center;">
                  <?php if (!empty($pb['bukti_pembayaran'])): ?>
                    <a href="<?= UPLOADS_URL ?>payments/<?= htmlspecialchars($pb['bukti_pembayaran']) ?>" target="_blank" style="display:inline-flex; align-items:center; gap:5px; font-size:12px; color:var(--admin-primary); font-weight:600;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                      </svg>
                      <span>Lihat Bukti</span>
                    </a>
                  <?php else: ?>
                    <span style="font-size:12px; color:#999;">Belum ada</span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php 
                    $badge = 'status-pending';
                    if ($pb['status'] === 'Dibayar') $badge = 'status-completed';
                    elseif ($pb['status'] === 'Gagal') $badge = 'status-cancelled';
                  ?>
                  <span class="status-badge <?= $badge ?>">
                    <?= htmlspecialchars($pb['status']) ?>
                  </span>
                </td>
                <td style="text-align: center;">
                  <?php if ($pb['status'] === 'Menunggu Konfirmasi' || $pb['status'] === 'Belum Dibayar'): ?>
                    <div style="display:flex; gap:6px; justify-content:center;">
                      <a href="<?= BASE_URL ?>admin/pembayaran.php?konfirmasi=<?= $pb['id'] ?>" class="btn-admin btn-admin-primary btn-admin-sm" onclick="return confirm('Konfirmasi pembayaran ini? Sistem akan otomatis mencatat ke pemasukan dan mengubah status pesanan ke Diproses.')" style="display:inline-flex; align-items:center; gap:4px;">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                        <span>Setujui</span>
                      </a>
                      <a href="<?= BASE_URL ?>admin/pembayaran.php?tolak=<?= $pb['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm" onclick="return confirm('Tolak pembayaran ini?')" style="color:#ef4444; border-color:#fee2e2; display:inline-flex; align-items:center; gap:4px;">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        <span>Tolak</span>
                      </a>
                    </div>
                  <?php else: ?>
                    <span style="font-size:12px; color:#888;">Selesai</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
