<?php
// admin/produk.php - Product List & Management
$admin_title = 'Kelola Produk';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$success = '';
$error = '';

if (!empty($_SESSION['flash_success'])) {
    $success = $_SESSION['flash_success'];
    unset($_SESSION['flash_success']);
}
if (!empty($_SESSION['flash_error'])) {
    $error = $_SESSION['flash_error'];
    unset($_SESSION['flash_error']);
}

// Handle Hapus Foto Produk Saja
if (isset($_GET['hapus_foto'])) {
    $del_img_id = (int)$_GET['hapus_foto'];

    $stmt_img = $pdo->prepare("SELECT id, nama_produk, gambar FROM produk WHERE id = ?");
    $stmt_img->execute([$del_img_id]);
    $prod_data = $stmt_img->fetch();

    if ($prod_data && !empty($prod_data['gambar'])) {
        $img_file = $prod_data['gambar'];

        // Cek apakah gambar digunakan oleh produk lain
        $check_other = $pdo->prepare("SELECT COUNT(*) FROM produk WHERE gambar = ? AND id != ?");
        $check_other->execute([$img_file, $del_img_id]);
        if ((int)$check_other->fetchColumn() === 0) {
            $file_path = __DIR__ . '/../uploads/products/' . $img_file;
            if (file_exists($file_path)) {
                @unlink($file_path);
            }
        }

        $update_stmt = $pdo->prepare("UPDATE produk SET gambar = NULL WHERE id = ?");
        $update_stmt->execute([$del_img_id]);
        $success = 'Foto untuk produk "' . htmlspecialchars($prod_data['nama_produk']) . '" berhasil dihapus.';
    } else {
        $error = 'Produk tidak memiliki foto atau data produk tidak ditemukan.';
    }
}

// Handle Hapus Produk
if (isset($_GET['hapus'])) {
    $del_id = (int)$_GET['hapus'];

    // Ambil nama file gambar terlebih dahulu sebelum produk dihapus
    $img_check = $pdo->prepare("SELECT gambar FROM produk WHERE id = ?");
    $img_check->execute([$del_id]);
    $del_img = $img_check->fetchColumn();

    try {
        $pdo->beginTransaction();

        // Hapus data terkait agar produk bisa dihapus dalam kondisi apa pun
        $pdo->prepare("DELETE FROM keranjang WHERE id_produk = ?")->execute([$del_id]);
        $pdo->prepare("DELETE FROM ulasan_produk WHERE id_produk = ?")->execute([$del_id]);
        $pdo->prepare("DELETE FROM detail_pesanan WHERE id_produk = ?")->execute([$del_id]);

        $stmt = $pdo->prepare("DELETE FROM produk WHERE id = ?");
        $deleted = $stmt->execute([$del_id]);

        if ($deleted && $stmt->rowCount() > 0) {
            // Hapus file fisik gambar jika tidak digunakan oleh produk lain
            if (!empty($del_img)) {
                $chk_other = $pdo->prepare("SELECT COUNT(*) FROM produk WHERE gambar = ?");
                $chk_other->execute([$del_img]);
                if ((int)$chk_other->fetchColumn() === 0) {
                    $fpath = __DIR__ . '/../uploads/products/' . $del_img;
                    if (file_exists($fpath)) {
                        @unlink($fpath);
                    }
                }
            }

            $pdo->commit();
            $success = 'Produk berhasil dihapus dari katalog.';
        } else {
            $pdo->rollBack();
            $error = 'Produk tidak ditemukan atau gagal dihapus.';
        }
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = 'Gagal menghapus produk: ' . $e->getMessage();
    }
}

// Ambil semua produk
$stmt = $pdo->query("
    SELECT p.*, k.nama_kategori 
    FROM produk p 
    JOIN kategori k ON p.id_kategori = k.id 
    ORDER BY p.id DESC
");
$products = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <h3 class="card-title">Daftar Produk Toko (<?= count($products) ?>)</h3>
    <a href="<?= BASE_URL ?>admin/produk-form.php" class="btn-admin btn-admin-primary" style="display:inline-flex; align-items:center; gap:6px;">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="5" x2="12" y2="19"></line>
        <line x1="5" y1="12" x2="19" y2="12"></line>
      </svg>
      <span>Tambah Produk Baru</span>
    </a>
  </div>

  <?php if (!empty($success)): ?>
    <div style="background:#dcfce7; color:#166534; padding:12px 20px; border-radius:6px; margin: 16px 24px 0 24px; font-size:13px; display:flex; align-items:center; gap:8px;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
      <span><?= htmlspecialchars($success) ?></span>
    </div>
  <?php endif; ?>

  <?php if (!empty($error)): ?>
    <div style="background:#fee2e2; color:#b91c1c; padding:12px 20px; border-radius:6px; margin: 16px 24px 0 24px; font-size:13px; display:flex; align-items:center; gap:8px;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
      <span><?= htmlspecialchars($error) ?></span>
    </div>
  <?php endif; ?>

  <div class="card-body">
    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th style="width: 70px;">Gambar</th>
            <th>Nama Produk & Warna</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th style="text-align: center;">Stok</th>
            <th>Ukuran</th>
            <th style="text-align: center;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($products as $p): ?>
            <tr>
              <td>
                <?php if (!empty($p['gambar'])): ?>
                  <div style="width: 50px; height: 50px; border-radius:6px; overflow:hidden; background:#eee; border:1px solid #e2e8f0;">
                    <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($p['gambar']) ?>" onerror="this.src='../assets/images/banners/hero-1.jpg'" style="width:100%; height:100%; object-fit:cover;">
                  </div>
                <?php else: ?>
                  <div style="width: 50px; height: 50px; border-radius:6px; background:#f8fafc; border:1px dashed #cbd5e1; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#94a3b8; font-size:9.5px; gap:2px;" title="Tidak ada foto produk">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
                      <circle cx="12" cy="13" r="4"></circle>
                    </svg>
                    <span>No Foto</span>
                  </div>
                <?php endif; ?>
              </td>
              <td>
                <div style="font-weight:700; color:var(--admin-text-dark); font-size:14px;">
                  <?= htmlspecialchars($p['nama_produk']) ?>
                </div>
                <div style="font-size:11.5px; color:#888;">
                  Warna: <?= htmlspecialchars($p['warna'] ?: '-') ?>
                </div>
              </td>
              <td>
                <span class="status-badge" style="background:#f1f5f9; color:#475569;">
                  <?= htmlspecialchars($p['nama_kategori']) ?>
                </span>
              </td>
              <td style="font-weight:700; color:var(--admin-primary);">
                <?= format_rupiah($p['harga']) ?>
              </td>
              <td style="text-align: center;">
                <b style="<?= $p['stok'] <= 5 ? 'color:#ef4444;' : 'color:#16a34a;' ?>">
                  <?= $p['stok'] ?>
                </b> pcs
              </td>
              <td><?= htmlspecialchars($p['ukuran'] ?: 'All Size') ?></td>
              <td style="text-align: center;">
                <div style="display:flex; gap:6px; justify-content:center; flex-wrap:wrap;">
                  <a href="<?= BASE_URL ?>admin/produk-form.php?id=<?= $p['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm" title="Ubah data produk">
                    Edit
                  </a>
                  <?php if (!empty($p['gambar'])): ?>
                    <a href="<?= BASE_URL ?>admin/produk.php?hapus_foto=<?= $p['id'] ?>" 
                       class="btn-admin btn-admin-outline btn-admin-sm" 
                       onclick="return confirm('Apakah Anda yakin ingin menghapus foto untuk produk \'<?= htmlspecialchars(addslashes($p['nama_produk'])) ?>\'?');" 
                       style="color:#d97706; border-color:#fde68a; display:inline-flex; align-items:center; gap:4px;" 
                       title="Hapus foto produk ini">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                      </svg>
                      <span>Hapus Foto</span>
                    </a>
                  <?php endif; ?>
                  <a href="<?= BASE_URL ?>admin/produk.php?hapus=<?= $p['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm" onclick="return confirm('Hapus produk ini?')" style="color:#ef4444; border-color:#fee2e2;" title="Hapus produk permanen">
                    Hapus
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
