<?php
// admin/index.php - Admin Dashboard for SOREN.ID
$admin_title = 'Dashboard Ringkasan';
include __DIR__ . '/includes/header.php';

// Hitung statistik
$stmt_income = $pdo->query("SELECT COALESCE(SUM(jumlah), 0) as total_omset FROM pemasukan");
$total_omset = (float)($stmt_income->fetch()['total_omset'] ?? 0);

$stmt_orders_count = $pdo->query("SELECT COUNT(*) as total_pesanan FROM pesanan");
$total_pesanan = (int)($stmt_orders_count->fetch()['total_pesanan'] ?? 0);

$stmt_prod_count = $pdo->query("SELECT COUNT(*) as total_produk FROM produk");
$total_produk = (int)($stmt_prod_count->fetch()['total_produk'] ?? 0);

$stmt_rev_count = $pdo->query("SELECT COUNT(*) as total_ulasan, COALESCE(AVG(rating), 5.0) as avg_rating FROM ulasan_produk");
$rev_stats = $stmt_rev_count->fetch();
$total_ulasan = (int)($rev_stats['total_ulasan'] ?? 0);
$avg_rating = round((float)($rev_stats['avg_rating'] ?? 5.0), 1);

// Ambil 5 pesanan terbaru
$stmt_recent_orders = $pdo->query("
    SELECT p.*, usr.nama as customer_name, pb.metode, pb.status as status_bayar
    FROM pesanan p
    JOIN users usr ON p.id_user = usr.id
    LEFT JOIN pembayaran pb ON p.id = pb.id_pesanan
    ORDER BY p.id DESC
    LIMIT 5
");
$recent_orders = $stmt_recent_orders->fetchAll();

// Ambil 4 ulasan terbaru
$stmt_recent_reviews = $pdo->query("
    SELECT u.*, p.nama_produk, usr.nama as customer_name
    FROM ulasan_produk u
    JOIN produk p ON u.id_produk = p.id
    JOIN users usr ON u.id_user = usr.id
    ORDER BY u.id DESC
    LIMIT 4
");
$recent_reviews = $stmt_recent_reviews->fetchAll();
?>

<!-- Metric Stats Cards -->
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-info">
      <h3><?= format_rupiah($total_omset) ?></h3>
      <p>Total Pemasukan Toko</p>
    </div>
    <div class="stat-icon icon-green" title="Total Pemasukan">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="2" y="5" width="20" height="14" rx="2"></rect>
        <line x1="2" y1="10" x2="22" y2="10"></line>
        <path d="M16 14h2"></path>
      </svg>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-info">
      <h3><?= $total_pesanan ?></h3>
      <p>Total Pesanan Masuk</p>
    </div>
    <div class="stat-icon icon-blue" title="Pesanan Masuk">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="16.5" y1="9.4" x2="7.55" y2="4.21"></line>
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
        <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
        <line x1="12" y1="22.08" x2="12" y2="12"></line>
      </svg>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-info">
      <h3><?= $total_produk ?></h3>
      <p>Produk Aktif di Katalog</p>
    </div>
    <div class="stat-icon icon-purple" title="Produk Aktif">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
        <line x1="3" y1="6" x2="21" y2="6"></line>
        <path d="M16 10a4 4 0 0 1-8 0"></path>
      </svg>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-info">
      <h3><?= $total_ulasan ?> (★ <?= $avg_rating ?>)</h3>
      <p>Ulasan Produk</p>
    </div>
    <div class="stat-icon icon-rose" title="Ulasan Pelanggan">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
      </svg>
    </div>
  </div>
</div>

<!-- Alerts if pending tasks exist -->
<?php if ($pending_pay > 0): ?>
  <div style="background:#fff8e1; border-left:4px solid #f39c12; padding:14px 20px; border-radius:6px; margin-bottom:24px; display:flex; justify-content:space-between; align-items:center;">
    <div>
      <b>Perhatian:</b> Terdapat <b><?= $pending_pay ?></b> pembayaran baru yang menunggu konfirmasi bukti transfer dari admin!
    </div>
    <a href="<?= BASE_URL ?>admin/pembayaran.php" class="btn-admin btn-admin-primary btn-admin-sm">Verifikasi Sekarang</a>
  </div>
<?php endif; ?>

<!-- Two Columns: Recent Orders & Recent Reviews -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
  <!-- Pesanan Terbaru -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Pesanan Pelanggan Terbaru</h3>
      <a href="<?= BASE_URL ?>admin/pesanan.php" class="btn-admin btn-admin-outline btn-admin-sm">Lihat Semua</a>
    </div>
    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th>No. Pesanan</th>
            <th>Pelanggan</th>
            <th>Total Tagihan</th>
            <th>Status</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recent_orders)): ?>
            <tr><td colspan="5" style="text-align:center; padding:20px; color:#888;">Belum ada pesanan masuk.</td></tr>
          <?php else: ?>
            <?php foreach ($recent_orders as $ord): 
              $st_badge = 'status-pending';
              if ($ord['status'] === 'Diproses') $st_badge = 'status-process';
              elseif ($ord['status'] === 'Dikirim') $st_badge = 'status-shipped';
              elseif ($ord['status'] === 'Selesai') $st_badge = 'status-completed';
              elseif ($ord['status'] === 'Dibatalkan') $st_badge = 'status-cancelled';
            ?>
              <tr>
                <td><b>#SOREN-<?= str_pad($ord['id'], 5, '0', STR_PAD_LEFT) ?></b></td>
                <td>
                  <div><b><?= htmlspecialchars($ord['customer_name']) ?></b></div>
                  <div style="font-size:11px; color:#888;"><?= date('d/m/Y H:i', strtotime($ord['tanggal_pesanan'])) ?></div>
                </td>
                <td style="font-weight:700; color:var(--admin-primary);"><?= format_rupiah($ord['total_harga']) ?></td>
                <td><span class="status-badge <?= $st_badge ?>"><?= htmlspecialchars($ord['status']) ?></span></td>
                <td>
                  <a href="<?= BASE_URL ?>admin/pesanan-detail.php?id=<?= $ord['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm">Detail</a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Ulasan Terbaru -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Ulasan Terbaru</h3>
      <a href="<?= BASE_URL ?>admin/ulasan.php" class="btn-admin btn-admin-outline btn-admin-sm">Kelola</a>
    </div>
    <div class="card-body" style="padding: 16px;">
      <?php if (empty($recent_reviews)): ?>
        <p style="text-align:center; color:#888; font-size:13px; padding:20px;">Belum ada ulasan produk.</p>
      <?php else: ?>
        <div style="display:flex; flex-direction:column; gap:14px;">
          <?php foreach ($recent_reviews as $r): ?>
            <div style="border-bottom:1px solid var(--admin-border); padding-bottom:12px;">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                <b style="font-size:13px;"><?= htmlspecialchars($r['customer_name']) ?></b>
                <span style="color:#f5a623; font-size:12px;"><?= str_repeat('★', $r['rating']) ?></span>
              </div>
              <div style="font-size:11.5px; color:#888; margin-bottom:4px;">Produk: <?= htmlspecialchars($r['nama_produk']) ?></div>
              <div style="font-size:12.5px; color:#444; line-height:1.4;">"<?= htmlspecialchars(mb_strimwidth($r['ulasan'], 0, 80, '...')) ?>"</div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
