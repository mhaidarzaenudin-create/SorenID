<?php
// admin/includes/footer.php - Admin Footer Component
?>
    </main>
  </div>
</div>

</body>
</html>
