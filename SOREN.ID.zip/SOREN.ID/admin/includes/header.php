<?php
// admin/includes/header.php - Admin Header & Navigation Sidebar
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

// Cek hak akses admin
if (!is_admin()) {
    header('Location: ' . BASE_URL . 'admin/login.php');
    exit;
}

$cur_page = basename($_SERVER['PHP_SELF']);

// Hitung chat belum dibaca
$stmt_chat = $pdo->query("SELECT COUNT(*) as unread FROM chat_messages WHERE pengirim = 'user' AND dibaca = 0");
$unread_chat = (int)($stmt_chat->fetch()['unread'] ?? 0);

// Hitung pembayaran menunggu konfirmasi
$stmt_pay = $pdo->query("SELECT COUNT(*) as pending_pay FROM pembayaran WHERE status = 'Menunggu Konfirmasi'");
$pending_pay = (int)($stmt_pay->fetch()['pending_pay'] ?? 0);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($admin_title) ? htmlspecialchars($admin_title) . ' - Admin SOREN.ID' : 'Admin Portal - SOREN.ID' ?></title>
  <link rel="stylesheet" href="<?= ASSETS_URL ?>css/admin.css?v=<?= @filemtime(__DIR__ . '/../../assets/css/admin.css') ?: time() ?>">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>👑</text></svg>">
</head>
<body>

<div class="admin-wrapper">
  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="sidebar-logo">SOREN.</span>
      <span class="sidebar-badge">ADMIN</span>
    </div>

    <ul class="sidebar-nav">
      <li class="nav-item <?= $cur_page === 'index.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/index.php">
          <div class="nav-label">
            <span class="nav-icon icon-dashboard">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="7" height="9" rx="1.5"></rect>
                <rect x="14" y="3" width="7" height="5" rx="1.5"></rect>
                <rect x="14" y="12" width="7" height="9" rx="1.5"></rect>
                <rect x="3" y="16" width="7" height="5" rx="1.5"></rect>
              </svg>
            </span>
            <span>Dashboard</span>
          </div>
        </a>
      </li>

      <li class="nav-item <?= in_array($cur_page, ['produk.php', 'produk-form.php']) ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/produk.php">
          <div class="nav-label">
            <span class="nav-icon icon-produk">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <path d="M16 10a4 4 0 0 1-8 0"></path>
              </svg>
            </span>
            <span>Kelola Produk</span>
          </div>
        </a>
      </li>

      <li class="nav-item <?= $cur_page === 'kategori.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/kategori.php">
          <div class="nav-label">
            <span class="nav-icon icon-kategori">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                <line x1="7" y1="7" x2="7.01" y2="7"></line>
              </svg>
            </span>
            <span>Kategori Produk</span>
          </div>
        </a>
      </li>

      <li class="nav-item <?= $cur_page === 'banner.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/banner.php">
          <div class="nav-label">
            <span class="nav-icon icon-banner">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polygon points="23 7 16 12 23 17 23 7"></polygon>
                <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
              </svg>
            </span>
            <span>Banner & Iklan Video</span>
          </div>
        </a>
      </li>

      <li class="nav-item <?= in_array($cur_page, ['pesanan.php', 'pesanan-detail.php']) ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/pesanan.php">
          <div class="nav-label">
            <span class="nav-icon icon-pesanan">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="16.5" y1="9.4" x2="7.55" y2="4.21"></line>
                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                <line x1="12" y1="22.08" x2="12" y2="12"></line>
              </svg>
            </span>
            <span>Pesanan Masuk</span>
          </div>
        </a>
      </li>

      <li class="nav-item <?= $cur_page === 'pembayaran.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/pembayaran.php">
          <div class="nav-label">
            <span class="nav-icon icon-bayar">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="1" y="4" width="22" height="16" rx="2.5"></rect>
                <line x1="1" y1="10" x2="23" y2="10"></line>
                <line x1="5" y1="15" x2="9" y2="15"></line>
              </svg>
            </span>
            <span>Verifikasi Bayar</span>
          </div>
          <?php if ($pending_pay > 0): ?>
            <span class="nav-counter"><?= $pending_pay ?></span>
          <?php endif; ?>
        </a>
      </li>

      <!-- FITUR ULASAN PRODUK ADMIN -->
      <li class="nav-item <?= $cur_page === 'ulasan.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/ulasan.php">
          <div class="nav-label">
            <span class="nav-icon icon-ulasan">
              <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
              </svg>
            </span>
            <span>Ulasan Produk</span>
          </div>
        </a>
      </li>

      <!-- FITUR LIVE CHAT ADMIN -->
      <li class="nav-item <?= $cur_page === 'chat.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/chat.php">
          <div class="nav-label">
            <span class="nav-icon icon-chat">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
              </svg>
            </span>
            <span>Live Chat</span>
          </div>
          <?php if ($unread_chat > 0): ?>
            <span class="nav-counter" id="sidebarChatBadge"><?= $unread_chat ?></span>
          <?php endif; ?>
        </a>
      </li>

      <li class="nav-item <?= $cur_page === 'laporan.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/laporan.php">
          <div class="nav-label">
            <span class="nav-icon icon-laporan">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                <polyline points="17 6 23 6 23 12"></polyline>
              </svg>
            </span>
            <span>Laporan & Kritik</span>
          </div>
        </a>
      </li>

      <li class="nav-item <?= $cur_page === 'toko.php' ? 'active' : '' ?>">
        <a href="<?= BASE_URL ?>admin/toko.php">
          <div class="nav-label">
            <span class="nav-icon icon-toko">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
              </svg>
            </span>
            <span>Profil Toko</span>
          </div>
        </a>
      </li>
    </ul>

    <div class="sidebar-footer">
      <a href="<?= BASE_URL ?>" target="_blank" class="sidebar-footer-link store-link">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
          <polyline points="15 3 21 3 21 9"></polyline>
          <line x1="10" y1="14" x2="21" y2="3"></line>
        </svg>
        <span>Lihat Toko Online</span>
      </a>
      <a href="<?= BASE_URL ?>admin/logout.php" class="sidebar-footer-link logout-link">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
          <polyline points="16 17 21 12 16 7"></polyline>
          <line x1="21" y1="12" x2="9" y2="12"></line>
        </svg>
        <span>Keluar (Logout)</span>
      </a>
    </div>
  </aside>

  <!-- Content Container -->
  <div class="admin-content">
    <header class="admin-header">
      <h2><?= $admin_title ?? 'Panel Kontrol Admin' ?></h2>
      <div class="admin-user-profile">
        <div class="admin-avatar">A</div>
        <div>
          <div style="font-weight:700; font-size:13.5px;"><?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin Soren') ?></div>
          <div style="font-size:11.5px; color:var(--admin-text-muted);">Administrator Toko</div>
        </div>
      </div>
    </header>

    <main class="admin-main">
