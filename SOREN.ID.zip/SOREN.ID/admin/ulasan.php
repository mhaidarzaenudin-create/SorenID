<?php
// admin/ulasan.php - Admin Product Review Moderation & Reply Management
$admin_title = 'Kelola Ulasan Produk';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$success = '';
$error = '';

// Handle Balas Ulasan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['balas_ulasan'])) {
    $id_ulasan = (int)$_POST['id_ulasan'];
    $balasan = clean_input($_POST['balasan_admin'] ?? '');

    $stmt = $pdo->prepare("UPDATE ulasan_produk SET balasan_admin = ? WHERE id = ?");
    if ($stmt->execute([$balasan, $id_ulasan])) {
        $success = 'Balasan admin berhasil disimpan dan kini ditampilkan pada halaman produk!';
    } else {
        $error = 'Gagal menyimpan balasan.';
    }
}

// Handle Hapus Ulasan
if (isset($_GET['hapus'])) {
    $id_del = (int)$_GET['hapus'];
    $del = $pdo->prepare("DELETE FROM ulasan_produk WHERE id = ?");
    if ($del->execute([$id_del])) {
        $success = 'Ulasan berhasil dihapus.';
    }
}

// Ambil semua ulasan
$stmt = $pdo->query("
    SELECT u.*, p.nama_produk, p.gambar as gambar_produk, usr.nama as customer_name
    FROM ulasan_produk u
    JOIN produk p ON u.id_produk = p.id
    JOIN users usr ON u.id_user = usr.id
    ORDER BY u.id DESC
");
$reviews = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <h3 class="card-title">Daftar Ulasan & Rating Pelanggan (<?= count($reviews) ?>)</h3>
  </div>

  <?php if (!empty($success)): ?>
    <div style="background:#dcfce7; color:#166534; padding:12px 20px; border-radius:6px; margin: 16px 24px 0 24px; font-size:13px;">
      ✓ <?= htmlspecialchars($success) ?>
    </div>
  <?php endif; ?>

  <div class="card-body">
    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th style="width: 220px;">Produk</th>
            <th style="width: 160px;">Pelanggan & Tanggal</th>
            <th style="width: 100px;">Rating</th>
            <th>Isi Ulasan & Foto</th>
            <th style="width: 240px;">Respon Resmi Admin</th>
            <th style="width: 120px; text-align:center;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($reviews)): ?>
            <tr>
              <td colspan="6" style="text-align:center; padding:30px; color:#888;">Belum ada ulasan dari pembeli.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($reviews as $rev): ?>
              <tr>
                <td>
                  <div style="display:flex; gap:10px; align-items:center;">
                    <div style="width:44px; height:44px; border-radius:6px; overflow:hidden; background:#eee; flex-shrink:0;">
                      <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($rev['gambar_produk']) ?>" onerror="this.src='../assets/images/banners/hero-1.jpg'" style="width:100%; height:100%; object-fit:cover;">
                    </div>
                    <div style="font-weight:600; font-size:13px;"><?= htmlspecialchars($rev['nama_produk']) ?></div>
                  </div>
                </td>
                <td>
                  <div style="font-weight:700; color:var(--admin-text-dark);"><?= htmlspecialchars($rev['customer_name']) ?></div>
                  <div style="font-size:11.5px; color:var(--admin-text-muted);"><?= date('d/m/Y H:i', strtotime($rev['created_at'])) ?></div>
                </td>
                <td>
                  <div style="color:#f5a623; font-size:14px; letter-spacing:1px;">
                    <?= str_repeat('★', $rev['rating']) ?>
                  </div>
                  <div style="font-size:11px; color:#888;"><?= $rev['rating'] ?> dari 5</div>
                </td>
                <td>
                  <div style="font-size:13px; line-height:1.5; color:#333; margin-bottom:8px;">
                    <?= nl2br(htmlspecialchars($rev['ulasan'])) ?>
                  </div>
                  <?php if (!empty($rev['foto'])): ?>
                    <a href="<?= UPLOADS_URL ?>reviews/<?= htmlspecialchars($rev['foto']) ?>" target="_blank" style="display:inline-flex; align-items:center; gap:6px; font-size:11.5px; color:var(--admin-primary); font-weight:600;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
                        <circle cx="12" cy="13" r="4"></circle>
                      </svg>
                      <span>Lihat Foto Pembeli</span>
                    </a>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if (!empty($rev['balasan_admin'])): ?>
                    <div style="background:#f8fafc; border-left:3px solid var(--admin-primary); padding:8px 12px; border-radius:4px; font-size:12px; color:#555;">
                      <b>Respon Anda:</b><br>
                      <?= nl2br(htmlspecialchars($rev['balasan_admin'])) ?>
                    </div>
                  <?php else: ?>
                    <span style="font-size:12px; color:#888; font-style:italic;">Belum dibalas</span>
                  <?php endif; ?>
                </td>
                <td style="text-align:center;">
                  <button type="button" class="btn-admin btn-admin-primary btn-admin-sm" onclick="openReplyModal(<?= $rev['id'] ?>, '<?= htmlspecialchars(addslashes($rev['balasan_admin'] ?? '')) ?>', '<?= htmlspecialchars(addslashes($rev['customer_name'])) ?>')" style="margin-bottom:4px; display:inline-flex; align-items:center; gap:5px;">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                    <span>Balas</span>
                  </button>
                  <a href="<?= BASE_URL ?>admin/ulasan.php?hapus=<?= $rev['id'] ?>" class="btn-admin btn-admin-outline btn-admin-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus ulasan ini?')" style="color:#ef4444; border-color:#fee2e2;">
                    Hapus
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Balas Ulasan -->
<div class="modal-backdrop" id="adminReplyModal">
  <div class="modal-card">
    <button type="button" class="modal-close" onclick="document.getElementById('adminReplyModal').classList.remove('show')" style="display:flex; align-items:center; justify-content:center;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
    <h3 class="modal-title">Tanggapi Ulasan Pelanggan</h3>
    <p style="font-size:13px; color:#666; margin-bottom:16px;">
      Balasan ini akan tampil di bawah ulasan <b id="replyCustomerName">Pelanggan</b> pada halaman produk toko.
    </p>

    <form method="POST" action="">
      <input type="hidden" name="balas_ulasan" value="1">
      <input type="hidden" name="id_ulasan" id="replyReviewId" value="">

      <div class="form-group">
        <label class="form-label">Teks Balasan Resmi Admin SOREN:</label>
        <textarea name="balasan_admin" id="replyContent" rows="4" class="form-control" placeholder="Contoh: Terima kasih banyak Kak atas ulasan manisnya! Senang sekali Kakak menyukai bahannya 💕" required></textarea>
      </div>

      <button type="submit" class="btn-admin btn-admin-primary" style="width:100%; justify-content:center; padding:10px;">
        Simpan Balasan Resmi
      </button>
    </form>
  </div>
</div>

<script>
  function openReplyModal(id, currentReply, customerName) {
    document.getElementById('replyReviewId').value = id;
    document.getElementById('replyContent').value = currentReply;
    document.getElementById('replyCustomerName').textContent = customerName;
    document.getElementById('adminReplyModal').classList.add('show');
  }
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
