<?php
// admin/toko.php - Store Profile & Social Media Settings
$admin_title = 'Pengaturan Profil Toko & Kontak';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$success = '';
$error = '';

// Handle Update Toko
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan_toko'])) {
    $nama = clean_input($_POST['nama_toko'] ?? '');
    $alamat = clean_input($_POST['alamat'] ?? '');
    $link_maps = clean_input($_POST['link_maps'] ?? '');
    $jam_buka = clean_input($_POST['jam_buka'] ?? '09:00:00');
    $jam_tutup = clean_input($_POST['jam_tutup'] ?? '21:00:00');
    $hari = clean_input($_POST['hari_operasional'] ?? 'Senin - Minggu');

    $stmt = $pdo->prepare("
        UPDATE toko 
        SET nama_toko = ?, alamat = ?, link_maps = ?, jam_buka = ?, jam_tutup = ?, hari_operasional = ?
        WHERE id = 1
    ");
    if ($stmt->execute([$nama, $alamat, $link_maps, $jam_buka, $jam_tutup, $hari])) {
        $success = 'Informasi toko berhasil diperbarui!';
    } else {
        $error = 'Gagal menyimpan perubahan.';
    }
}

// Handle Update Sosmed
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan_sosmed'])) {
    foreach ($_POST['sosmed'] as $id_sm => $val) {
        $username = clean_input($val['username'] ?? '');
        $link = clean_input($val['link'] ?? '');
        $nomor = clean_input($val['nomor'] ?? '');
        $up = $pdo->prepare("UPDATE kontak_sosmed SET username = ?, link = ?, nomor = ? WHERE id = ?");
        $up->execute([$username, $link, $nomor, (int)$id_sm]);
    }
    $success = 'Kontak & sosial media toko berhasil diperbarui!';
}

$toko = get_toko_info($pdo);
$sosmed = get_kontak_sosmed($pdo);

include __DIR__ . '/includes/header.php';
?>

<?php if (!empty($success)): ?>
  <div style="background:#dcfce7; color:#166534; padding:12px 20px; border-radius:6px; margin-bottom:20px; font-size:13px;">
    ✓ <?= htmlspecialchars($success) ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: flex-start;">
  <!-- Form Profil Toko -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Informasi Operasional dan Toko Offline</h3>
    </div>
    <div class="card-body">
      <form method="POST" action="">
        <input type="hidden" name="simpan_toko" value="1">

        <div class="form-group">
          <label class="form-label">Nama Brand / Toko</label>
          <input type="text" name="nama_toko" class="form-control" value="<?= htmlspecialchars($toko['nama_toko']) ?>" required>
        </div>

        <div class="form-group">
          <label class="form-label">Alamat Butik Fisik</label>
          <textarea name="alamat" rows="3" class="form-control" required><?= htmlspecialchars($toko['alamat']) ?></textarea>
        </div>

        <div class="form-group">
          <label class="form-label">Tautan Google Maps</label>
          <input type="url" name="link_maps" class="form-control" value="<?= htmlspecialchars($toko['link_maps'] ?? '') ?>">
        </div>

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 14px;">
          <div class="form-group">
            <label class="form-label">Jam Buka</label>
            <input type="time" name="jam_buka" class="form-control" value="<?= substr($toko['jam_buka'], 0, 5) ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Jam Tutup</label>
            <input type="time" name="jam_tutup" class="form-control" value="<?= substr($toko['jam_tutup'], 0, 5) ?>">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Hari Operasional</label>
          <input type="text" name="hari_operasional" class="form-control" value="<?= htmlspecialchars($toko['hari_operasional'] ?? '') ?>" placeholder="Contoh: Setiap Hari (Senin - Minggu)">
        </div>

        <button type="submit" class="btn-admin btn-admin-primary" style="margin-top:10px;">
          Simpan Profil Toko
        </button>
      </form>
    </div>
  </div>

  <!-- Form Kontak & Sosmed -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Saluran Media Sosial & Kontak</h3>
    </div>
    <div class="card-body">
      <form method="POST" action="">
        <input type="hidden" name="simpan_sosmed" value="1">

        <?php foreach ($sosmed as $sm): ?>
          <div style="background:#f8fafc; padding:14px; border-radius:8px; margin-bottom:14px; border:1px solid var(--admin-border);">
            <b style="font-size:13.5px; display:block; margin-bottom:8px;"><?= htmlspecialchars($sm['nama_platform']) ?></b>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size:12px;">
              <div>
                <label style="display:block; margin-bottom:3px; color:#666;">Username / Nomor:</label>
                <input type="text" name="sosmed[<?= $sm['id'] ?>][username]" class="form-control" style="font-size:12px; padding:6px 10px;" value="<?= htmlspecialchars($sm['username'] ?: $sm['nomor']) ?>">
              </div>
              <div>
                <label style="display:block; margin-bottom:3px; color:#666;">Tautan / Link URL:</label>
                <input type="text" name="sosmed[<?= $sm['id'] ?>][link]" class="form-control" style="font-size:12px; padding:6px 10px;" value="<?= htmlspecialchars($sm['link'] ?? '') ?>">
              </div>
            </div>
          </div>
        <?php endforeach; ?>

        <button type="submit" class="btn-admin btn-admin-primary" style="margin-top:10px;">
          Simpan Perubahan Kontak
        </button>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
