<?php
// kontak.php - Store Contact & Feedback (Kritik Saran) Page
$page_title = 'Hubungi Kami & Kritik Saran';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$toko = get_toko_info($pdo);
$sosmed = get_kontak_sosmed($pdo);

$msg_success = '';
$msg_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isi = clean_input($_POST['isi'] ?? '');
    if (empty($isi)) {
        $msg_error = 'Pesan kritik & saran tidak boleh kosong.';
    } else {
        $user_id = is_logged_in() ? $_SESSION['user_id'] : 2; // Default to user demo id if guest
        $ins = $pdo->prepare("INSERT INTO kritik_saran (id_user, isi, tanggal, status) VALUES (?, ?, NOW(), 'Belum Dibaca')");
        if ($ins->execute([$user_id, $isi])) {
            $msg_success = 'Terima kasih banyak atas kritik dan saran yang kamu sampaikan! Masukan kamu sangat berharga untuk kemajuan SOREN.ID 💕';
        } else {
            $msg_error = 'Terjadi kesalahan sistem, silakan coba lagi.';
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding-top: 30px; padding-bottom: 70px;">
  <div class="breadcrumb">
    <a href="<?= BASE_URL ?>">Beranda</a>
    <span>/</span>
    <span style="color:var(--primary-dark); font-weight:600;">Kontak Kami</span>
  </div>

  <div style="text-align: center; margin-bottom: 36px;">
    <div class="section-subtitle">Customer Care</div>
    <h1 style="font-family: var(--font-serif); font-size: 36px; margin-bottom: 10px;">Hubungi Tim SOREN.ID</h1>
    <p style="font-size: 14.5px; color: var(--text-muted); max-width: 600px; margin: 0 auto;">
      Kami selalu siap mendengarkan pertanyaan, konsultasi ukuran outfit, maupun masukan berharga dari kamu.
    </p>
  </div>

  <?php if (!empty($msg_success)): ?>
    <div style="background:#e8f5e9; color:#2e7d32; padding:14px 20px; border-radius:var(--radius-sm); margin-bottom:24px; font-size:14px; text-align:center;">
      ✓ <?= htmlspecialchars($msg_success) ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($msg_error)): ?>
    <div style="background:#fde8e8; color:#c81e1e; padding:14px 20px; border-radius:var(--radius-sm); margin-bottom:24px; font-size:14px; text-align:center;">
      ⚠️ <?= htmlspecialchars($msg_error) ?>
    </div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: flex-start;">
    <!-- Store Info Card -->
    <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 32px; box-shadow:var(--shadow-sm);">
      <h3 style="font-family: var(--font-serif); font-size: 22px; margin-bottom: 18px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        📍 Butik & Kantor Pusat
      </h3>

      <div style="display:flex; flex-direction:column; gap:16px; font-size:14px; line-height:1.7;">
        <div>
          <b style="color:var(--text-dark);">Nama Toko:</b><br>
          <?= htmlspecialchars($toko['nama_toko']) ?>
        </div>
        <div>
          <b style="color:var(--text-dark);">Alamat Lengkap:</b><br>
          <?= nl2br(htmlspecialchars($toko['alamat'])) ?>
        </div>
        <div>
          <b style="color:var(--text-dark);">Jam Operasional:</b><br>
          <?= substr($toko['jam_buka'], 0, 5) ?> - <?= substr($toko['jam_tutup'], 0, 5) ?> WIB (<?= htmlspecialchars($toko['hari_operasional']) ?>)
        </div>
      </div>

      <h3 style="font-family: var(--font-serif); font-size: 20px; margin: 28px 0 16px 0; border-bottom:1px solid var(--border-color); padding-bottom:10px;">
        📱 Saluran Komunikasi Resmi
      </h3>

      <div style="display:flex; flex-direction:column; gap:10px;">
        <?php foreach ($sosmed as $sm): ?>
          <a href="<?= htmlspecialchars($sm['link'] ?? '#') ?>" target="_blank" style="display:flex; align-items:center; justify-content:space-between; padding:10px 14px; border:1px solid var(--border-light); border-radius:var(--radius-sm); background:var(--bg-main); transition:var(--transition);">
            <span style="font-weight:600; color:var(--text-dark);"><?= htmlspecialchars($sm['nama_platform']) ?></span>
            <span style="font-size:12.5px; color:var(--primary); font-weight:600;"><?= htmlspecialchars($sm['username'] ?: $sm['nomor']) ?> →</span>
          </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Kritik & Saran Form -->
    <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 32px; box-shadow:var(--shadow-sm);" id="kritik">
      <h3 style="font-family: var(--font-serif); font-size: 22px; margin-bottom: 12px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        💌 Kotak Kritik & Saran
      </h3>
      <p style="font-size:13.5px; color:var(--text-muted); margin-bottom: 20px;">
        Punya ide warna baru, masukan pelayanan, atau saran produk? Tuliskan langsung ke tim manajemen kami.
      </p>

      <form method="POST" action="">
        <div class="form-group">
          <label class="form-label">Kritik & Saran Kamu:</label>
          <textarea name="isi" rows="6" class="form-control" placeholder="Tuliskan pengalaman atau saran kamu untuk SOREN.ID..." required></textarea>
        </div>

        <button type="submit" class="btn btn-primary btn-block" style="margin-top:16px;">
          Kirim Kritik & Saran
        </button>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
