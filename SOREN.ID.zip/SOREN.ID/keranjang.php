<?php
// keranjang.php - Full Cart Page for SOREN.ID
$page_title = 'Keranjang Belanja';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$items = get_cart_items($pdo);
$subtotal = 0;
foreach ($items as $it) {
    $subtotal += ($it['harga'] * $it['jumlah']);
}

// Gratis ongkir jika belanja >= 150rb
$ongkir = ($subtotal >= 150000 || $subtotal == 0) ? 0 : 15000;
$grand_total = $subtotal + $ongkir;

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding-top: 30px; padding-bottom: 70px;">
  <div class="breadcrumb">
    <a href="<?= BASE_URL ?>">Beranda</a>
    <span>/</span>
    <span style="color:var(--primary-dark); font-weight:600;">Keranjang Belanja</span>
  </div>

  <h1 style="font-family: var(--font-serif); font-size: 32px; margin-bottom: 24px;">Keranjang Belanja Kamu</h1>

  <?php if (empty($items)): ?>
    <div style="background:#fff; border-radius:var(--radius-md); padding:60px 20px; text-align:center; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
      <div style="font-size: 56px; margin-bottom: 16px;">🛍️</div>
      <h3 style="font-family: var(--font-serif); font-size: 24px; margin-bottom: 8px;">Keranjang Masih Kosong</h3>
      <p style="color:var(--text-muted); font-size:14px; margin-bottom: 24px;">Belum ada produk modest wear yang ditambahkan ke keranjang belanja kamu.</p>
      <a href="<?= BASE_URL ?>katalog.php" class="btn btn-primary">Mulai Belanja Sekarang</a>
    </div>
  <?php else: ?>
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 36px; align-items: flex-start;">
      <!-- Item List -->
      <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 24px; box-shadow:var(--shadow-sm);">
        <table class="table">
          <thead>
            <tr>
              <th>Produk</th>
              <th style="text-align: center;">Jumlah</th>
              <th style="text-align: right;">Subtotal</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $it): 
              $item_sub = $it['harga'] * $it['jumlah'];
            ?>
              <tr>
                <td>
                  <div style="display: flex; gap: 16px; align-items: center;">
                    <div style="width: 70px; height: 70px; border-radius:var(--radius-sm); overflow:hidden; background:#f7f3f1; flex-shrink:0;">
                      <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($it['gambar']) ?>" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="<?= htmlspecialchars($it['nama_produk']) ?>" style="width:100%; height:100%; object-fit:cover;">
                    </div>
                    <div>
                      <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $it['produk_id'] ?>" style="font-weight:600; color:var(--text-dark); font-size:14.5px;">
                        <?= htmlspecialchars($it['nama_produk']) ?>
                      </a>
                      <div style="font-size: 12.5px; color:var(--text-muted); margin-top:2px;">
                        Harga: <?= format_rupiah($it['harga']) ?>
                      </div>
                    </div>
                  </div>
                </td>
                <td style="text-align: center;">
                  <div class="qty-stepper" style="margin: 0 auto;">
                    <button type="button" class="qty-btn" onclick="updateCartQty(<?= $it['produk_id'] ?>, <?= $it['jumlah'] - 1 ?>)">-</button>
                    <span class="qty-input" style="display: flex; align-items: center; justify-content: center;"><?= $it['jumlah'] ?></span>
                    <button type="button" class="qty-btn" onclick="updateCartQty(<?= $it['produk_id'] ?>, <?= $it['jumlah'] + 1 ?>)">+</button>
                  </div>
                </td>
                <td style="text-align: right; font-weight:700; color:var(--primary-dark);">
                  <?= format_rupiah($item_sub) ?>
                </td>
                <td style="text-align: center;">
                  <button type="button" onclick="removeCartItem(<?= $it['produk_id'] ?>)" style="background:none; border:none; color:#c58385; cursor:pointer; font-size:16px;" title="Hapus Item">
                    ✕
                  </button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 24px;">
          <a href="<?= BASE_URL ?>katalog.php" class="btn btn-outline btn-sm">← Lanjut Belanja</a>
        </div>
      </div>

      <!-- Order Summary Card -->
      <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 24px; box-shadow:var(--shadow-sm);">
        <h3 style="font-family: var(--font-serif); font-size: 20px; margin-bottom: 20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
          Ringkasan Pesanan
        </h3>

        <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 14px;">
          <span style="color:var(--text-muted);">Total Belanja:</span>
          <span style="font-weight: 600;"><?= format_rupiah($subtotal) ?></span>
        </div>

        <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 14px;">
          <span style="color:var(--text-muted);">Estimasi Ongkos Kirim:</span>
          <?php if ($ongkir === 0): ?>
            <span style="color:var(--badge-new); font-weight:700;">GRATIS ONGKIR</span>
          <?php else: ?>
            <span style="font-weight: 600;"><?= format_rupiah($ongkir) ?></span>
          <?php endif; ?>
        </div>

        <?php if ($subtotal < 150000): ?>
          <div style="background:var(--primary-light); border-radius:var(--radius-sm); padding:10px; font-size:12px; color:var(--primary-dark); margin-bottom:16px;">
            💡 Tambah belanja <b><?= format_rupiah(150000 - $subtotal) ?></b> lagi untuk menikmati <b>Gratis Ongkir</b>!
          </div>
        <?php endif; ?>

        <div style="border-top:1px solid var(--border-color); padding-top:16px; margin-top:16px; display: flex; justify-content: space-between; font-size: 18px; font-weight: 700; color:var(--primary-dark);">
          <span>Total Tagihan:</span>
          <span><?= format_rupiah($grand_total) ?></span>
        </div>

        <a href="<?= BASE_URL ?>checkout.php" class="btn btn-primary btn-block" style="margin-top: 24px;">
          Lanjut ke Checkout
        </a>

        <div style="margin-top: 16px; text-align: center; font-size: 12px; color: var(--text-light);">
          🔒 Transaksi aman & terenkripsi
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>

<script>
  function renderCartPage() {
    location.reload();
  }
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
