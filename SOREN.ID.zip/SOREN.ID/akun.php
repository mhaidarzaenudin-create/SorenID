<?php
// akun.php - Customer Dashboard, Order History, Payment Proof Upload & Review Trigger
$page_title = 'Akun Saya & Riwayat Pesanan';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (!is_logged_in()) {
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// Handle upload bukti pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_bukti'])) {
    $pesanan_id = (int)$_POST['id_pesanan'];
    if (!empty($_FILES['bukti']) && $_FILES['bukti']['error'] === UPLOAD_ERR_OK) {
        $up = upload_image($_FILES['bukti'], __DIR__ . '/uploads/payments', 'pay');
        if ($up['success']) {
            $stmt = $pdo->prepare("
                UPDATE pembayaran 
                SET bukti_pembayaran = ?, status = 'Menunggu Konfirmasi', tanggal_pembayaran = NOW() 
                WHERE id_pesanan = ?
            ");
            $stmt->execute([$up['filename'], $pesanan_id]);
            $success_msg = 'Bukti pembayaran berhasil diunggah! Tim admin kami akan segera memverifikasinya.';
        } else {
            $error_msg = $up['message'];
        }
    } else {
        $error_msg = 'Harap pilih file foto bukti pembayaran.';
    }
}

// Ambil data user
$stmt_user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt_user->execute([$user_id]);
$user_data = $stmt_user->fetch();

// Ambil riwayat pesanan
$stmt_orders = $pdo->prepare("
    SELECT p.*, pb.metode, pb.status as status_bayar, pb.bukti_pembayaran
    FROM pesanan p
    LEFT JOIN pembayaran pb ON p.id = pb.id_pesanan
    WHERE p.id_user = ?
    ORDER BY p.id DESC
");
$stmt_orders->execute([$user_id]);
$orders = $stmt_orders->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding-top: 30px; padding-bottom: 70px;">
  <div class="breadcrumb">
    <a href="<?= BASE_URL ?>">Beranda</a>
    <span>/</span>
    <span style="color:var(--primary-dark); font-weight:600;">Akun Saya</span>
  </div>

  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; flex-wrap: wrap; gap: 16px;">
    <div>
      <h1 style="font-family: var(--font-serif); font-size: 32px; color:var(--text-dark);">
        Halo, <?= htmlspecialchars($user_data['nama']) ?> ✨
      </h1>
      <p style="color:var(--text-muted); font-size:14px;">Kelola riwayat belanja dan status pesanan kamu di sini.</p>
    </div>
    <a href="<?= BASE_URL ?>logout.php" class="btn btn-outline btn-sm">Keluar (Logout)</a>
  </div>

  <?php if (!empty($success_msg)): ?>
    <div style="background:#e8f5e9; color:#2e7d32; padding:14px; border-radius:var(--radius-sm); margin-bottom:20px; font-size:13.5px;">
      ✓ <?= htmlspecialchars($success_msg) ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($error_msg)): ?>
    <div style="background:#fde8e8; color:#c81e1e; padding:14px; border-radius:var(--radius-sm); margin-bottom:20px; font-size:13.5px;">
      ⚠️ <?= htmlspecialchars($error_msg) ?>
    </div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 2.5fr; gap: 36px; align-items: flex-start;">
    <!-- Profile Card -->
    <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 26px; box-shadow:var(--shadow-sm);">
      <h3 style="font-family: var(--font-serif); font-size: 18px; margin-bottom: 16px; border-bottom:1px solid var(--border-color); padding-bottom:10px;">
        Profil Saya
      </h3>
      <div style="font-size: 13.5px; display: flex; flex-direction: column; gap: 12px;">
        <div>
          <span style="color:var(--text-light); font-size:12px; display:block;">Nama:</span>
          <b><?= htmlspecialchars($user_data['nama']) ?></b>
        </div>
        <div>
          <span style="color:var(--text-light); font-size:12px; display:block;">Email:</span>
          <?= htmlspecialchars($user_data['email']) ?>
        </div>
        <div>
          <span style="color:var(--text-light); font-size:12px; display:block;">No. WhatsApp / HP:</span>
          <?= htmlspecialchars($user_data['no_hp'] ?: '-') ?>
        </div>
        <div>
          <span style="color:var(--text-light); font-size:12px; display:block;">Alamat Pengiriman Utama:</span>
          <?= nl2br(htmlspecialchars($user_data['alamat'] ?: 'Belum diisi')) ?>
        </div>
      </div>
    </div>

    <!-- Orders List -->
    <div>
      <h3 style="font-family: var(--font-serif); font-size: 22px; margin-bottom: 20px;">
        Riwayat Pesanan Kamu (<?= count($orders) ?>)
      </h3>

      <?php if (empty($orders)): ?>
        <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 40px 20px; text-align:center;">
          <div style="font-size: 40px; margin-bottom: 10px;">📦</div>
          <h4 style="font-family: var(--font-serif); margin-bottom: 6px;">Belum Ada Riwayat Pesanan</h4>
          <p style="color:var(--text-muted); font-size:13.5px; margin-bottom: 18px;">Yuk checkout produk favoritmu sekarang!</p>
          <a href="<?= BASE_URL ?>katalog.php" class="btn btn-primary btn-sm">Mulai Belanja</a>
        </div>
      <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 20px;">
          <?php foreach ($orders as $ord): 
            // Ambil item produk dalam pesanan ini
            $st_items = $pdo->prepare("
              SELECT dp.*, p.nama_produk, p.gambar, p.id as id_produk
              FROM detail_pesanan dp
              JOIN produk p ON dp.id_produk = p.id
              WHERE dp.id_pesanan = ?
            ");
            $st_items->execute([$ord['id']]);
            $ord_items = $st_items->fetchAll();
          ?>
            <div style="background:#fff; border-radius:var(--radius-md); border:1px solid var(--border-color); padding: 22px; box-shadow:var(--shadow-sm);">
              <!-- Order Header -->
              <div style="display: flex; justify-content: space-between; align-items: center; border-bottom:1px solid var(--border-light); padding-bottom:14px; margin-bottom: 16px; flex-wrap:wrap; gap:10px;">
                <div>
                  <span style="font-weight:700; color:var(--text-dark); font-size:15px;">#SOREN-<?= str_pad($ord['id'], 5, '0', STR_PAD_LEFT) ?></span>
                  <span style="font-size:12px; color:var(--text-light); margin-left:8px;"><?= date('d M Y, H:i', strtotime($ord['tanggal_pesanan'])) ?> WIB</span>
                </div>
                <div>
                  <?php 
                    $st_badge = 'status-pending';
                    if ($ord['status'] === 'Diproses') $st_badge = 'status-process';
                    elseif ($ord['status'] === 'Dikirim') $st_badge = 'status-shipped';
                    elseif ($ord['status'] === 'Selesai') $st_badge = 'status-completed';
                    elseif ($ord['status'] === 'Dibatalkan') $st_badge = 'status-cancelled';
                  ?>
                  <span class="status-badge <?= $st_badge ?>"><?= htmlspecialchars($ord['status']) ?></span>
                </div>
              </div>

              <!-- Order Items List -->
              <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 16px;">
                <?php foreach ($ord_items as $item): ?>
                  <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; gap: 12px; align-items: center;">
                      <div style="width: 50px; height: 50px; border-radius:var(--radius-sm); overflow:hidden; background:#f7f3f1; flex-shrink:0;">
                        <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($item['gambar']) ?>" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="<?= htmlspecialchars($item['nama_produk']) ?>" style="width:100%; height:100%; object-fit:cover;">
                      </div>
                      <div>
                        <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $item['id_produk'] ?>" style="font-size:13.5px; font-weight:600; color:var(--text-dark);">
                          <?= htmlspecialchars($item['nama_produk']) ?>
                        </a>
                        <div style="font-size:12px; color:var(--text-muted);"><?= $item['jumlah'] ?> pcs x <?= format_rupiah($item['harga']) ?></div>
                      </div>
                    </div>
                    <div>
                      <!-- JIKA PESANAN SELESAI, TAMPILKAN TOMBOL BERI ULASAN! -->
                      <?php if ($ord['status'] === 'Selesai'): ?>
                        <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $item['id_produk'] ?>#ulasanSection" class="btn btn-primary btn-sm" style="padding:4px 12px; font-size:11px;">
                          ✍️ Beri Ulasan
                        </a>
                      <?php endif; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>

              <!-- Order Footer Info -->
              <div style="display: flex; justify-content: space-between; align-items: center; border-top:1px solid var(--border-light); padding-top:14px; flex-wrap:wrap; gap:12px;">
                <div style="font-size: 13px; color:var(--text-muted);">
                  Metode: <b><?= htmlspecialchars($ord['metode'] ?: 'Transfer') ?></b> • 
                  Status Bayar: <b><?= htmlspecialchars($ord['status_bayar'] ?: 'Belum Dibayar') ?></b>
                </div>
                <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                  <?php if ($ord['status_bayar'] === 'Belum Dibayar' && stripos($ord['metode'], 'QRIS') !== false): ?>
                    <a href="<?= BASE_URL ?>pesanan-sukses.php?id=<?= $ord['id'] ?>" class="btn btn-outline btn-sm" style="font-size:11.5px; padding:5px 12px; border-color:#e1251b; color:#e1251b; border-radius:8px;">
                      📱 Buka Kode QRIS
                    </a>
                  <?php endif; ?>
                  <div style="font-size: 16px; font-weight:700; color:var(--primary-dark);">
                    Total: <?= format_rupiah($ord['total_harga']) ?>
                  </div>
                </div>
              </div>

              <!-- Form Upload Bukti Transfer jika belum dikonfirmasi -->
              <?php if ($ord['status_bayar'] === 'Belum Dibayar' || empty($ord['bukti_pembayaran'])): ?>
                <div style="margin-top: 16px; background:var(--bg-main); padding:14px; border-radius:var(--radius-sm); border:1px solid var(--border-color);">
                  <div style="font-size: 13px; font-weight:600; margin-bottom:8px; color:var(--text-dark);">
                    📸 Unggah Bukti Transfer / Pembayaran:
                  </div>
                  <form method="POST" enctype="multipart/form-data" style="display: flex; gap: 10px; align-items: center; flex-wrap:wrap;">
                    <input type="hidden" name="upload_bukti" value="1">
                    <input type="hidden" name="id_pesanan" value="<?= $ord['id'] ?>">
                    <input type="file" name="bukti" accept="image/*" class="form-control" style="font-size:12px; width:auto; flex-grow:1;" required>
                    <button type="submit" class="btn btn-primary btn-sm">Kirim Bukti</button>
                  </form>
                </div>
              <?php elseif ($ord['status_bayar'] === 'Menunggu Konfirmasi'): ?>
                <div style="margin-top: 12px; font-size: 12.5px; color:#b78103; background:#fff8e1; padding:8px 12px; border-radius:4px;">
                  ⏳ Bukti pembayaran telah diunggah dan sedang dalam proses verifikasi oleh Admin SOREN.
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
