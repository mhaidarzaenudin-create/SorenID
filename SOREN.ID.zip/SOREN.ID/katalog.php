<?php
// katalog.php - Catalog & Filter Page for SOREN.ID
$page_title = 'Katalog Produk';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$kategori_id = (int)($_GET['kategori'] ?? 0);
$sort = $_GET['sort'] ?? 'terbaru';
$search = clean_input($_GET['q'] ?? '');

$sql = "SELECT p.*, k.nama_kategori FROM produk p JOIN kategori k ON p.id_kategori = k.id WHERE 1=1";
$params = [];

if ($kategori_id > 0) {
    $sql .= " AND p.id_kategori = ?";
    $params[] = $kategori_id;
}

if (!empty($search)) {
    $sql .= " AND (p.nama_produk LIKE ? OR p.deskripsi LIKE ? OR p.warna LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

switch ($sort) {
    case 'harga_asc':
        $sql .= " ORDER BY p.harga ASC";
        break;
    case 'harga_desc':
        $sql .= " ORDER BY p.harga DESC";
        break;
    case 'nama_asc':
        $sql .= " ORDER BY p.nama_produk ASC";
        break;
    default:
        $sql .= " ORDER BY p.id DESC";
        break;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = get_categories($pdo);

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding-top: 30px; padding-bottom: 60px;">
  <!-- Breadcrumb -->
  <div class="breadcrumb">
    <a href="<?= BASE_URL ?>">Beranda</a>
    <span>/</span>
    <a href="<?= BASE_URL ?>katalog.php">Katalog</a>
    <?php if ($kategori_id > 0): 
      $active_cat = array_filter($categories, fn($c) => $c['id'] == $kategori_id);
      $cat_name = !empty($active_cat) ? reset($active_cat)['nama_kategori'] : '';
    ?>
      <span>/</span>
      <span style="color:var(--primary-dark); font-weight:600;"><?= htmlspecialchars($cat_name) ?></span>
    <?php endif; ?>
  </div>

  <!-- Header Banner Section -->
  <div style="text-align: center; margin-bottom: 36px;">
    <h1 style="font-family: var(--font-serif); font-size: 36px; margin-bottom: 8px;">
      <?= !empty($cat_name) ? htmlspecialchars($cat_name) : 'Semua Koleksi' ?>
    </h1>
    <p style="color: var(--text-muted); font-size: 14px;">
      Menampilkan <?= count($products) ?> produk pilihan berkualitas tinggi dengan kenyamanan optimal
    </p>
  </div>

  <!-- Filter & Sort Bar -->
  <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
    <!-- Category Pills -->
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <a href="<?= BASE_URL ?>katalog.php" class="filter-pill <?= $kategori_id == 0 ? 'active' : '' ?>">
        Semua (<?= array_sum(array_column($categories, 'total_produk')) ?>)
      </a>
      <?php foreach ($categories as $cat): ?>
        <a href="<?= BASE_URL ?>katalog.php?kategori=<?= $cat['id'] ?>" class="filter-pill <?= $kategori_id == $cat['id'] ? 'active' : '' ?>">
          <?= htmlspecialchars($cat['nama_kategori']) ?> (<?= $cat['total_produk'] ?>)
        </a>
      <?php endforeach; ?>
    </div>

    <!-- Sorting Dropdown -->
    <form method="GET" action="<?= BASE_URL ?>katalog.php" style="display: flex; align-items: center; gap: 10px;">
      <?php if ($kategori_id > 0): ?>
        <input type="hidden" name="kategori" value="<?= $kategori_id ?>">
      <?php endif; ?>
      <?php if (!empty($search)): ?>
        <input type="hidden" name="q" value="<?= htmlspecialchars($search) ?>">
      <?php endif; ?>
      <label for="sort" style="font-size: 13px; color: var(--text-muted);">Urutkan:</label>
      <select name="sort" id="sort" class="form-control" style="width: auto; padding: 6px 12px; font-size: 13px;" onchange="this.form.submit()">
        <option value="terbaru" <?= $sort === 'terbaru' ? 'selected' : '' ?>>Produk Terbaru</option>
        <option value="harga_asc" <?= $sort === 'harga_asc' ? 'selected' : '' ?>>Harga: Terendah ke Tertinggi</option>
        <option value="harga_desc" <?= $sort === 'harga_desc' ? 'selected' : '' ?>>Harga: Tertinggi ke Terendah</option>
        <option value="nama_asc" <?= $sort === 'nama_asc' ? 'selected' : '' ?>>Nama: A - Z</option>
      </select>
    </form>
  </div>

  <!-- Product Grid -->
  <?php if (empty($products)): ?>
    <div style="text-align: center; padding: 60px 20px;">
      <div style="font-size: 48px; margin-bottom: 12px;">🔍</div>
      <h3 style="font-family: var(--font-serif); font-size: 22px; margin-bottom: 8px;">Tidak Ada Produk yang Cocok</h3>
      <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 24px;">Silakan coba kata kunci lain atau pilih kategori yang berbeda.</p>
      <a href="<?= BASE_URL ?>katalog.php" class="btn btn-primary btn-sm">Lihat Semua Produk</a>
    </div>
  <?php else: ?>
    <div class="product-grid">
      <?php foreach ($products as $p): 
        $rating_stat = get_product_rating($pdo, $p['id']);
      ?>
        <div class="product-card">
          <div class="product-thumb">
            <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $p['id'] ?>">
              <img src="<?= !empty($p['gambar']) ? UPLOADS_URL . 'products/' . htmlspecialchars($p['gambar']) : ASSETS_URL . 'images/banners/hero-1.jpg' ?>" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="<?= htmlspecialchars($p['nama_produk']) ?>">
            </a>
            <!-- Overlay Transparan Menyatu dengan Foto Produk -->
            <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $p['id'] ?>" class="product-thumb-overlay">
              <div class="product-category"><?= htmlspecialchars($p['nama_kategori']) ?></div>
              <h3 class="product-name"><?= htmlspecialchars($p['nama_produk']) ?></h3>
              <div class="product-price">
                <span><?= format_rupiah($p['harga']) ?></span>
              </div>
            </a>
          </div>
          <div class="product-info">
            <!-- Rating Stars -->
            <div class="rating-stars">
              <span class="stars-icon">
                <?php 
                  $avg = $rating_stat['average'] ?: 5.0;
                  for ($i = 1; $i <= 5; $i++) {
                    echo $i <= round($avg) ? '★' : '☆';
                  }
                ?>
              </span>
              <span class="rating-count">(<?= $rating_stat['total'] ?: '10' ?> ulasan)</span>
            </div>

            <!-- Color Swatches -->
            <?php if (!empty($p['warna'])): 
              $colors = explode(',', $p['warna']);
            ?>
              <div class="color-swatches">
                <?php foreach (array_slice($colors, 0, 3) as $c): ?>
                  <span class="swatch-chip"><?= trim(htmlspecialchars($c)) ?></span>
                <?php endforeach; ?>
                <?php if (count($colors) > 3): ?>
                  <span class="swatch-chip">+<?= count($colors) - 3 ?></span>
                <?php endif; ?>
              </div>
            <?php endif; ?>

            <div class="product-actions">
              <button type="button" class="btn btn-outline btn-block btn-sm" onclick="addToCart(<?= $p['id'] ?>)">
                + Keranjang
              </button>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
