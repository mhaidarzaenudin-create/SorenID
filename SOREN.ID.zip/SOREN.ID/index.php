<?php
// index.php - Homepage SOREN.ID (Lozy.id Style)
$page_title = 'Beranda - Korean Women Fashion';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

// Ambil data kategori
$categories = get_categories($pdo);

// Ambil produk Best Seller
$stmt_best = $pdo->query("SELECT p.*, k.nama_kategori FROM produk p JOIN kategori k ON p.id_kategori = k.id ORDER BY p.id ASC");
$best_sellers = $stmt_best->fetchAll();

// Ambil produk New Arrivals
$stmt_new = $pdo->query("SELECT p.*, k.nama_kategori FROM produk p JOIN kategori k ON p.id_kategori = k.id ORDER BY p.id DESC LIMIT 4");
$new_arrivals = $stmt_new->fetchAll();

// Ambil iklan video dan promosi produk aktif
$video_ads = $pdo->query("
    SELECT b.*,
           p.nama_produk, p.gambar as gambar_produk, p.harga as harga_produk
    FROM banner_diskon b
    LEFT JOIN produk p ON b.id_produk = p.id
    WHERE b.aktif = 1 AND (b.tipe = 'video')
    ORDER BY b.urutan ASC, b.id ASC
")->fetchAll();

$discount_banners = $pdo->query("
  SELECT b.*, p.nama_produk AS nama_produk, p.gambar AS gambar_produk, p.harga AS harga_produk
  FROM banner_diskon b
  LEFT JOIN produk p ON b.id_produk = p.id
  WHERE b.aktif = 1 AND b.tipe = 'diskon'
  ORDER BY b.urutan ASC, b.id ASC
  LIMIT 4
")->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<?php if (!empty($video_ads)): ?>
<!-- ═══════════════════════════════════════════════════════════════════════════ -->
<!-- 1. IKLAN VIDEO (BAGIAN ATAS - VIDEO MURNI TANPA TEKS APAPUN)              -->
<!-- ═══════════════════════════════════════════════════════════════════════════ -->
<section class="video-ad-section" aria-label="Iklan Video">
  <div class="container">
    <div class="video-ad-wrapper">
      <?php foreach ($video_ads as $vi => $v):
        // Helper cek YouTube
        $yt_id = null;
        if (($v['video_tipe'] ?? '') === 'url' && !empty($v['video_url'])) {
          if (preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/|youtube\.com/shorts/)([^"&?/ ]{11})%i', $v['video_url'], $m)) {
            $yt_id = $m[1];
          }
        }
        $video_src = ($v['video_tipe'] === 'url') ? $v['video_url'] : UPLOADS_URL . 'banners/videos/' . $v['video_file'];
        $has_link  = !empty($v['link_url']);
      ?>
        <div class="video-ad-box" id="videoAdBox-<?= $vi ?>">

          <?php if (!empty($yt_id)): ?>
            <!-- YouTube Embed -->
            <div class="video-ad-iframe-box">
              <iframe class="video-ad-iframe"
                      src="https://www.youtube-nocookie.com/embed/<?= $yt_id ?>?autoplay=1&mute=1&loop=1&playlist=<?= $yt_id ?>&controls=0&showinfo=0&rel=0&modestbranding=1&playsinline=1"
                      title="Iklan Video"
                      allow="autoplay; encrypted-media; picture-in-picture"
                      loading="lazy">
              </iframe>
            </div>
          <?php else: ?>
            <?php if ($has_link): ?>
              <a href="<?= BASE_URL . htmlspecialchars($v['link_url']) ?>" class="video-ad-clickable">
            <?php endif; ?>

            <!-- HTML5 Video Player -->
            <video class="video-ad-player" id="videoAdPlayer-<?= $vi ?>"
                   autoplay
                   muted
                   <?= !empty($v['video_loop']) ? 'loop' : '' ?>
                   playsinline
                   <?= !empty($v['gambar']) ? 'poster="' . UPLOADS_URL . 'banners/' . htmlspecialchars($v['gambar']) . '"' : '' ?>>
              <source src="<?= htmlspecialchars($video_src) ?>" type="video/mp4">
            </video>

            <?php if ($has_link): ?>
              </a>
            <?php endif; ?>

            <!-- Tombol Mute — selalu DI LUAR <a> agar bisa diklik -->
            <button type="button"
                    class="video-ad-sound-btn"
                    id="videoAdSoundBtn-<?= $vi ?>"
                    data-video-id="videoAdPlayer-<?= $vi ?>"
                    aria-label="Nyalakan/matikan suara video"
                    title="Nyalakan / Matikan Suara">
              <span class="sound-icon">🔇</span>
            </button>
          <?php endif; ?>

        </div>
      <?php break; // Tampilkan video utama teratas ?>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<script>
// ── Tombol Mute/Unmute Iklan Video ──────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.video-ad-sound-btn').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      var videoId = btn.getAttribute('data-video-id');
      var video   = document.getElementById(videoId);
      if (!video) return;

      video.muted = !video.muted;

      // Pastikan video sedang berjalan (browser kadang pause saat unmute)
      if (!video.muted && video.paused) {
        video.play().catch(function () {});
      }

      var icon = btn.querySelector('.sound-icon');
      if (icon) {
        icon.textContent = video.muted ? '🔇' : '🔊';
      }

      btn.title = video.muted ? 'Nyalakan Suara' : 'Matikan Suara';
    });
  });
});
</script>

<!-- 4. Koleksi Terlaris (Best Sellers) -->
<section class="section-padding home-products-section">
  <div class="container">
    <div class="section-header">
      <div class="section-subtitle">Paling Dicintai Pelanggan</div>
      <h2 class="section-title">Best Seller Series</h2>
    </div>

    <div class="product-grid">
      <?php foreach ($best_sellers as $p): 
        $rating_stat = get_product_rating($pdo, $p['id']);
      ?>
        <div class="product-card">
          <div class="product-thumb">
            <span class="product-badges">
              <span class="badge badge-primary">BEST SELLER</span>
            </span>
            <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $p['id'] ?>">
              <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($p['gambar']) ?>" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="<?= htmlspecialchars($p['nama_produk']) ?>">
            </a>
            <!-- Overlay Transparan Menyatu dengan Foto Produk -->
            <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $p['id'] ?>" class="product-thumb-overlay">
              <div class="product-category"><?= htmlspecialchars($p['nama_kategori']) ?></div>
              <h3 class="product-name"><?= htmlspecialchars($p['nama_produk']) ?></h3>
              <div class="product-price">
                <span><?= format_rupiah($p['harga']) ?></span>
                <span class="original-price"><?= format_rupiah($p['harga'] * 1.25) ?></span>
              </div>
            </a>
          </div>
          <div class="product-info">
            <!-- Rating Stars -->
            <div class="rating-stars">
              <span class="stars-icon">
                <?php 
                  $avg = $rating_stat['average'] ?: 5.0;
                  for ($i = 1; $i <= 5; $i++) {
                    echo $i <= round($avg) ? '★' : '☆';
                  }
                ?>
              </span>
              <span class="rating-count">(<?= $rating_stat['total'] ?: '12' ?> ulasan)</span>
            </div>

            <!-- Color Swatches -->
            <?php if (!empty($p['warna'])): 
              $colors = explode(',', $p['warna']);
            ?>
              <div class="color-swatches">
                <?php foreach (array_slice($colors, 0, 3) as $c): ?>
                  <span class="swatch-chip"><?= trim(htmlspecialchars($c)) ?></span>
                <?php endforeach; ?>
                <?php if (count($colors) > 3): ?>
                  <span class="swatch-chip">+<?= count($colors) - 3 ?></span>
                <?php endif; ?>
              </div>
            <?php endif; ?>

            <div class="product-actions">
              <button type="button" class="btn btn-outline btn-block btn-sm" onclick="addToCart(<?= $p['id'] ?>)">
                + Keranjang
              </button>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>

<?php if (!empty($discount_banners)): ?>
<section class="section-padding discount-banner-section">
  <div class="container">
    <div class="section-header">
      <div class="section-subtitle">Penawaran Pilihan</div>
      <h2 class="section-title">Promo Berlangsung</h2>
    </div>

    <div class="discount-banner-list">
      <?php foreach ($discount_banners as $ad):
        $banner_path = !empty($ad['gambar']) ? __DIR__ . '/uploads/banners/' . basename($ad['gambar']) : '';
        if ($banner_path && is_file($banner_path)) {
          $ad_image = UPLOADS_URL . 'banners/' . rawurlencode(basename($ad['gambar']));
        } elseif (!empty($ad['gambar_produk'])) {
          $ad_image = UPLOADS_URL . 'products/' . rawurlencode($ad['gambar_produk']);
        } else {
          $ad_image = ASSETS_URL . 'images/banners/hero-1.jpg';
        }

        $ad_href = !empty($ad['link_url'])
          ? (preg_match('/^https?:\/\//i', $ad['link_url']) ? $ad['link_url'] : BASE_URL . ltrim($ad['link_url'], '/'))
          : (!empty($ad['id_produk']) ? BASE_URL . 'produk-detail.php?id=' . (int)$ad['id_produk'] : BASE_URL . 'katalog.php');
        $ad_background = preg_match('/^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/', $ad['warna_bg'] ?? '')
          ? $ad['warna_bg']
          : '#fbeee6';
        $ad_original_price = $ad['harga_asli'] ?: ($ad['harga_produk'] ?? null);
        $ad_discount_price = $ad['harga_diskon'] ?? null;
      ?>
        <article class="discount-banner" style="--promo-background: <?= htmlspecialchars($ad_background, ENT_QUOTES, 'UTF-8') ?>">
          <a class="discount-banner-visual" href="<?= htmlspecialchars($ad_href, ENT_QUOTES, 'UTF-8') ?>" tabindex="-1" aria-hidden="true">
            <img src="<?= htmlspecialchars($ad_image, ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy">
          </a>
          <div class="discount-banner-copy">
            <?php if (!empty($ad['label_diskon'])): ?>
              <span class="discount-banner-label"><?= htmlspecialchars($ad['label_diskon']) ?></span>
            <?php endif; ?>
            <h3><?= htmlspecialchars($ad['judul']) ?></h3>
            <?php if (!empty($ad['subjudul'])): ?>
              <p><?= htmlspecialchars($ad['subjudul']) ?></p>
            <?php elseif (!empty($ad['nama_produk'])): ?>
              <p><?= htmlspecialchars($ad['nama_produk']) ?></p>
            <?php endif; ?>
            <?php if ($ad_discount_price || $ad_original_price): ?>
              <div class="discount-banner-prices">
                <?php if ($ad_discount_price): ?>
                  <span class="discount-banner-price"><?= format_rupiah($ad_discount_price) ?></span>
                <?php endif; ?>
                <?php if ($ad_original_price && $ad_discount_price): ?>
                  <span class="discount-banner-price-original"><?= format_rupiah($ad_original_price) ?></span>
                <?php elseif ($ad_original_price): ?>
                  <span class="discount-banner-price"><?= format_rupiah($ad_original_price) ?></span>
                <?php endif; ?>
              </div>
            <?php endif; ?>
            <a class="discount-banner-button" href="<?= htmlspecialchars($ad_href, ENT_QUOTES, 'UTF-8') ?>">
              <?= htmlspecialchars($ad['teks_tombol'] ?: 'Lihat Penawaran') ?>
            </a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- 5. Koleksi Terbaru (New Arrivals) -->
<section class="section-padding new-arrivals-section">
  <div class="container">
    <div class="section-header">
      <div class="section-subtitle">Baru Tiba Minggu Ini</div>
      <h2 class="section-title">New Arrivals</h2>
    </div>

    <div class="product-grid">
      <?php foreach ($new_arrivals as $p): 
        $rating_stat = get_product_rating($pdo, $p['id']);
      ?>
        <div class="product-card">
          <div class="product-thumb">
            <span class="product-badges">
              <span class="badge badge-new">NEW</span>
            </span>
            <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $p['id'] ?>">
              <img src="<?= UPLOADS_URL ?>products/<?= htmlspecialchars($p['gambar']) ?>" onerror="this.src='assets/images/banners/hero-1.jpg'" alt="<?= htmlspecialchars($p['nama_produk']) ?>">
            </a>
            <!-- Overlay Transparan Menyatu dengan Foto Produk -->
            <a href="<?= BASE_URL ?>produk-detail.php?id=<?= $p['id'] ?>" class="product-thumb-overlay">
              <div class="product-category"><?= htmlspecialchars($p['nama_kategori']) ?></div>
              <h3 class="product-name"><?= htmlspecialchars($p['nama_produk']) ?></h3>
              <div class="product-price">
                <span><?= format_rupiah($p['harga']) ?></span>
              </div>
            </a>
          </div>
          <div class="product-info">
            <div class="rating-stars">
              <span class="stars-icon">★★★★★</span>
              <span class="rating-count">(<?= $rating_stat['total'] ?: '8' ?> ulasan)</span>
            </div>

            <div class="product-actions">
              <button type="button" class="btn btn-outline btn-block btn-sm" onclick="addToCart(<?= $p['id'] ?>)">
                + Keranjang
              </button>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Jaminan Berbelanja (Features Bar) -->
<section class="features-bar">
  <div class="container">
    <div class="features-grid">
      <div class="feature-item">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            <path d="m9 12 2 2 4-4"/>
          </svg>
        </div>
        <div class="feature-text">
          <h4>100% Produk Original</h4>
          <p>Kualitas bahan premium terpilih</p>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/>
            <path d="M15 18H9"/>
            <path d="M19 18h2a1 1 0 0 0 1-1v-5l-3-4h-5v10z"/>
            <circle cx="7" cy="18" r="2"/>
            <circle cx="17" cy="18" r="2"/>
          </svg>
        </div>
        <div class="feature-text">
          <h4>Pengiriman Cepat</h4>
          <p>Pesanan dikirim di hari yang sama</p>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
          </svg>
        </div>
        <div class="feature-text">
          <h4>Garansi Tukar Size</h4>
          <p>Bebas retur jika ukuran tidak sesuai</p>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20 12 20 22 4 22 4 12"/>
            <rect x="2" y="7" width="20" height="5"/>
            <line x1="12" y1="22" x2="12" y2="7"/>
            <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
            <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
          </svg>
        </div>
        <div class="feature-text">
          <h4>Kemasan Eksklusif</h4>
          <p>Hardbox wangi & greeting card</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
