<?php
// includes/footer.php - Footer component for SOREN.ID
require_once __DIR__ . '/functions.php';
$toko = get_toko_info($pdo);
$sosmed = get_kontak_sosmed($pdo);
?>
  <!-- Footer (Lozy.id Style) -->
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        <!-- Brand Info -->
        <div class="footer-brand">
          <h2>SOREN.</h2>
          <p>
            Toko baju wanita bergaya Korean style dengan pilihan atasan, bawahan, dan one set yang nyaman dipakai, mudah disusun, dan tetap tampil chic untuk aktivitas harian.
          </p>
          <div style="font-size: 13px; color: var(--text-muted); line-height: 1.7;">
            <div style="display:flex; align-items:flex-start; gap:8px; margin-bottom:6px;">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--primary); margin-top:3px; flex-shrink:0;">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
              </svg>
              <div>
                <b style="color:var(--text-dark);">Butik Offline:</b><br>
                <?= htmlspecialchars($toko['alamat']) ?>
              </div>
            </div>
            <div style="display:flex; align-items:center; gap:8px;">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--primary); flex-shrink:0;">
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
              </svg>
              <div>
                <b style="color:var(--text-dark);">Jam Buka:</b> <?= substr($toko['jam_buka'], 0, 5) ?> - <?= substr($toko['jam_tutup'], 0, 5) ?> WIB (<?= htmlspecialchars($toko['hari_operasional']) ?>)
              </div>
            </div>
          </div>

          <div class="social-links">
            <?php foreach ($sosmed as $sm): ?>
              <a href="<?= htmlspecialchars($sm['link'] ?? '#') ?>" target="_blank" class="social-icon" title="<?= htmlspecialchars($sm['nama_platform']) ?>">
                <?= get_platform_svg($sm['nama_platform']) ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Links Koleksi -->
        <div>
          <h4 class="footer-title">Koleksi</h4>
          <ul class="footer-links">
            <?php foreach (array_slice($categories, 0, 3) as $cat): ?>
              <li><a href="<?= BASE_URL ?>katalog.php?kategori=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['nama_kategori']) ?></a></li>
            <?php endforeach; ?>
          </ul>
        </div>

        <!-- Links Bantuan -->
        <div>
          <h4 class="footer-title">Bantuan</h4>
          <ul class="footer-links">
            <li><a href="<?= BASE_URL ?>akun.php">Cek Status Pesanan</a></li>
            <li><a href="<?= BASE_URL ?>tentang-kami.php">Tentang SOREN</a></li>
            <li><a href="<?= BASE_URL ?>kontak.php">Hubungi Kami</a></li>
            <li><a href="<?= BASE_URL ?>kontak.php#kritik">Kritik & Saran</a></li>
            <li><a href="<?= BASE_URL ?>admin/login.php" style="color:var(--text-light); font-size:11px;">Portal Admin</a></li>
          </ul>
        </div>

        <!-- Newsletter & Pembayaran -->
        <div>
          <h4 class="footer-title">Tetap Terhubung</h4>
          <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 12px;">
            Dapatkan inspirasi styling modest wear dan penawaran eksklusif langsung ke email kamu.
          </p>
          <form onsubmit="event.preventDefault(); showToast('🎉 Terima kasih telah bergabung dengan Soren Club!'); this.reset();" style="display:flex; gap:6px; margin-bottom:18px;">
            <input type="email" placeholder="Alamat email kamu..." class="chat-input" style="font-size:12px; padding:6px 14px;" required>
            <button type="submit" class="btn btn-primary btn-sm" style="padding:6px 14px; font-size:11px;">Gabung</button>
          </form>

          <div style="font-size: 11.5px; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); margin-bottom: 6px;">Metode Pembayaran Resmi:</div>
          <div style="display:flex; gap:8px; font-size: 20px; align-items:center;">
            <span title="Bank BCA" style="background:rgba(255,255,255,0.8); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); padding:3px 9px; border-radius:5px; font-size:11.5px; font-weight:700; border:1px solid rgba(255,255,255,0.65); box-shadow:0 2px 6px rgba(0,0,0,0.06); color:#2e1d17;">BCA</span>
            <span title="Bank Mandiri" style="background:rgba(255,255,255,0.8); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); padding:3px 9px; border-radius:5px; font-size:11.5px; font-weight:700; border:1px solid rgba(255,255,255,0.65); box-shadow:0 2px 6px rgba(0,0,0,0.06); color:#2e1d17;">Mandiri</span>
            <span title="QRIS" style="background:rgba(255,255,255,0.8); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); padding:3px 9px; border-radius:5px; font-size:11.5px; font-weight:700; border:1px solid rgba(255,255,255,0.65); box-shadow:0 2px 6px rgba(0,0,0,0.06); color:#2e1d17;">QRIS</span>
            <span title="Cash on Delivery" style="background:rgba(255,255,255,0.8); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); padding:3px 9px; border-radius:5px; font-size:11.5px; font-weight:700; border:1px solid rgba(255,255,255,0.65); box-shadow:0 2px 6px rgba(0,0,0,0.06); color:#2e1d17;">COD</span>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> SOREN.ID (Korean Women Fashion). Hak Cipta Dilindungi.</p>
      </div>
    </div>
  </footer>

  <!-- Include Customer Live Chat Widget -->
  <?php include __DIR__ . '/chat-widget.php'; ?>

  <?php
  // Ambil produk nyata untuk notifikasi live sales di pojok kiri bawah
  $toast_products = [];
  try {
      $stmt_toast_prod = $pdo->query("SELECT id, nama_produk, harga, gambar FROM produk ORDER BY id DESC LIMIT 15");
      while ($tp = $stmt_toast_prod->fetch(PDO::FETCH_ASSOC)) {
          $decoded_name = html_entity_decode($tp['nama_produk'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
          $decoded_name = html_entity_decode($decoded_name, ENT_QUOTES | ENT_HTML5, 'UTF-8');
          $toast_products[] = [
              'id'     => (int)$tp['id'],
              'nama'   => $decoded_name,
              'harga'  => (float)$tp['harga'],
              'gambar' => !empty($tp['gambar']) ? UPLOADS_URL . 'products/' . htmlspecialchars($tp['gambar']) : ''
          ];
      }
  } catch (Exception $e) {
      $toast_products = [];
  }
  ?>
  <script>
    window.SOREN_PRODUCTS = <?= json_encode($toast_products, JSON_UNESCAPED_UNICODE) ?>;
  </script>

  <!-- Scripts -->
  <script src="<?= ASSETS_URL ?>js/main.js?v=<?= filemtime(__DIR__ . '/../assets/js/main.js') ?>"></script>
  <script src="<?= ASSETS_URL ?>js/chat.js"></script>

  <script>
    // Toggle Mobile Menu
    const mobileToggle = document.getElementById('mobileToggle');
    const navMenu = document.getElementById('navMenu');
    if (mobileToggle && navMenu) {
      mobileToggle.addEventListener('click', () => {
        if (navMenu.style.display === 'flex') {
          navMenu.style.display = 'none';
        } else {
          navMenu.style.display = 'flex';
          navMenu.style.flexDirection = 'column';
          navMenu.style.position = 'absolute';
          navMenu.style.top = '100%';
          navMenu.style.left = '0';
          navMenu.style.right = '0';
          navMenu.style.background = '#fff';
          navMenu.style.padding = '20px';
          navMenu.style.boxShadow = '0 10px 20px rgba(0,0,0,0.1)';
        }
      });
    }
  </script>
</body>
</html>
