<?php
// includes/functions.php - Helper utility functions untuk SOREN.ID

require_once __DIR__ . '/../config/database.php';

function format_rupiah($angka) {
    return 'Rp ' . number_format((float)$angka, 0, ',', '.');
}

function clean_input($data) {
    return htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
}

function verify_password($password, $stored_hash) {
    if ($stored_hash === null || $stored_hash === '') {
        return false;
    }

    if (is_string($password) && is_string($stored_hash) && password_verify($password, $stored_hash)) {
        return true;
    }

    return hash_equals((string)$stored_hash, (string)$password);
}

function is_logged_in() {
    return !empty($_SESSION['user_id']) && ($_SESSION['user_role'] ?? '') === 'user';
}

function is_admin() {
    return !empty($_SESSION['admin_id']) || (!empty($_SESSION['user_id']) && ($_SESSION['user_role'] ?? '') === 'admin');
}

function current_user() {
    if (!empty($_SESSION['user_id'])) {
        return [
            'id' => $_SESSION['user_id'],
            'nama' => $_SESSION['user_name'] ?? 'Pelanggan',
            'email' => $_SESSION['user_email'] ?? '',
            'role' => $_SESSION['user_role'] ?? 'user'
        ];
    }
    return null;
}

function set_flash($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash($type) {
    if (!empty($_SESSION['flash'][$type])) {
        $msg = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $msg;
    }
    return null;
}

// Menghitung jumlah item di keranjang (dukungan database jika login, atau session jika guest)
function get_cart_count($pdo) {
    if (is_logged_in()) {
        $stmt = $pdo->prepare("SELECT SUM(jumlah) as total FROM keranjang WHERE id_user = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $res = $stmt->fetch();
        return (int)($res['total'] ?? 0);
    } else {
        if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
            return 0;
        }
        $total = 0;
        foreach ($_SESSION['cart'] as $item) {
            $total += (int)($item['jumlah'] ?? 0);
        }
        return $total;
    }
}

// Mendapatkan item keranjang saat ini
function get_cart_items($pdo) {
    $items = [];
    if (is_logged_in()) {
        $stmt = $pdo->prepare("
            SELECT k.id as keranjang_id, k.jumlah, p.id as produk_id, p.nama_produk, p.harga, p.gambar, p.stok, p.warna, p.ukuran
            FROM keranjang k
            JOIN produk p ON k.id_produk = p.id
            WHERE k.id_user = ?
            ORDER BY k.id DESC
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $items = $stmt->fetchAll();
    } else {
        if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            $ids = array_keys($_SESSION['cart']);
            if (!empty($ids)) {
                $inQuery = implode(',', array_fill(0, count($ids), '?'));
                $stmt = $pdo->prepare("SELECT id as produk_id, nama_produk, harga, gambar, stok, warna, ukuran FROM produk WHERE id IN ($inQuery)");
                $stmt->execute($ids);
                $products = $stmt->fetchAll();
                foreach ($products as $p) {
                    $pid = $p['produk_id'];
                    $qty = $_SESSION['cart'][$pid]['jumlah'] ?? 1;
                    $p['keranjang_id'] = 'session_' . $pid;
                    $p['jumlah'] = $qty;
                    $items[] = $p;
                }
            }
        }
    }
    return $items;
}

// Mendapatkan informasi toko
function get_toko_info($pdo) {
    static $toko = null;
    if ($toko === null) {
        $stmt = $pdo->query("SELECT * FROM toko LIMIT 1");
        $toko = $stmt->fetch() ?: [
            'nama_toko' => 'SOREN.ID',
            'alamat' => 'Bandung, Jawa Barat',
            'link_maps' => '#',
            'jam_buka' => '09:00',
            'jam_tutup' => '21:00',
            'hari_operasional' => 'Senin - Minggu'
        ];
    }
    return $toko;
}

// Mendapatkan kontak sosial media
function get_kontak_sosmed($pdo) {
    static $sosmed = null;
    if ($sosmed === null) {
        $stmt = $pdo->query("SELECT * FROM kontak_sosmed");
        $sosmed = $stmt->fetchAll() ?: [];
    }
    return $sosmed;
}

// Mendapatkan kategori aktif
function get_categories($pdo) {
    static $cats = null;
    if ($cats === null) {
        $stmt = $pdo->query("SELECT k.*, COUNT(p.id) as total_produk FROM kategori k LEFT JOIN produk p ON k.id = p.id_kategori GROUP BY k.id ORDER BY k.id ASC");
        $cats = $stmt->fetchAll() ?: [];
    }
    return $cats;
}

// Menghitung statistik ulasan produk
function get_product_rating($pdo, $product_id) {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_review,
            COALESCE(AVG(rating), 0) as avg_rating,
            SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as star_5,
            SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as star_4,
            SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as star_3,
            SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as star_2,
            SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as star_1
        FROM ulasan_produk
        WHERE id_produk = ?
    ");
    $stmt->execute([$product_id]);
    $res = $stmt->fetch();
    return [
        'total' => (int)($res['total_review'] ?? 0),
        'average' => round((float)($res['avg_rating'] ?? 0), 1),
        'star_5' => (int)($res['star_5'] ?? 0),
        'star_4' => (int)($res['star_4'] ?? 0),
        'star_3' => (int)($res['star_3'] ?? 0),
        'star_2' => (int)($res['star_2'] ?? 0),
        'star_1' => (int)($res['star_1'] ?? 0),
    ];
}

// Helper upload gambar yang aman
function upload_image($file, $target_dir, $prefix = 'img') {
    if (empty($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'Tidak ada file yang diunggah atau terjadi kesalahan upload.'];
    }

    $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp'];
    $file_name = $file['name'];
    $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed_extensions)) {
        return ['success' => false, 'message' => 'Format file tidak didukung. Harap gunakan JPG, PNG, atau WEBP.'];
    }

    if ($file['size'] > 5 * 1024 * 1024) { // 5MB limit
        return ['success' => false, 'message' => 'Ukuran file terlalu besar, maksimal 5MB.'];
    }

    if (!is_dir($target_dir)) {
        if (!mkdir($target_dir, 0777, true) && !is_dir($target_dir)) {
            return ['success' => false, 'message' => 'Folder upload tidak dapat dibuat. Periksa izin folder project.'];
        }
    }

    if (!is_writable($target_dir)) {
        @chmod($target_dir, 0777);
    }

    if (!is_writable($target_dir)) {
        return ['success' => false, 'message' => 'Folder upload tidak dapat ditulis. Beri izin write pada folder uploads/products.'];
    }

    $new_filename = $prefix . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $destination = rtrim($target_dir, '/\\') . DIRECTORY_SEPARATOR . $new_filename;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'filename' => $new_filename];
    } else {
        return ['success' => false, 'message' => 'Gagal memindahkan file yang diunggah. Pastikan folder upload writable dan server memiliki izin menulis.'];
    }
}

/**
 * Menghasilkan ikon SVG minimalis & estetik untuk kategori pakaian SOREN
 */
function get_category_svg($cat_name) {
    $n = strtolower(trim((string)$cat_name));
    
    if (stripos($n, 'atasan') !== false || stripos($n, 'top') !== false || stripos($n, 'blouse') !== false || stripos($n, 'kaos') !== false || stripos($n, 'kemeja') !== false) {
        // Ikon Atasan / Blouse
        return '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16.5 3c-1 1.5-2.5 2-4.5 2s-3.5-.5-4.5-2L3 6l2 4 2-1v11a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9l2 1 2-4-4.5-3z"/></svg>';
    } elseif (stripos($n, 'bawahan') !== false || stripos($n, 'bottom') !== false || stripos($n, 'celana') !== false || stripos($n, 'pants') !== false || stripos($n, 'rok') !== false || stripos($n, 'skirt') !== false) {
        // Ikon Bawahan / Celana
        return '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h14l-1.5 16a1 1 0 0 1-1 .9H13l-1-8-1 8H7.5a1 1 0 0 1-1-.9L5 4z"/><line x1="12" y1="4" x2="12" y2="12"/></svg>';
    } elseif (stripos($n, 'one set') !== false || stripos($n, 'oneset') !== false || stripos($n, 'set') !== false) {
        // Ikon One Set / Matching Set
        return '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4a2 2 0 0 1 2 2c0 .6-.3 1.2-.8 1.5L20 11a1 1 0 0 1 .5.9v1.6a1 1 0 0 1-1.5.9L12 11.5 5 14.4A1 1 0 0 1 3.5 13.5V11.9a1 1 0 0 1 .5-.9l6.8-3.5c-.5-.3-.8-.9-.8-1.5a2 2 0 0 1 2-2z"/><path d="M6 14v6a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-6"/><path d="M9 18h6"/></svg>';
    } elseif (stripos($n, 'dress') !== false || stripos($n, 'gaun') !== false || stripos($n, 'gamis') !== false) {
        // Ikon Dress / Gaun
        return '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6l1.5 5-2.5 3 4.5 10H5.5L10 11 7.5 8 9 3z"/><path d="M10 3a2 2 0 0 0 4 0"/><line x1="9" y1="11" x2="15" y2="11"/></svg>';
    } else {
        // Ikon Aksesoris / Tas
        return '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>';
    }
}

/**
 * Menghasilkan ikon SVG minimalis untuk platform media sosial & kontak resmi SOREN
 */
function get_platform_svg($platform_name) {
    $p = strtolower(trim((string)$platform_name));
    if (stripos($p, 'instagram') !== false || stripos($p, 'ig') !== false) {
        return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>';
    } elseif (stripos($p, 'whatsapp') !== false || stripos($p, 'wa') !== false) {
        return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>';
    } elseif (stripos($p, 'tiktok') !== false) {
        return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"></path></svg>';
    } elseif (stripos($p, 'shopee') !== false || stripos($p, 'tokopedia') !== false || stripos($p, 'store') !== false || stripos($p, 'toko') !== false) {
        return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>';
    } else {
        return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>';
    }
}
