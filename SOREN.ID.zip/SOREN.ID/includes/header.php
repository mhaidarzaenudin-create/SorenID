<?php
// includes/header.php - Header, Announcement Bar & Navigation SOREN.ID
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

$cart_count = get_cart_count($pdo);
$categories = get_categories($pdo);
$current_page = basename($_SERVER['PHP_SELF']);
$featured_categories = [];
foreach ($categories as $cat) {
  $normalized = strtolower(trim($cat['nama_kategori']));
  if (in_array($normalized, ['atasan', 'bawahan', 'one set', 'one-set', 'oneset'], true)) {
    $featured_categories[] = $cat;
  }
}
if (empty($featured_categories) && !empty($categories)) {
  $featured_categories = array_slice($categories, 0, 3);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - SOREN.ID' : 'SOREN.ID - Korean Women Fashion Store' ?></title>
  <meta name="description" content="Toko baju wanita bergaya Korean street style dengan koleksi atasan, bawahan, dan one set yang nyaman, trendy, dan cocok untuk daily wear.">
  <link rel="stylesheet" href="<?= ASSETS_URL ?>css/style.css?v=<?= filemtime(__DIR__ . '/../assets/css/style.css') ?>">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>💖</text></svg>">
  <style>
    /* Styling Kategori Dropdown SOREN.ID */
    .nav-dropdown {
      position: relative;
      display: inline-flex;
      align-items: center;
      list-style: none !important;
    }
    .nav-dropdown .dropdown-toggle {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      cursor: pointer;
    }
    .nav-dropdown .dropdown-caret {
      transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
      margin-top: -1px;
    }
    .nav-dropdown:hover .dropdown-caret {
      transform: rotate(180deg);
      color: var(--primary);
    }
    .nav-dropdown:hover .nav-link::after {
      width: 100%;
    }
    .dropdown-menu {
      position: absolute;
      top: calc(100% + 8px);
      left: 50%;
      transform: translateX(-50%) translateY(8px);
      min-width: 160px;
      background: rgba(255, 255, 255, 0.92);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border: 1px solid var(--border-color, #f4e6eb);
      border-radius: 12px;
      box-shadow: 0 12px 30px rgba(42, 31, 39, 0.1), 0 2px 6px rgba(42, 31, 39, 0.04);
      padding: 8px;
      list-style: none !important;
      margin: 0 !important;
      opacity: 0;
      visibility: hidden;
      pointer-events: none;
      transition: all 0.22s cubic-bezier(0.4, 0, 0.2, 1);
      z-index: 1050;
    }
    .dropdown-menu::before {
      content: '';
      position: absolute;
      top: -12px;
      left: 0;
      right: 0;
      height: 12px;
    }
    .nav-dropdown:hover .dropdown-menu,
    .nav-dropdown:focus-within .dropdown-menu {
      opacity: 1;
      visibility: visible;
      pointer-events: auto;
      transform: translateX(-50%) translateY(0);
    }
    .dropdown-menu li {
      list-style: none !important;
      margin: 0 !important;
      padding: 0 !important;
    }
    .dropdown-item {
      display: block;
      padding: 9px 16px;
      font-size: 13px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--text-dark, #2a1f27);
      text-decoration: none;
      border-radius: 8px;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      white-space: nowrap;
    }
    .dropdown-item:hover {
      background-color: var(--primary-soft, #f9ebf0);
      color: var(--primary-dark, #7a4d5e);
      padding-left: 20px;
    }
    .dropdown-item.active {
      background-color: var(--primary-soft, #f9ebf0);
      color: var(--primary-dark, #7a4d5e);
    }
    @media (max-width: 768px) {
      .nav-dropdown {
        width: 100%;
        flex-direction: column;
        align-items: flex-start;
      }
      .nav-dropdown .dropdown-toggle {
        width: 100%;
        justify-content: space-between;
        padding: 8px 0;
      }
      .dropdown-menu {
        position: static;
        transform: none !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto !important;
        box-shadow: none;
        border: none;
        border-left: 2px solid var(--primary-soft, #f9ebf0);
        background: transparent;
        padding: 4px 0 4px 12px;
        margin: 4px 0 6px 8px !important;
        min-width: auto;
        width: calc(100% - 8px);
      }
      .dropdown-menu::before {
        display: none;
      }
      .dropdown-item {
        padding: 6px 10px;
        font-size: 13px;
      }
    }
  </style>
</head>
<body>

  <!-- 1. Top Announcement Bar -->
  <div class="announcement-bar">
    <div class="container">
      <span>✨ <b>FLASH SALE</b>: Free Ongkir min. belanja Rp 150.000 • COD Seluruh Indonesia • Style Korea untuk Wanita</span>
    </div>
  </div>

  <!-- 2. Sticky Header & Navbar -->
  <header class="header-sticky">
    <div class="container">
      <nav class="navbar">
        <button type="button" class="mobile-toggle" id="mobileToggle" aria-label="Menu Navigasi">
          ☰
        </button>

        <!-- Brand Logo -->
        <a href="<?= BASE_URL ?>" class="nav-brand">
          <span class="brand-logo">SOREN.</span>
          <span class="brand-tagline">Korean Girls Fashion</span>
        </a>

        <!-- Menu Links -->
        <ul class="nav-menu" id="navMenu">
          <li><a href="<?= BASE_URL ?>" class="nav-link <?= $current_page === 'index.php' ? 'active' : '' ?>">Beranda</a></li>
          <li class="nav-dropdown">
            <a href="<?= BASE_URL ?>katalog.php" class="nav-link dropdown-toggle <?= $current_page === 'katalog.php' ? 'active' : '' ?>" id="kategoriMenu" aria-expanded="false" aria-haspopup="true">
              Kategori
              <svg class="dropdown-caret" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="6 9 12 15 18 9"></polyline>
              </svg>
            </a>
            <ul class="dropdown-menu" aria-labelledby="kategoriMenu">
              <?php foreach ($featured_categories as $cat): ?>
                <li>
                  <a href="<?= BASE_URL ?>katalog.php?kategori=<?= $cat['id'] ?>" class="dropdown-item <?= (($_GET['kategori'] ?? '') == (string)$cat['id']) ? 'active' : '' ?>">
                    <?= htmlspecialchars($cat['nama_kategori']) ?>
                  </a>
                </li>
              <?php endforeach; ?>
            </ul>
          </li>
          <li><a href="<?= BASE_URL ?>tentang-kami.php" class="nav-link <?= $current_page === 'tentang-kami.php' ? 'active' : '' ?>">About Us</a></li>
          <li><a href="<?= BASE_URL ?>kontak.php" class="nav-link <?= $current_page === 'kontak.php' ? 'active' : '' ?>">Kontak</a></li>
        </ul>

        <!-- Action Buttons (Pojok Kanan Atas) -->
        <div class="nav-actions">
          <!-- Search Trigger -->
          <button type="button" class="nav-btn" id="searchBtn" title="Pencarian Produk" aria-label="Cari Produk" onclick="document.getElementById('searchModal').classList.add('show')">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </button>

          <!-- User Account -->
          <?php if (is_logged_in()): ?>
            <a href="<?= BASE_URL ?>akun.php" class="nav-btn" title="Akun Saya (<?= htmlspecialchars($_SESSION['user_name']) ?>)" aria-label="Akun Saya">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
              <span style="font-size: 11px; margin-left: 6px; font-weight:600;"><?= htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]) ?></span>
            </a>
          <?php else: ?>
            <a href="<?= BASE_URL ?>login.php" class="nav-btn" title="Masuk / Daftar" aria-label="Masuk atau Daftar Akun">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
            </a>
          <?php endif; ?>

          <!-- Cart Drawer Trigger -->
          <button type="button" class="nav-btn" id="cartTrigger" title="Keranjang Belanja" aria-label="Lihat Keranjang Belanja">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path>
              <line x1="3" y1="6" x2="21" y2="6"></line>
              <path d="M16 10a4 4 0 0 1-8 0"></path>
            </svg>
            <span class="badge-count cart-count-badge"><?= $cart_count ?></span>
          </button>
        </div>
      </nav>
    </div>
  </header>

  <!-- 3. Quick Search Modal -->
  <div class="modal-backdrop" id="searchModal">
    <div class="modal-card" style="max-width: 480px;">
      <button type="button" class="modal-close" onclick="document.getElementById('searchModal').classList.remove('show')">✕</button>
      <h3 class="modal-title">Cari Koleksi SOREN</h3>
      <p style="font-size:13px; color:var(--text-muted); margin-bottom:18px;">Temukan outfit Korea favoritmu</p>
      <form action="<?= BASE_URL ?>katalog.php" method="GET" style="display:flex; gap:10px;">
        <input type="text" name="q" placeholder="Ketik nama produk / warna..." class="chat-input" style="flex-grow:1;" required autofocus>
        <button type="submit" class="btn btn-primary btn-sm">Cari</button>
      </form>
      <div style="margin-top: 20px; font-size: 12.5px; color: var(--text-muted);">
        <b>Trending:</b>
        <div style="display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap;">
          <a href="<?= BASE_URL ?>katalog.php?q=Oversized" class="quick-chip">Oversized</a>
          <a href="<?= BASE_URL ?>katalog.php?q=Wide Leg" class="quick-chip">Wide Leg</a>
          <a href="<?= BASE_URL ?>katalog.php?q=Set" class="quick-chip">Matching Set</a>
          <a href="<?= BASE_URL ?>katalog.php?q=Blouse" class="quick-chip">Blouse</a>
        </div>
      </div>
    </div>
  </div>

  <!-- 4. Slide-Out Cart Drawer -->
  <div class="drawer-backdrop" id="drawerBackdrop"></div>
  <div class="cart-drawer" id="cartDrawer">
    <div class="drawer-header">
      <h3>Keranjang Belanja (<span class="cart-count-badge"><?= $cart_count ?></span>)</h3>
      <button type="button" class="drawer-close" id="drawerClose">✕</button>
    </div>
    <div class="drawer-body" id="drawerBody">
      <!-- Diisi via AJAX loadCartDrawer() -->
      <div style="text-align: center; padding: 40px 10px; color: var(--text-muted);">
        <p>Memuat keranjang...</p>
      </div>
    </div>
    <div class="drawer-footer">
      <div class="drawer-subtotal">
        <span>Subtotal:</span>
        <span id="drawerSubtotal">Rp 0</span>
      </div>
      <a href="<?= BASE_URL ?>checkout.php" class="btn btn-primary btn-block" style="margin-bottom: 8px;">Lanjut ke Checkout</a>
      <a href="<?= BASE_URL ?>keranjang.php" class="btn btn-outline btn-block btn-sm" onclick="document.getElementById('drawerClose').click()">Lihat Keranjang Penuh</a>
    </div>
  </div>
