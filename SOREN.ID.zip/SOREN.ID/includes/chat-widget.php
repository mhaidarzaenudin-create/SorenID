<?php
// includes/chat-widget.php - Floating Live Chat Widget with Admin for SOREN.ID
?>
<!-- Floating Live Chat Widget (Soren Care) -->
<div class="chat-fab-container">
  <!-- Tooltip speech bubble -->
  <div class="chat-tooltip" id="chatTooltip">
    <span>👋 Butuh bantuan pilih outfit Korea yang cocok? Chat Min-Soren yuk! 💕</span>
  </div>

  <!-- Floating Action Button (Pojok Kanan Bawah) -->
  <button type="button" class="chat-fab" id="chatFab" title="Chat dengan Admin Soren Care" aria-label="Buka Live Chat">
    <div class="chat-pulse"></div>
    <svg class="chat-fab-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
    </svg>
    <span class="badge-count" id="chatFabBadge" style="display: none; top: -4px; right: -4px;">1</span>
  </button>

  <!-- Chat Window Drawer -->
  <div class="chat-window" id="chatWindow">
    <div class="chat-header">
      <div class="chat-agent">
        <div class="agent-avatar">S</div>
        <div class="agent-info">
          <h4>Soren Care</h4>
          <p><span class="online-dot"></span> Online • Respon Cepat</p>
        </div>
      </div>
      <button type="button" class="chat-close-btn" id="chatCloseBtn" title="Tutup Chat">✕</button>
    </div>

    <!-- Message Bubble Area -->
    <div class="chat-messages" id="chatMessages">
      <div style="text-align:center; padding: 20px; color: var(--text-muted); font-size:13px;">
        <p>👋 Halo! Selamat datang di <b>SOREN.ID</b>.</p>
        <p style="margin-top:6px;">Ada yang bisa Min-Soren bantu mengenai produk atau pesanan hari ini?</p>
      </div>
    </div>

    <!-- Quick FAQ Chips -->
    <div class="chat-quick-replies">
      <span class="quick-chip">Berapa lama pengiriman?</span>
      <span class="quick-chip">Outfit yang paling hits?</span>
      <span class="quick-chip">Bisa COD min?</span>
      <span class="quick-chip">Panduan ukuran outfit</span>
    </div>

    <!-- Chat Input Area -->
    <div class="chat-input-bar">
      <input type="text" id="chatInput" class="chat-input" placeholder="Tulis pesan untuk Min-Soren..." autocomplete="off">
      <button type="button" id="chatSendBtn" class="chat-send-btn" title="Kirim Pesan">➤</button>
    </div>
  </div>
</div>
